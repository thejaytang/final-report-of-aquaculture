# 1. Requirement Authoring Assistant test materials

This package contains the authored test text, all original screenshots and the offline case briefing. The text and screenshots can be opened directly. The briefing interface and analysis are in English. Source passages and screenshots retain their original language.

| Location | Contents |
| --- | --- |
| `01_Test_text/regulatory-composite-test.txt` | Complete authored test text, sections 1 through 11. Wording, punctuation and order match the briefing's text download. |
| `01_Test_text/cases-original-text.csv` | Original source passages for cases R01 through R20. |
| `02_Screenshots/individual/` | All 46 original screenshots from individual-passage tests. |
| `02_Screenshots/whole/` | All 23 original screenshots from the complete-text test. |
| `case-screenshot-index.csv` | Case-to-screenshot mapping, including which images appear in the briefing. One image may support several cases. |
| `02_Screenshots/screenshots-manifest.csv` | Original filenames, dimensions and SHA-256 hashes for all 69 screenshots. |
| `03_Offline_briefing/index.html` | English case analysis and presentation. Open in a browser and keep the adjacent `assets` folder. |

# 2. Source preservation and scope

The complete test text has 11 sections. The cancelled section 12 and the electronic training-record sentence removed by the user are excluded. This is a composite test instrument, not one enacted regulation. All 20 case quotations come verbatim from the relevant sections.

The 69 original screenshots retain their filenames and pixels, grouped by input method. The offline briefing also includes its 20 selected screenshot copies so it can run independently. `files.sha256` lists package file hashes. Email messages, access links and account credentials are excluded.
