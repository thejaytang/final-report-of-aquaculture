/* Shared, session-local presentation layout. Evidence and review content never change. */
(() => {
  'use strict';
  const locale=window.BRIEFING_I18N;
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
  const configs=[
    {id:'case-workspace',min:280,widths:[1.3,1],hide:[null,'analysis']},
    {id:'workbench-workspace',min:210,widths:[.9,1,1.15,1.3],hide:['original document','extracted content',null,'interpretation']}
  ];
  const layouts=configs.map(config=>{
    const root=document.getElementById(config.id),grid=root.querySelector('.pane-grid'),tools=root.querySelector('.pane-tools');
    const panes=[...grid.querySelectorAll('[data-pane]')];
    let weights=[...config.widths],hidden=new Set(),sizes=[],visible=[],stacked=false,drag=null;
    const button=(label,action)=>{
      const node=document.createElement('button');
      node.type='button';node.className='pane-control';node.textContent=label;
      node.addEventListener('click',action);return node;
    };
    const restoreButtons=panes.map((pane,i)=>{
      if(!config.hide[i]) return null;
      const restore=button('Show '+config.hide[i],()=>toggle(i,false));restore.hidden=true;
      restore.setAttribute('aria-controls',pane.id);tools.append(restore);
      const collapse=button('',()=>toggle(i,true));collapse.classList.add('pane-collapse');
      collapse.setAttribute('aria-label','Hide '+config.hide[i]);collapse.title='Hide '+config.hide[i];collapse.setAttribute('aria-controls',pane.id);
      collapse.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h12"/></svg>';
      pane.querySelector('.pane-heading,h4').append(collapse);
      return restore;
    });
    const reset=button('Reset layout',()=>{
      weights=[...config.widths];hidden.clear();
      syncVisibility();refresh();
    });tools.append(reset);
    const splitters=panes.slice(1).map((pane,i)=>{
      const separator=document.createElement('div');separator.className='pane-splitter';separator.tabIndex=0;
      separator.setAttribute('role','separator');separator.setAttribute('aria-orientation','vertical');
      separator.setAttribute('aria-label','Resize columns');grid.insertBefore(separator,pane);
      separator.addEventListener('keydown',event=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key) || stacked) return;
        event.preventDefault();event.stopPropagation();
        const pair=pairFor(i+1);if(!pair) return;
        const [left,right]=pair,total=sizes[left]+sizes[right];
        resizePair(left,right,event.key==='Home'?config.min:event.key==='End'?total-config.min:sizes[left]+(event.key==='ArrowLeft'?-1:1)*(event.shiftKey?40:16));
      });
      separator.addEventListener('pointerdown',event=>{
        if(event.button!==0 || stacked) return;
        const pair=pairFor(i+1);if(!pair) return;
        event.preventDefault();separator.focus({preventScroll:true});separator.setPointerCapture(event.pointerId);
        drag={pointerId:event.pointerId,x:event.clientX,pair,start:sizes[pair[0]],separator};
        root.classList.add('is-resizing');
      });
      separator.addEventListener('pointermove',event=>{
        if(drag && drag.pointerId===event.pointerId) resizePair(...drag.pair,drag.start+event.clientX-drag.x);
      });
      const finish=()=>{drag=null;root.classList.remove('is-resizing');};
      separator.addEventListener('pointerup',finish);separator.addEventListener('pointercancel',finish);separator.addEventListener('lostpointercapture',finish);
      return separator;
    });
    function pairFor(right) {
      const position=visible.indexOf(right);return position>0?[visible[position-1],right]:null;
    }
    function syncVisibility() {
      panes.forEach((pane,i)=>{
        pane.hidden=hidden.has(i);pane.inert=hidden.has(i);
        if(restoreButtons[i]) restoreButtons[i].hidden=!hidden.has(i);
      });
    }
    function toggle(i,collapse) {
      if(collapse) {
        hidden.add(i);restoreButtons[i].hidden=false;
        if(panes[i].contains(document.activeElement)) restoreButtons[i].focus({preventScroll:true});
      } else {
        hidden.delete(i);
        panes[i].hidden=false;panes[i].inert=false;
        panes[i].querySelector('.pane-collapse').focus({preventScroll:true});
      }
      syncVisibility();refresh();
    }
    function resizePair(left,right,width) {
      const total=sizes[left]+sizes[right];
      const scale=visible.reduce((sum,i)=>sum+weights[i],0)/visible.reduce((sum,i)=>sum+sizes[i],0);
      const next=clamp(width,config.min,total-config.min);
      // Unaffected panes retain their on-screen width when a minimum is active.
      visible.forEach(i=>{weights[i]=(i===left?next:i===right?total-next:sizes[i])*scale;});
      refresh();
    }
    function refresh() {
      visible=panes.map((_,i)=>i).filter(i=>!hidden.has(i));
      const width=grid.clientWidth;
      stacked=width<config.min*panes.length+22*(panes.length-1);
      root.classList.toggle('is-stacked',stacked);
      if(stacked && drag) {drag.separator.releasePointerCapture(drag.pointerId);drag=null;}
      const available=Math.max(0,width-22*(visible.length-1));
      let remaining=available,flexible=[...visible];sizes=Array(panes.length).fill(0);
      // Water-fill the remaining width so no visible desktop pane falls below its minimum.
      while(flexible.length) {
        const total=flexible.reduce((sum,i)=>sum+weights[i],0);
        const small=flexible.filter(i=>remaining*weights[i]/total<config.min);
        if(!small.length) {flexible.forEach(i=>sizes[i]=remaining*weights[i]/total);break;}
        small.forEach(i=>{sizes[i]=config.min;remaining-=config.min;});
        flexible=flexible.filter(i=>!small.includes(i));
      }
      const columns=[];
      panes.forEach((pane,i)=>{
        const pair=pairFor(i),separator=splitters[i-1];
        if(separator) {
          const show=Boolean(pair) && !stacked;
          if(!show && separator===document.activeElement) reset.focus({preventScroll:true});
          separator.hidden=!show;
          if(show) {
            const [left,right]=pair,total=sizes[left]+sizes[right];
            separator.setAttribute('aria-controls',panes[left].id+' '+panes[right].id);
            separator.setAttribute('aria-valuemin',(config.min/total*100).toFixed(1));
            separator.setAttribute('aria-valuemax',((total-config.min)/total*100).toFixed(1));
            separator.setAttribute('aria-valuenow',(sizes[left]/total*100).toFixed(1));
          }
        }
        if(!hidden.has(i)) {if(pair) columns.push('22px');columns.push(`${Math.max(0,sizes[i])}px`);}
      });
      grid.style.gridTemplateColumns=stacked?'minmax(0,1fr)':columns.join(' ');
      locale.apply(tools);splitters.forEach(separator=>locale.apply(separator));
      window.BRIEFING_DECK?.refresh();
    }
    new ResizeObserver(refresh).observe(grid);
    return {refresh};
  });
  window.BRIEFING_PANES={refresh(){layouts.forEach(layout=>layout.refresh());}};
})();
