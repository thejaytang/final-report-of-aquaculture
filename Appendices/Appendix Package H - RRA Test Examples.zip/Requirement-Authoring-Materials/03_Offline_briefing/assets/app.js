(() => {
  'use strict';
  const englishData = window.BRIEFING;
  const locale = window.BRIEFING_I18N;
  const fullscreen = window.BRIEFING_FULLSCREEN;
  const deck = window.BRIEFING_DECK;
  let data = locale.content(englishData);
  const $ = id => document.getElementById(id);
  const escape = text => String(text).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let caseIndex = 0;
  let imageRequest = 0;
  let patternId = 'M1';
  let outcomeId = 'O3';
  let modalVariant = 'shall';
  let detached = false;
  const announce = text => { $('announcer').textContent = locale.t(text); };
  const animateChange = element => {
    if (!reducedMotion.matches && element.animate) element.animate([{opacity:.75},{opacity:1}],{duration:180,easing:'cubic-bezier(.16,1,.3,1)'});
  };
  const tag = (id,kind) => {
    const collection = kind === 'mode' ? data.patterns : data.outcomes;
    const item = collection.find(value => value.id === id);
    return `<span class="tag ${kind === 'outcome' ? 'outcome-tag' : ''}">${escape(id)} · ${escape(item.name)}</span>`;
  };

  function renderPattern(id,animate=true) {
    patternId = id;
    const item = data.patterns.find(pattern => pattern.id === id);
    document.querySelectorAll('[data-pattern]').forEach(button => {
      const active = button.dataset.pattern === id;
      button.setAttribute('aria-selected',String(active));
      button.tabIndex = active ? 0 : -1;
    });
    $('pattern-panel').setAttribute('aria-labelledby',`tab-${id}`);
    $('pattern-definition').textContent = item.definition;
    $('pattern-test').textContent = item.test;
    $('pattern-status').textContent = item.status;
    if (id === 'M1') {
      const sentence = modalVariant === 'required'
        ? 'Measuring seawater temperature <strong>is required</strong>.'
        : `Seawater temperature <strong>${modalVariant}</strong> be measured.`;
      $('teaching-visual').innerHTML = `<div class="teaching-visual"><p class="example-line">${sentence}</p></div><div class="variant-options" aria-label="Change the normative expression"><button data-modal="shall" aria-pressed="${modalVariant==='shall'}">shall</button><button data-modal="must" aria-pressed="${modalVariant==='must'}">must</button><button data-modal="required" aria-pressed="${modalVariant==='required'}">is required</button></div><p class="example-result"><span class="normative-force">Obligation</span><span>The wording changes. The force should survive normalisation.</span></p>`;
    } else if (id === 'M2') {
      $('teaching-visual').innerHTML = '<div class="example-pair"><article><h4>Informative context</h4><p>“A storm means severe weather at the site.”</p><small>Keep it as context.<br>It does not need to become a duty.</small></article><article><h4>Qualitative obligation</h4><p>“After a storm, measure seawater temperature as soon as practicable.”</p><small>Keep the duty and its open timing.<br>Do not invent a 24-hour limit.</small></article></div>';
    } else {
      $('teaching-visual').innerHTML = `<div class="tree-source ${detached?'detached':''}"><span class="shared-condition">${detached?'Shared condition lost: ':''}After a storm</span><div>The operator shall:</div><div class="nested-duties"><div><b>(a)</b> inspect the cages<small>${detached?'Detached: “Empty cages are exempt.”':'Exception to (a) only: empty cages'}</small></div><div><b>(b)</b> check the moorings</div></div><p class="tree-explanation">${detached?'Illustrative failure: the child duties lose their trigger, and the exemption loses its target.':'Both duties inherit the storm trigger. “Paragraph (a) does not apply to empty cages” modifies only the inspection duty.'}</p></div><div class="variant-options"><button data-context="linked" aria-pressed="${!detached}">Keep the relationships</button><button data-context="detached" aria-pressed="${detached}">Show a broken split</button></div>`;
    }
    locale.apply($('pattern-panel'));
    if (animate) animateChange($('teaching-visual'));
  }
  $('teaching-visual').addEventListener('click',event => {
    const modalButton = event.target.closest('[data-modal]');
    const contextButton = event.target.closest('[data-context]');
    if (modalButton) {
      modalVariant = modalButton.dataset.modal;
      renderPattern(patternId);
      document.querySelector(`[data-modal="${modalVariant}"]`).focus({preventScroll:true});
      announce(`Expression changed to ${modalVariant}; normative force remains obligation.`);
    }
    if (contextButton) {
      detached = contextButton.dataset.context === 'detached';
      renderPattern(patternId);
      document.querySelector(`[data-context="${detached?'detached':'linked'}"]`).focus({preventScroll:true});
      announce(detached?'Illustrative broken split shown.':'Source relationships restored.');
    }
  });
  document.querySelectorAll('[data-pattern]').forEach(button => button.addEventListener('click',() => renderPattern(button.dataset.pattern)));

  $('outcome-list').innerHTML = data.outcomes.map(item => `<button role="tab" id="tab-${item.id}" aria-selected="false" aria-controls="outcome-detail" data-outcome="${item.id}" tabindex="-1"><span>${item.id}</span>${escape(item.name)}</button>`).join('');
  function renderOutcome(id,animate=true) {
    outcomeId = id;
    const item = data.outcomes.find(value => value.id === id);
    document.querySelectorAll('[data-outcome]').forEach(button => {
      const active = button.dataset.outcome === id;
      button.setAttribute('aria-selected',String(active));
      button.tabIndex = active ? 0 : -1;
    });
    $('outcome-detail').setAttribute('aria-labelledby',`tab-${id}`);
    $('outcome-detail').innerHTML = `<h3>${escape(item.name)}</h3><p>${escape(item.text)}</p><p class="outcome-example">${escape(item.example)}</p><div class="tag-list">${item.modes.map(mode => tag(mode,'mode')).join('')}</div><p class="small-note" style="margin-top:22px">${escape(item.status)}</p>`;
    $('mapping-table').innerHTML = `<table class="map-table"><caption class="sr-only">Possible pattern to outcome relationships; selected outcome is ${escape(item.name)}</caption><thead><tr><th scope="col">Pattern</th>${data.outcomes.map(outcome => `<th scope="col" class="${outcome.id===id?'selected-col':''}">${outcome.id}<br>${escape(outcome.short)}</th>`).join('')}</tr></thead><tbody>${data.patterns.map(pattern => `<tr><th scope="row">${pattern.id} · ${escape(pattern.short)}</th>${data.outcomes.map(outcome => `<td class="${outcome.id===id?'selected-col':''}">${outcome.modes.includes(pattern.id)?'<span class="map-dot" aria-hidden="true"></span><span class="sr-only">Possible relationship</span>':'<span class="map-empty" aria-hidden="true">·</span><span class="sr-only">No relationship proposed</span>'}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    locale.apply($('outcome-detail'));
    locale.apply($('mapping-table'));
    if (animate) animateChange($('outcome-detail'));
  }
  $('outcome-list').addEventListener('click',event => {
    const button = event.target.closest('[data-outcome]');
    if (button) renderOutcome(button.dataset.outcome);
  });
  // Native tab buttons with a roving tab stop; arrow navigation remains inside the tab group.
  const singleColumnOutcomes = window.matchMedia('(max-width: 650px)');
  const syncOutcomeDirection = () => $('outcome-list').setAttribute('aria-orientation',singleColumnOutcomes.matches?'vertical':'horizontal');
  singleColumnOutcomes.addEventListener('change',syncOutcomeDirection);
  syncOutcomeDirection();
  document.querySelectorAll('[role="tablist"]').forEach(list => list.addEventListener('keydown',event => {
    const tabs = [...list.querySelectorAll('[role="tab"]')];
    const current = tabs.indexOf(document.activeElement);
    const forward = list.getAttribute('aria-orientation')==='horizontal'?'ArrowRight':'ArrowDown';
    const backward = list.getAttribute('aria-orientation')==='horizontal'?'ArrowLeft':'ArrowUp';
    if (current < 0 || ![forward,backward,'Home','End'].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length-1 : (current + (event.key===forward?1:-1) + tabs.length)%tabs.length;
    tabs[next].click();
    tabs[next].focus({preventScroll:true});
    const selected=tabs[next].getBoundingClientRect(), bounds=list.getBoundingClientRect();
    if(selected.left<bounds.left) list.scrollLeft+=selected.left-bounds.left;
    else if(selected.right>bounds.right) list.scrollLeft+=selected.right-bounds.right;
  }));

  $('full-source').innerHTML = data.sections.map(section => `<section aria-labelledby="source-section-${section.id}"><h3 id="source-section-${section.id}">§ ${section.id}. ${escape(section.title)}</h3><p class="source-text">${escape(section.text)}</p></section>`).join('');
  function renderCaseOptions() {
    $('case-select').innerHTML = data.cases.map((item,index) => `<option value="${index}">${item.id} · §${item.section} · ${escape(item.title)}</option>`).join('');
  }
  renderCaseOptions();
  function placeholder(item,message='Screenshot to be added') {
    $('case-image-area').innerHTML = `<div class="screenshot-empty"><svg viewBox="0 0 48 48" aria-hidden="true"><rect x="5" y="7" width="38" height="32" rx="2"/><path d="M5 15h38M12 11h1m4 0h1M13 32l8-8 6 6 5-5 6 7"/></svg><strong>${escape(message)}</strong><p>The matching assistant result will appear here for comparison with the source above.</p><small>${item.id} · §${item.section} · Reserved evidence position</small></div>`;
    locale.apply($('case-image-area'));
  }
  function renderCase(index,animate=true) {
    caseIndex = Math.min(data.cases.length-1,Math.max(0,index));
    const item = data.cases[caseIndex];
    const section = data.sections.find(value => value.id === item.section);
    $('case-select').value = String(caseIndex);
    $('case-prev').disabled = caseIndex===0;
    $('case-next').disabled = caseIndex===data.cases.length-1;
    $('case-progress').textContent = `${caseIndex+1} / ${data.cases.length}`;
    $('case-identity').textContent = `${item.id} · § ${item.section}`;
    $('case-title').textContent = item.title;
    $('case-source').textContent = item.quote;
    const capture = item.evidence[item.selectedEvidence.batch];
    $('case-modes').innerHTML = capture.modes.length ? capture.modes.map(mode => tag(mode,'mode')).join('') : '<span class="tag neutral-tag">No mechanism attributed</span>';
    $('case-outcomes').innerHTML = capture.outcomes.length ? capture.outcomes.map(outcome => tag(outcome,'outcome')).join('') : '<span class="tag neutral-tag">No semantic failure established</span>';
    $('case-logic').textContent = item.reviewSummary.expected;
    $('case-analysis').textContent = capture.analysis;
    $('case-hypothesis').textContent = item.analysis+' '+item.watch;
    $('case-context').textContent = `§ ${section.id}. ${section.title}\n\n${section.text}`;
    $('actual-finding').textContent = item.reviewSummary.problem;
    $('actual-finding').dataset.status = capture.outcomes.length ? 'changed' : 'reviewed';
    renderScreenshot();
    locale.apply($('active-case'));
    if (animate) animateChange($('active-case'));
  }
  function renderScreenshot() {
    const item = data.cases[caseIndex];
    const selection = item.selectedEvidence;
    const screen = item.evidence[selection.batch].screens[selection.index];
    const request = ++imageRequest;
    $('shot-open').href = screen.src;
    placeholder(item);
    const img = new Image();
    img.className = 'case-screenshot';
    img.alt = `${item.id} · ${locale.t(screen.label)}`;
    img.onload = () => { if (request===imageRequest) $('case-image-area').replaceChildren(img); };
    img.onerror = () => { if (request===imageRequest) placeholder(item,'Screenshot unavailable'); };
    img.src = screen.src;
  }
  $('case-select').addEventListener('change',event => renderCase(Number(event.target.value)));
  $('case-prev').addEventListener('click',() => renderCase(caseIndex-1));
  $('case-next').addEventListener('click',() => renderCase(caseIndex+1));
  $('download-source').addEventListener('click',() => {
    const text = englishData.sections.map(section => `§ ${section.id}. ${section.title}\n\n${section.text}`).join('\n\n');
    const url = URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));
    const link = document.createElement('a');
    link.href = url; link.download = 'regulatory-composite-test.txt';
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url),1000);
    announce('The composite test text has been downloaded.');
  });

  function syncFullscreen() {
    const active=fullscreen.active();
    $('fullscreen').setAttribute('aria-label',locale.t(active?'Exit full screen':'Enter full screen'));
    $('fullscreen').title=locale.t(active?'Exit full screen':'Full screen');
    $('fullscreen').setAttribute('aria-pressed',String(active));
    $('fullscreen').dataset.active=String(active);
    $('fullscreen').querySelector('path').setAttribute('d',active?'M3 8h5V3m13 5h-5V3M3 16h5v5m13-5h-5v5':'M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5');
  }
  let fullscreenError='';
  function showFullscreenError(message) {
    fullscreenError=message;
    $('fullscreen-notice').textContent=message;
    locale.apply($('fullscreen-notice'));
    $('fullscreen-notice').hidden=false;
    syncFullscreen();
  }
  fullscreen.onerror=showFullscreenError;
  async function fullScreen(exitOnly=false) {
    const exiting=exitOnly || fullscreen.active();
    fullscreenError='';
    $('fullscreen-notice').hidden=true;
    try { await (exiting ? fullscreen.exit() : fullscreen.enter()); }
    catch(error) {
      if (!exiting || fullscreen.active()) {
        showFullscreenError(error.message);
      }
    }
    syncFullscreen();
  }
  $('fullscreen').addEventListener('click',() => fullScreen());
  ['fullscreenchange','webkitfullscreenchange'].forEach(name => document.addEventListener(name,syncFullscreen));
  document.addEventListener('keydown',event => { if(event.key==='Escape' && fullscreen.active()) fullScreen(true); });
  function applyLanguage() {
    data=locale.content(englishData);
    document.documentElement.lang='en';
    document.title=locale.t('Regulatory meaning · Requirements Authoring Assistant');
    $('outcome-list').innerHTML = data.outcomes.map(item => `<button role="tab" id="tab-${item.id}" aria-selected="false" aria-controls="outcome-detail" data-outcome="${item.id}" tabindex="-1"><span>${item.id}</span>${escape(item.name)}</button>`).join('');
    renderCaseOptions();
    renderPattern(patternId,false);
    renderOutcome(outcomeId,false);
    renderCase(caseIndex,false);
    $('fullscreen-notice').textContent=fullscreenError;
    locale.apply();
    window.BRIEFING_PANES.refresh();
    syncFullscreen();
    deck.refresh();
  }
  applyLanguage();
  deck.start();
})();
