/* Both browser API families use one state reader and one explicit exit action. */
(() => {
  let lastAction='enter';
  const messages={enter:'Could not enter full screen. Use the browser full-screen control.',exit:'Could not exit full screen. Press Esc or use the browser full-screen control.'};
  const active = () => Boolean(document.fullscreenElement || document.webkitFullscreenElement || document.webkitIsFullScreen);
  const enter = async () => {
    lastAction='enter';
    const request=document.documentElement.requestFullscreen || document.documentElement.webkitRequestFullscreen;
    if (!request) throw new Error('Full screen is unavailable here. Use the browser full-screen control.');
    try { await request.call(document.documentElement); }
    catch (_) { throw new Error('Could not enter full screen. Use the browser full-screen control.'); }
  };
  const exit = async () => {
    lastAction='exit';
    // Calling the exit action never requests entry, even if the host's state is stale.
    const webkitExit=document.webkitExitFullscreen || document.webkitCancelFullScreen;
    const webkitActive=!document.fullscreenElement && (document.webkitFullscreenElement || document.webkitIsFullScreen);
    const leave=webkitActive ? webkitExit || document.exitFullscreen : document.exitFullscreen || webkitExit;
    if (!leave) throw new Error('Could not exit full screen. Press Esc or use the browser full-screen control.');
    try { await leave.call(document); }
    catch (_) { throw new Error('Could not exit full screen. Press Esc or use the browser full-screen control.'); }
  };
  const api={active,enter,exit,onerror:()=>{}};
  ['fullscreenerror','webkitfullscreenerror'].forEach(name=>document.addEventListener(name,()=>api.onerror(messages[lastAction])));
  window.BRIEFING_FULLSCREEN=api;
})();
