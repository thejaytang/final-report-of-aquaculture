/* English handoff. Original source passages and screenshot references are preserved. */
window.BRIEFING = {
  "patterns": [
    {
      "id": "M1",
      "name": "Normative-language mismatch",
      "short": "Language",
      "definition": "Regulatory force is expressed in forms that may not match the assistant’s fixed verbal-form vocabulary.",
      "test": "Preserve obligation, prohibition and permission, even when the original wording changes.",
      "status": "Boundary to test · must → shall substitution observed; meaning needs separate review"
    },
    {
      "id": "M2",
      "name": "Verifiability mismatch",
      "short": "Verification",
      "definition": "Authoring-quality rules can misclassify informative context or qualitative obligations when they expect a standalone, precisely measurable requirement.",
      "test": "Retain useful context and qualitative duties. Identify evidence gaps without inventing a threshold.",
      "status": "Pilot concern · unsupported replacement criteria observed"
    },
    {
      "id": "M3",
      "name": "Context dependence",
      "short": "Context",
      "definition": "A clause gets its complete meaning from a parent, shared condition, list, exception, reference or another sentence.",
      "test": "Preserve those connections when the text is decomposed into reviewable units.",
      "status": "Captured context errors · R08 timing and R16 reversed applicability"
    }
  ],
  "outcomes": [
    {
      "id": "O1",
      "name": "No matching field",
      "short": "No field",
      "text": "A source expression has no direct destination in the available fields. Safe normalization may resolve the mismatch; losing the original force does not.",
      "example": "“must” has no literal selector. Is obligation still represented?",
      "modes": [
        "M1"
      ],
      "status": "Not established by the selector alone"
    },
    {
      "id": "O2",
      "name": "Content omitted",
      "short": "Omission",
      "text": "A duty, qualifier, definition or context fragment is skipped. The cause requires a separate check.",
      "example": "R13’s training-record request duty is absent from the complete-text output.",
      "modes": [
        "M1",
        "M2",
        "M3"
      ],
      "status": "Observed in supplied captures · context, qualifiers and the R13 duty"
    },
    {
      "id": "O3",
      "name": "Meaning rewritten",
      "short": "Rewriting",
      "text": "A transformation or suggested replacement adds, removes or changes an obligation, threshold, actor or qualification.",
      "example": "R16 changes medicines added AND discharge away into medicines not added OR discharge at the facility.",
      "modes": [
        "M1",
        "M2",
        "M3"
      ],
      "status": "Observed in selected rows and unadopted suggestions"
    },
    {
      "id": "O4",
      "name": "Relationships flattened",
      "short": "Flattening",
      "text": "Separate entries retain words but lose the parent, shared condition, conjunction or reference that made them a complete requirement.",
      "example": "R09’s isolated split loses the shared possible-damage storm trigger.",
      "modes": [
        "M3"
      ],
      "status": "Observed in R09’s isolated split · shared storm trigger lost"
    },
    {
      "id": "O5",
      "name": "Subrequirements or exceptions detached",
      "short": "Detached exception",
      "text": "A child duty or exemption is separated from its target. Applicability can broaden, narrow or reverse.",
      "example": "An exemption for inspection is applied to every duty.",
      "modes": [
        "M3"
      ],
      "status": "Not established by supplied captures · visible exceptions often survive"
    },
    {
      "id": "O6",
      "name": "Scope / Condition / Demand misassigned",
      "short": "Field error",
      "text": "The object being checked, the applicability condition or the required action is assigned to the wrong field. This can also happen in a simple, well-formed sentence.",
      "example": "R05 makes Competence perform the action of documenting competence.",
      "modes": [
        "M1",
        "M2",
        "M3"
      ],
      "status": "Observed in role and field assignments · not every error needs a mismatch pattern"
    }
  ],
  "sections": [
    {
      "id": 1,
      "title": "Scope, purpose and definitions",
      "text": "These provisions apply to all aquaculture species cultivated at a site, including fish, molluscs and algae. Their purpose is to prevent escapes and safeguard animal welfare.\n\n“Operator” means the person responsible for operating the site."
    },
    {
      "id": 2,
      "title": "Cultivated species",
      "text": "The cultivation of species that do not occur naturally in the area is prohibited.\n\nThis prohibition does not apply where the competent authority has issued written authorisation permitting the cultivation of that species at that site."
    },
    {
      "id": 3,
      "title": "Competence and training",
      "text": "The operator must ensure that sufficient personnel possess the knowledge and skills necessary for their assigned tasks.\n\nSuch competence shall be documented through both practical and theoretical training. The training shall:\n\na. be delivered by a veterinarian, a fish health biologist, or another person with equivalent expertise in fish welfare;\n\nb. cover all of the following topics:\n\n1. the relevant provisions of these regulations;\n2. normal animal behaviour and physiological needs;\n3. production conditions that affect animal welfare;\n\nc. be repeated as needed and at intervals not exceeding five years."
    },
    {
      "id": 4,
      "title": "Inspection after storms",
      "text": "Following a storm that may have damaged a containment structure, the operator must inspect that structure as soon as practicable and retain a record of the inspection."
    },
    {
      "id": 5,
      "title": "Damaged structures",
      "text": "If damage is found, the structure must not be used until it has been repaired, unless the competent authority has approved a temporary arrangement permitting its use."
    },
    {
      "id": 6,
      "title": "Authority powers",
      "text": "The competent authority may extend the five-year training interval in § 3(c). Such an extension does not waive the training content requirements in § 3(b)."
    },
    {
      "id": 7,
      "title": "Records",
      "text": "The operator shall retain each inspection record for three years after the date of the inspection.\n\nThe operator is required to make training records available to the competent authority on request."
    },
    {
      "id": 8,
      "title": "External reference",
      "text": "Disinfection must be carried out in accordance with Annex 2."
    },
    {
      "id": 9,
      "title": "Additional training",
      "text": "The operator should conduct additional refresher training after changes to working methods."
    },
    {
      "id": 10,
      "title": "Discharge of bath treatment water",
      "text": "When medicinal products have been added to bath treatment water and the water is discharged at locations other than the aquaculture facility, the discharge shall take place while the vessel is underway.\n\nInformation regarding the time of discharge, geographic position, the site concerned, and the medicinal product involved shall be reported to the Norwegian Directorate of Fisheries.\n\nNotification of the discharge shall be submitted in the manner determined by the supervisory authority."
    },
    {
      "id": 11,
      "title": "Risk assessment and systematic measures",
      "text": "The risk assessment shall form the basis for systematic measures.\n\nThe best available knowledge shall be incorporated into the risk assessment, the selection of systematic measures, and monitoring activities."
    }
  ],
  "cases": [
    {
      "id": "R01",
      "section": 1,
      "title": "Keep context without turning it into a duty",
      "quote": "These provisions apply to all aquaculture species cultivated at a site, including fish, molluscs and algae. Their purpose is to prevent escapes and safeguard animal welfare.\n\n“Operator” means the person responsible for operating the site.",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O6"
      ],
      "logic": "Scope + purpose + definition inform later duties.",
      "analysis": "Preserve all three context functions. The species universe is broader than fish. A purpose or definition need not become a standalone SHALL requirement.",
      "watch": "Check whether context remains available when later clauses are interpreted.",
      "screenshot": "assets/evidence/individual/R01.png",
      "observedModes": [
        "M2",
        "M3"
      ],
      "observedOutcomes": [
        "O2",
        "O3",
        "O6"
      ],
      "finding": "Context becomes a duty assigned to the species.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R01.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R01(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3",
            "O6"
          ],
          "finding": "Context becomes a duty assigned to the species.",
          "analysis": "The purpose becomes “species … shall prevent escapes and safeguard animal welfare”. The Operator definition is absent from the transformed row. Species are now treated as the actor for a duty that the source never assigned to them."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/1.png",
              "label": "Complete input"
            },
            {
              "src": "assets/evidence/whole/2.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Content not extracted",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [
            "O2"
          ],
          "finding": "The scope, purpose and definition have no structured entries.",
          "analysis": "The complete input includes §1, but the 22 visible output entries start with the species prohibition. The source remains in the input; these context functions are not represented as output entries. Their availability to downstream interpretation cannot be confirmed from screenshots."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "Purpose becomes a duty assigned to species; the Operator definition disappears.",
        "expected": "Keep scope, purpose and definition as context for later duties."
      }
    },
    {
      "id": "R02",
      "section": 2,
      "title": "Recognise a prohibition without “shall not”",
      "quote": "The cultivation of species that do not occur naturally in the area is prohibited.",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O1",
        "O2",
        "O3",
        "O6"
      ],
      "logic": "Non-native species → cultivation prohibited, subject to §2’s exception.",
      "analysis": "“Is prohibited” carries normative force. Preserve the species, cultivation activity, area and link to the following exemption. Do not default to a fish-only scope.",
      "watch": "Check force preservation and the regulated object, not literal modal-word matching.",
      "screenshot": "assets/evidence/whole/2.png",
      "observedModes": [],
      "observedOutcomes": [
        "O3",
        "O6"
      ],
      "finding": "The same activity-as-actor wording appears in the full run.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R02.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R02(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "Prohibition is recognised; the action becomes its own actor.",
          "analysis": "SHALL NOT preserves the force of “is prohibited”. The row reads “Cultivation … shall not cultivate species …”; Scope contains the cultivation activity and Demand repeats the action. This is a field/wording error, not proof that a missing literal modal prevents recognition."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/2.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Observed change",
          "modes": [],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "The same activity-as-actor wording appears in the full run.",
          "analysis": "Entry 1.1 recognises SHALL NOT, but still says cultivation shall not cultivate. The full context does not resolve this field construction. No O1 failure is established by either capture."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "“Cultivation shall not cultivate” makes an activity its own actor.",
        "expected": "Cultivation of non-native species is prohibited. Keep the object and prohibition coherent."
      }
    },
    {
      "id": "R03",
      "section": 2,
      "title": "Attach the exemption to its prohibition",
      "quote": "This prohibition does not apply where the competent authority has issued written authorisation permitting the cultivation of that species at that site.",
      "modes": [
        "M3"
      ],
      "outcomes": [
        "O4",
        "O5",
        "O6"
      ],
      "logic": "Written authorisation for this species AND this site → §2 prohibition exempted.",
      "analysis": "The exception is linked to a particular prohibition, species and site. It is not a general exemption from every provision.",
      "watch": "Check the exception target, authority, written form and species/site limits.",
      "screenshot": "assets/evidence/individual/R03.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O2",
        "O3"
      ],
      "finding": "“Written” survives in the Condition field, but disappears from the row.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R03.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R03(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Partial preservation",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3"
          ],
          "finding": "“Written” survives in the Condition field, but disappears from the row.",
          "analysis": "The exception still names the authority, species and site. The row omits the required written form; the attributes retain it. This inconsistency matters if the row is used alone. The screenshot does not prove that the exception has been attached to the wrong prohibition."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/3.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Written authorisation and the bounded exemption are retained.",
          "analysis": "Entry 1.2 preserves the competent authority, written authorisation, species and site, and says the prohibition does not apply. The visible wording keeps the exception target. Stored relationship IDs are unavailable, so a complete relationship audit is still outside this evidence."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "“Written” is missing from the row, although Condition retains it.",
        "expected": "Only written authorisation for this species and this site creates the exemption."
      }
    },
    {
      "id": "R04",
      "section": 3,
      "title": "Preserve staffing sufficiency and competence",
      "quote": "The operator must ensure that sufficient personnel possess the knowledge and skills necessary for their assigned tasks.",
      "modes": [
        "M1",
        "M2"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O6"
      ],
      "logic": "Sufficient personnel AND task-relevant knowledge AND skills.",
      "analysis": "Staffing sufficiency and individual competence both matter. The source supplies no headcount, certificate, experience period or test score.",
      "watch": "Check whether staffing is lost or unsupported criteria are added.",
      "screenshot": "assets/evidence/individual/R04.png",
      "observedModes": [
        "M2"
      ],
      "observedOutcomes": [
        "O2",
        "O3"
      ],
      "finding": "The row drops staffing sufficiency; Demand still contains it.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R04.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R04(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M2"
          ],
          "outcomes": [
            "O2",
            "O3"
          ],
          "finding": "The row drops staffing sufficiency; Demand still contains it.",
          "analysis": "“Sufficient personnel” becomes personnel with the required knowledge and skills in the row. Having competent personnel does not by itself ensure enough personnel. The Demand field retains “sufficient”, so the two representations disagree. Must → shall alone is not the failure."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/4.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Unsupported suggestion",
          "modes": [
            "M2"
          ],
          "outcomes": [
            "O3"
          ],
          "finding": "Sufficiency is retained, but suggested headcounts have no source basis.",
          "analysis": "Entry 1.3 keeps “sufficient personnel” and flags it Not Verifiable. A proposed replacement requires at least two qualified personnel per task. The source specifies no number. This is an unsupported suggestion, not evidence of an adopted final requirement."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The row drops “sufficient”; Demand still contains it.",
        "expected": "Require enough personnel with the knowledge and skills needed for their tasks."
      }
    },
    {
      "id": "R05",
      "section": 3,
      "title": "Carry the referent and both training forms",
      "quote": "Such competence shall be documented through both practical and theoretical training.",
      "modes": [
        "M3"
      ],
      "outcomes": [
        "O2",
        "O4",
        "O6"
      ],
      "logic": "“Such competence” → preceding competence; practical AND theoretical.",
      "analysis": "Resolve the referent to the preceding requirement. Both training forms are required. Documentation is distinct from a generic statement that training exists.",
      "watch": "Check antecedent binding and whether AND becomes OR.",
      "screenshot": "assets/evidence/whole/5.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O3",
        "O6"
      ],
      "finding": "Full context does not fix the documentation actor.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R05.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R05(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "A documentation obligation becomes “Competence shall document competence”.",
          "analysis": "Both practical and theoretical training survive. The passive “shall be documented” becomes an active Demand, with Competence as Scope/actor. Competence is the object to be documented, not the entity performing documentation. Antecedent links cannot be audited in this isolated input."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/5.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "Full context does not fix the documentation actor.",
          "analysis": "Entry 1.4 still says “Competence shall document competence” and retains both training forms. The visible failure is the active/passive role assignment. A resolved link from “such competence” to §3’s staffing duty is not visible."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "“Competence shall document competence” gives the object an action.",
        "expected": "Competence shall be documented through both practical and theoretical training."
      }
    },
    {
      "id": "R06",
      "section": 3,
      "title": "Keep alternatives inside the parent training duty",
      "quote": "The training shall:\n\na. be delivered by a veterinarian, a fish health biologist, or another person with equivalent expertise in fish welfare;",
      "modes": [
        "M3"
      ],
      "outcomes": [
        "O2",
        "O4",
        "O5"
      ],
      "logic": "Veterinarian OR fish health biologist OR another person with equivalent expertise.",
      "analysis": "The item inherits “The training shall”. These are alternative provider categories; equivalent expertise qualifies the third option.",
      "watch": "Check inherited modality, OR semantics and the qualifier’s target.",
      "screenshot": "assets/evidence/individual/R06.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [],
      "finding": "All three alternative provider categories survive.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R06.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R06(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "All three alternative provider categories survive.",
          "analysis": "The row keeps veterinarian OR fish health biologist OR another person with equivalent fish-welfare expertise. The expertise qualifier still belongs to the third option. This capture does not demonstrate a broken OR or a detached child duty."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/6.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "The parent training duty and provider alternatives are retained.",
          "analysis": "Entry 1.5 repeats Training and keeps the three alternatives with equivalent expertise on the third. The visible wording preserves the requirement. This is a useful counterexample to treating every nested clause as a failed extraction."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "No semantic defect is visible: all three provider alternatives survive.",
        "expected": "Keep the OR alternatives; equivalent expertise qualifies the third option."
      }
    },
    {
      "id": "R07",
      "section": 3,
      "title": "Retain all nested curriculum topics",
      "quote": "b. cover all of the following topics:\n\n1. the relevant provisions of these regulations;\n2. normal animal behaviour and physiological needs;\n3. production conditions that affect animal welfare;",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O4",
        "O5"
      ],
      "logic": "Training content includes topic 1 AND topic 2 AND topic 3.",
      "analysis": "Each topic belongs under the training-content duty. A topic fragment is not an independent requirement for an animal or a production condition.",
      "watch": "Check complete topic coverage and parent-child links.",
      "screenshot": "assets/evidence/individual/R07.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [],
      "finding": "Three topic requirements retain their training context.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R07.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R07(2).png",
              "label": "Topic 1 attributes"
            },
            {
              "src": "assets/evidence/individual/R07(3).png",
              "label": "Topic 2 attributes"
            },
            {
              "src": "assets/evidence/individual/R07(4).png",
              "label": "Topic 3 attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Three topic requirements retain their training context.",
          "analysis": "The split produces three Training shall cover rows. All topics are present and each repeats the parent object. Splitting alone is not meaning loss. Screenshots show topic coverage but not stored parent-child relationship metadata."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/7.png",
              "label": "Output and attributes"
            },
            {
              "src": "assets/evidence/whole/8.png",
              "label": "Output and attributes"
            },
            {
              "src": "assets/evidence/whole/9.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "All curriculum topics remain in entries 1.6–1.8.",
          "analysis": "Each topic is still a training-content duty. Neither AND-to-OR substitution nor an omitted topic is visible. Whether these entries have machine-readable parent links requires an export, not a screenshot inference."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "All topics survive. Stored parent-child links are not visible.",
        "expected": "All three topics belong to the training-content duty."
      }
    },
    {
      "id": "R08",
      "section": 3,
      "title": "Keep both timing constraints",
      "quote": "c. be repeated as needed and at intervals not exceeding five years.",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O4"
      ],
      "logic": "Repeat when needed AND never let the interval exceed five years, subject to §6.",
      "analysis": "A fixed five-year schedule alone loses the need-triggered duty. The later extension power must stay linked without waiving training content.",
      "watch": "Check both timing branches and the §6 cross-reference.",
      "screenshot": "assets/evidence/whole/10.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O3",
        "O4",
        "O6"
      ],
      "finding": "The five-year maximum becomes conditional on need.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R08.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R08(2).png",
              "label": "Need-trigger attributes"
            },
            {
              "src": "assets/evidence/individual/R08(3).png",
              "label": "Five-year attributes"
            }
          ],
          "status": "Warning only",
          "modes": [
            "M2"
          ],
          "outcomes": [],
          "finding": "Both timing branches survive; “when needed” gets a warning.",
          "analysis": "The two rows separately require repetition when needed and at intervals not exceeding five years. Not Verifiable is an authoring-quality judgement on open timing; it is not itself an omitted duty. No unsupported replacement is shown here."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/10.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O3",
            "O4",
            "O6"
          ],
          "finding": "The five-year maximum becomes conditional on need.",
          "analysis": "Entry 1.9 says “If needed, Training shall repeat at intervals not exceeding five years”; Condition is “as needed”. The source imposes two constraints joined by AND. The output makes need govern the maximum interval, allowing a reading with no five-year obligation when no need is identified."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The five-year maximum applies only “if needed”.",
        "expected": "Repeat when needed AND at intervals not exceeding five years, subject to the authority’s extension power."
      }
    },
    {
      "id": "R09",
      "section": 4,
      "title": "Preserve possibility, trigger and open timing",
      "quote": "Following a storm that may have damaged a containment structure, the operator must inspect that structure as soon as practicable and retain a record of the inspection.",
      "modes": [
        "M1",
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O4",
        "O6"
      ],
      "logic": "Storm with possible damage → inspect promptly as practicable AND retain a record.",
      "analysis": "“May” expresses possible damage, not permission. The duty is triggered by that possibility; the text sets no 24-hour deadline.",
      "watch": "Check the shared trigger, both duties and whether a deadline is invented.",
      "screenshot": "assets/evidence/individual/R09(2).png",
      "observedModes": [
        "M2",
        "M3"
      ],
      "observedOutcomes": [
        "O2",
        "O3",
        "O4"
      ],
      "finding": "The split loses the shared storm trigger.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R09.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R09(2).png",
              "label": "Output continued"
            },
            {
              "src": "assets/evidence/individual/R09(3).png",
              "label": "Inspection attributes"
            },
            {
              "src": "assets/evidence/individual/R09(4).png",
              "label": "Record attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3",
            "O4"
          ],
          "finding": "The split loses the shared storm trigger.",
          "analysis": "Neither transformed row contains the possible-damage storm condition, and both Condition fields are blank. Inspection and record retention become unconditional. Suggested 2-, 24- and 8-hour deadlines add unsupported limits; the screenshots do not show them being adopted."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/11.png",
              "label": "Output and attributes"
            },
            {
              "src": "assets/evidence/whole/12.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Partial preservation",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3"
          ],
          "finding": "The storm trigger returns; the actor and practicability qualifier change.",
          "analysis": "Entries 1.10 and 1.11 both keep the possible-damage trigger. The inspection row omits the operator and replaces “as soon as practicable” with “promptly”, losing the feasibility qualification. Suggested 24-, 8- and 12-hour deadlines remain unsupported and unadopted in these captures."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 1
      },
      "reviewSummary": {
        "problem": "Both child rows lose the storm trigger. Suggestions invent deadlines.",
        "expected": "Both duties inherit the possible-damage storm trigger; inspection remains as soon as practicable."
      }
    },
    {
      "id": "R10",
      "section": 5,
      "title": "Preserve the condition, end point and exception",
      "quote": "If damage is found, the structure must not be used until it has been repaired, unless the competent authority has approved a temporary arrangement permitting its use.",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O3",
        "O4",
        "O5",
        "O6"
      ],
      "logic": "Damage found AND not repaired AND no approved temporary use → use prohibited.",
      "analysis": "This is a conditional prohibition. Repair ends it; an approved temporary arrangement creates a bounded exception.",
      "watch": "Check negation, the repair condition and the exception target.",
      "screenshot": "assets/evidence/individual/R10.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O2",
        "O3"
      ],
      "finding": "The exception stays attached, but its use-specific qualifier is missing.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R10.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R10(29.png",
              "label": "Attributes"
            }
          ],
          "status": "Partial preservation",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3"
          ],
          "finding": "The exception stays attached, but its use-specific qualifier is missing.",
          "analysis": "Damage, repair and authority approval survive. The row and Demand omit “permitting its use” from the temporary arrangement. That qualifier bounds which approval creates an exemption. This is qualifier loss, not proof that the exception was applied to unrelated duties."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/13.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "The bounded temporary-use exception is retained.",
          "analysis": "Entry 1.12 keeps damage, prohibition until repair, and absence of authority approval for a temporary arrangement permitting use. Recasting unless as a negative condition preserves the visible conditional prohibition here."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The temporary arrangement loses “permitting its use”.",
        "expected": "Use remains prohibited until repair, unless the authority approves temporary use."
      }
    },
    {
      "id": "R11",
      "section": 6,
      "title": "Distinguish authority power from operator duty",
      "quote": "The competent authority may extend the five-year training interval in § 3(c). Such an extension does not waive the training content requirements in § 3(b).",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O3",
        "O4",
        "O5",
        "O6"
      ],
      "logic": "Authority may extend interval; §3(b) content remains required.",
      "analysis": "The power belongs to the authority. An extension is not automatic and does not remove the content requirements.",
      "watch": "Check the actor, permission and precise scope of the change.",
      "screenshot": "assets/evidence/individual/R11.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O2",
        "O3"
      ],
      "finding": "The extension power loses its authority actor in the operative row.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R11.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R11(2).png",
              "label": "Extension attributes"
            },
            {
              "src": "assets/evidence/individual/R11(3).png",
              "label": "Content-limit attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O2",
            "O3"
          ],
          "finding": "The extension power loses its authority actor in the operative row.",
          "analysis": "“The training interval … may be extended” no longer says by the competent authority; Scope and Demand do not restore that actor. The rationale mentions the authority, but is not the operative permission. The content restriction and §3 references survive."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/14.png",
              "label": "Output and attributes"
            },
            {
              "src": "assets/evidence/whole/15.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Authority, permission and the content restriction survive.",
          "analysis": "Entry 1.13 gives MAY to the competent authority; 1.14 retains the non-waiver of §3(b) content. Both references are visible. Indentation alone is insufficient to establish the exact stored parent/exception relationships."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The permission row omits who may grant the extension.",
        "expected": "The competent authority may extend the interval; training content remains required."
      }
    },
    {
      "id": "R12",
      "section": 7,
      "title": "Use an explicit criterion as a control",
      "quote": "The operator shall retain each inspection record for three years after the date of the inspection.",
      "modes": [],
      "outcomes": [
        "O6"
      ],
      "logic": "Each record: retain until at least inspection date + three years.",
      "analysis": "This is a clear quantitative control case. The object, duration and start date should survive without reinterpretation.",
      "watch": "Check the basic fields even when no mismatch pattern is present.",
      "screenshot": "assets/evidence/individual/R12.png",
      "observedModes": [],
      "observedOutcomes": [],
      "finding": "Object, actor, three-year period and start date survive.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R12.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R12(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [],
          "outcomes": [],
          "finding": "Object, actor, three-year period and start date survive.",
          "analysis": "The row keeps each inspection record, the operator and three years after the inspection date. This is a successful quantitative control in this capture, not evidence that every simple requirement is reliable."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/16.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [],
          "outcomes": [],
          "finding": "Entry 1.15 preserves the quantitative control.",
          "analysis": "The three-year retention period remains tied to the date of each inspection. No relevant qualifier loss is visible in this row or its displayed fields."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "No visible defect: actor, records, period and start date survive.",
        "expected": "The operator retains each record for three years after its inspection date."
      }
    },
    {
      "id": "R13",
      "section": 7,
      "title": "Recognise an obligation and its request trigger",
      "quote": "The operator is required to make training records available to the competent authority on request.",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O1",
        "O2",
        "O6"
      ],
      "logic": "Authority requests → operator makes training records available.",
      "analysis": "“Is required to” is obligatory. Keep the record type, recipient and trigger. No response time is specified.",
      "watch": "Check force and condition; do not invent a deadline.",
      "screenshot": "assets/evidence/whole/16.png",
      "observedModes": [
        "M1",
        "M3"
      ],
      "observedOutcomes": [
        "O2"
      ],
      "finding": "The training-record request duty is absent from the 22 entries.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R13.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R13(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M1",
            "M3"
          ],
          "outcomes": [],
          "finding": "“Is required to” is recognised and the request trigger survives.",
          "analysis": "The row uses SHALL and retains the operator, training records, competent authority and on-request condition. A missing literal selector does not prevent force preservation in this capture."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/1.png",
              "label": "Complete input"
            },
            {
              "src": "assets/evidence/whole/16.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Content not extracted",
          "modes": [
            "M1",
            "M3"
          ],
          "outcomes": [
            "O2"
          ],
          "finding": "The training-record request duty is absent from the 22 entries.",
          "analysis": "The complete input includes this sentence. The output moves from inspection-record retention (1.15) to disinfection (1.16), and no other visible entry carries this duty. The isolated run retains it. These captures show omission and an input-context difference; they do not prove why it was skipped."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 1
      },
      "reviewSummary": {
        "problem": "The request-triggered training-record duty is absent from the full output.",
        "expected": "On the authority’s request, the operator makes training records available."
      }
    },
    {
      "id": "R14",
      "section": 8,
      "title": "Keep an unresolved reference explicit",
      "quote": "Disinfection must be carried out in accordance with Annex 2.",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O4"
      ],
      "logic": "Disinfection method → Annex 2; Annex 2 not supplied.",
      "analysis": "Retain the duty and unresolved reference. The test intentionally omits the annex. Missing method details require context, not invention.",
      "watch": "Check whether the annex is fabricated, ignored or correctly marked missing.",
      "screenshot": "assets/evidence/whole/17.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O3",
        "O6"
      ],
      "finding": "“Disinfection shall carry out” loses the passive action structure.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R14.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R14(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Review limitation",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Annex 2 is retained, but its contents are unavailable.",
          "analysis": "The visible duty still points to Annex 2. The green Verifiable label cannot establish compliance with an annex absent from the input. Rationale describes annex standards without supplied annex evidence; those claims are not an extracted legal criterion."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/17.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "“Disinfection shall carry out” loses the passive action structure.",
          "analysis": "Entry 1.16 makes Disinfection the subject of “carry out”, with no object, instead of something to be carried out. The Annex 2 reference survives. Its substantive method remains unresolved because the annex was not supplied."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "“Disinfection shall carry out” turns the action into an actor.",
        "expected": "Disinfection shall be carried out under Annex 2. Keep the unavailable annex unresolved."
      }
    },
    {
      "id": "R15",
      "section": 9,
      "title": "Preserve recommendation strength",
      "quote": "The operator should conduct additional refresher training after changes to working methods.",
      "modes": [
        "M1",
        "M3"
      ],
      "outcomes": [
        "O3",
        "O6"
      ],
      "logic": "Working methods change → additional refresher training recommended.",
      "analysis": "Preserve SHOULD and the change trigger. Do not silently turn the recommendation into a mandatory SHALL.",
      "watch": "Check modality strength rather than the presence of an accepted selector.",
      "screenshot": "assets/evidence/individual/R15.png",
      "observedModes": [
        "M1",
        "M3"
      ],
      "observedOutcomes": [],
      "finding": "SHOULD and the working-method change trigger survive.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R15.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R15(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M1",
            "M3"
          ],
          "outcomes": [],
          "finding": "SHOULD and the working-method change trigger survive.",
          "analysis": "The additional refresher training remains a recommendation after changes to working methods. No silent SHOULD-to-SHALL strengthening is visible."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/18.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M1",
            "M3"
          ],
          "outcomes": [],
          "finding": "The recommendation remains a recommendation.",
          "analysis": "Entry 1.17 retains the operator, additional refresher training, SHOULD and the change condition. This capture preserves both modality and applicability."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "No visible defect: SHOULD and its trigger survive.",
        "expected": "Refresher training after method changes remains a recommendation."
      }
    },
    {
      "id": "R16",
      "section": 10,
      "title": "Keep the combined discharge conditions",
      "quote": "When medicinal products have been added to bath treatment water and the water is discharged at locations other than the aquaculture facility, the discharge shall take place while the vessel is underway.",
      "modes": [
        "M3"
      ],
      "outcomes": [
        "O2",
        "O4",
        "O6"
      ],
      "logic": "Medicinal products added AND discharge away from facility → vessel underway during discharge.",
      "analysis": "Both conditions qualify the discharge. Vessel movement is the required concurrent state. The excerpt does not name a duty-holder or minimum speed.",
      "watch": "Check AND, simultaneous operation and Scope/Condition/Demand assignments.",
      "screenshot": "assets/evidence/whole/19.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [
        "O3"
      ],
      "finding": "The same condition reversal appears with the full input.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R16.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R16(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O3"
          ],
          "finding": "The row reverses the applicability condition; the Condition field stays correct.",
          "analysis": "Let A = medicinal products added and B = discharge away from the facility. The source is A AND B → underway. The row becomes NOT A OR NOT B → underway, the complement of the trigger. The adjacent Condition field keeps A AND B. This is a directly visible semantic reversal and row/field contradiction."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/19.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M3"
          ],
          "outcomes": [
            "O3"
          ],
          "finding": "The same condition reversal appears with the full input.",
          "analysis": "Entry 1.18 again applies the duty when medicines are not added OR discharge is at the facility. Condition still records medicines added AND discharge away. More surrounding text did not fix this error in the supplied run."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The row changes A AND B into NOT A OR NOT B. Condition is correct.",
        "expected": "Medicines added AND discharge away from the facility → discharge while underway."
      }
    },
    {
      "id": "R17",
      "section": 10,
      "title": "Carry the same discharge into the report",
      "quote": "Information regarding the time of discharge, geographic position, the site concerned, and the medicinal product involved shall be reported to the Norwegian Directorate of Fisheries.",
      "modes": [
        "M3"
      ],
      "outcomes": [
        "O2",
        "O4",
        "O5",
        "O6"
      ],
      "logic": "Same discharge → report time AND position AND site AND medicinal product to the named authority.",
      "analysis": "“The discharge” refers back to the preceding scenario. All four fields are required within that report. Preserve the named recipient.",
      "watch": "Check cross-sentence context and complete reporting content.",
      "screenshot": "assets/evidence/whole/20.png",
      "observedModes": [
        "M3"
      ],
      "observedOutcomes": [],
      "finding": "Reporting content is complete; the discharge relationship is not auditable.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R17.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R17(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Review limitation",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "All four report fields survive; cross-sentence applicability is not demonstrated.",
          "analysis": "Time, position, site, medicine and the Directorate of Fisheries are present. Condition is blank, but this isolated input does not contain the preceding discharge scenario. Its omission from the input cannot be treated as proof that the assistant lost supplied context."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/20.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Review limitation",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Reporting content is complete; the discharge relationship is not auditable.",
          "analysis": "Entry 1.19 keeps all four fields and the named recipient. The displayed Condition is blank and there is no visible relationship metadata binding “the discharge” to 1.18. This is a context-review gap; screenshots alone do not show whether an internal link exists."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "Report contents survive; the link to the preceding discharge is not visible.",
        "expected": "Bind all four report fields and the named recipient to the same discharge."
      }
    },
    {
      "id": "R18",
      "section": 10,
      "title": "Bind procedure to the same notification",
      "quote": "Notification of the discharge shall be submitted in the manner determined by the supervisory authority.",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O4"
      ],
      "logic": "Same discharge notification → authority-determined submission method.",
      "analysis": "The method is supplied by an external authoritative determination. The excerpt does not specify email, a platform or a deadline.",
      "watch": "Check the notification link and whether unsupported procedure details appear.",
      "screenshot": "assets/evidence/individual/R18.png",
      "observedModes": [
        "M2",
        "M3"
      ],
      "observedOutcomes": [
        "O3",
        "O6"
      ],
      "finding": "The notification becomes the actor submitting itself.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R18.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R18(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Observed change",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [
            "O3",
            "O6"
          ],
          "finding": "The notification becomes the actor submitting itself.",
          "analysis": "“Notification shall submit the notification” changes passive submission into an active Demand with Notification as Scope/actor. The authority-determined method remains. Original Not Verifiable and transformed Verifiable labels disagree without a supplied method resolving the gap."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/21.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M3"
          ],
          "outcomes": [],
          "finding": "Passive submission and the authority-determined method survive.",
          "analysis": "Entry 1.20 says notification shall be submitted in the manner determined by the authority. The visible duty is preserved. The external procedure itself is not supplied, so the Verifiable label is not evidence that the procedure has been checked."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "“Notification shall submit the notification” makes it submit itself.",
        "expected": "The notification shall be submitted by the authority-determined method."
      }
    },
    {
      "id": "R19",
      "section": 11,
      "title": "Preserve the assessment-to-measures relationship",
      "quote": "The risk assessment shall form the basis for systematic measures.",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O3",
        "O4",
        "O6"
      ],
      "logic": "Risk assessment → basis for systematic measures.",
      "analysis": "The requirement is a relationship between the assessment and the measures. Merely storing two unrelated objects loses that relationship.",
      "watch": "Check the “basis for” link and avoid substituting an invented measurable criterion.",
      "screenshot": "assets/evidence/individual/R19.png",
      "observedModes": [
        "M2"
      ],
      "observedOutcomes": [
        "O3"
      ],
      "finding": "The basis-for relationship survives; suggestions add documentation duties.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R19.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R19(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Unsupported suggestion",
          "modes": [
            "M2"
          ],
          "outcomes": [
            "O3"
          ],
          "finding": "The basis-for relationship survives; suggestions add documentation duties.",
          "analysis": "The transformed row still says the risk assessment shall form the basis for measures. Proposed replacements add documented/referenced links for each measure. These may be check-design ideas, but they are not stated source obligations and no adoption is visible."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/22.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Preserved in this capture",
          "modes": [
            "M2"
          ],
          "outcomes": [],
          "finding": "The same relationship is now labelled Verifiable.",
          "analysis": "Entry 1.21 keeps “form the basis for systematic measures”. The full-run label differs from the isolated warning. This demonstrates a captured status difference between input contexts, not repeat-run nondeterminism or proof of a changed legal duty."
        }
      },
      "selectedEvidence": {
        "batch": "individual",
        "index": 0
      },
      "reviewSummary": {
        "problem": "The row is preserved; suggestions add documentation and reference duties.",
        "expected": "Keep the assessment as the basis for measures. Separate extra check-design ideas."
      }
    },
    {
      "id": "R20",
      "section": 11,
      "title": "Distribute the shared duty over all three targets",
      "quote": "The best available knowledge shall be incorporated into the risk assessment, the selection of systematic measures, and monitoring activities.",
      "modes": [
        "M2",
        "M3"
      ],
      "outcomes": [
        "O2",
        "O3",
        "O4",
        "O5"
      ],
      "logic": "Knowledge in risk assessment AND measure selection AND monitoring.",
      "analysis": "One compound requirement or three linked children can both work. Each target must remain independently checkable, and all three must satisfy the duty.",
      "watch": "Check whether a single overall judgement hides a missing target.",
      "screenshot": "assets/evidence/whole/23.png",
      "observedModes": [
        "M2"
      ],
      "observedOutcomes": [
        "O3"
      ],
      "finding": "The row retains all targets; proposed knowledge sources narrow the source duty.",
      "evidence": {
        "individual": {
          "screens": [
            {
              "src": "assets/evidence/individual/R20.png",
              "label": "Output"
            },
            {
              "src": "assets/evidence/individual/R20(2).png",
              "label": "Attributes"
            }
          ],
          "status": "Status inconsistency",
          "modes": [
            "M2",
            "M3"
          ],
          "outcomes": [],
          "finding": "All three targets survive in one row; the split explanation is inconsistent.",
          "analysis": "Risk assessment, measure selection and monitoring are all present. A single compound requirement does not by itself lose meaning. The original is labelled Not Verifiable / split required, but the result remains one Verifiable row. Independent checks of all targets are still needed; target omission is not visible."
        },
        "whole": {
          "screens": [
            {
              "src": "assets/evidence/whole/23.png",
              "label": "Output and attributes"
            }
          ],
          "status": "Unsupported suggestion",
          "modes": [
            "M2"
          ],
          "outcomes": [
            "O3"
          ],
          "finding": "The row retains all targets; proposed knowledge sources narrow the source duty.",
          "analysis": "Entry 1.22 is now Not Verifiable. Suggestions replace best available knowledge with latest peer-reviewed literature, a recent risk-analysis report or an accredited expert panel. The source does not prescribe these exclusive proxies. They are proposed replacements, not adopted duties. Keeping the three targets in one row is not itself an observed failure."
        }
      },
      "selectedEvidence": {
        "batch": "whole",
        "index": 0
      },
      "reviewSummary": {
        "problem": "Suggestions narrow “best available knowledge” to prescribed source types.",
        "expected": "Keep best available knowledge in all three targets without inventing exclusive sources."
      }
    }
  ]
};
