/* Native scroll owns gesture physics and page snapping; the glass layers follow its position. */
(() => {
  const scenes=[...document.querySelectorAll('main > .scene')];
  const main=document.getElementById('main');
  const locale=window.BRIEFING_I18N;
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
  // Scene headings and their metadata in index.html are the chapter authority.
  const model=scenes.map(scene=>({id:scene.id,label:scene.dataset.sceneLabel,chapter:scene.dataset.chapter || scene.id,navLabel:scene.dataset.chapterLabel}));
  const nav=document.querySelector('.masthead nav');
  model.filter(item=>item.navLabel).forEach(item=>{
    const button=document.createElement('button');button.type='button';
    button.dataset.scene=item.id;button.setAttribute('aria-controls',item.id);button.textContent=item.navLabel;
    nav.append(button);
  });
  const byId=id=>document.getElementById(id);
  const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
  const renderedScroll=new WeakMap();
  let active=0,started=false,height=0,starts=[],overflow=[],stops=[],frame=0,settleTimer=0;
  let between=false,base=0,progress=0;
  let gesture=null,lastWheel=-Infinity,touchOrigin=null,destination=null;
  const gestureQuiet=220;
  // Keep native scrolling, but bound each gesture to content OR one adjacent page.
  function beginGesture(direction,target) {
    destination=null;
    render();
    const top=starts[active],bottom=top+overflow[active],position=main.scrollTop;
    gesture={min:top,max:bottom};
    if(nestedScroll(target,direction)) gesture={min:position,max:position};
    else if(direction>0 && position>=bottom-2 && active<scenes.length-1) gesture.max=starts[active+1];
    else if(direction<0 && position<=top+2 && active>0) gesture.min=starts[active-1]+overflow[active-1];
  }
  function containGesture() {
    if(!gesture) return;
    const top=clamp(main.scrollTop,gesture.min,gesture.max);
    if(Math.abs(top-main.scrollTop)>.5) main.scrollTo({top,behavior:'instant'});
  }
  function wheel(event) {
    if(event.ctrlKey || event.metaKey || Math.abs(event.deltaX)>Math.abs(event.deltaY) || !event.deltaY) return;
    const direction=Math.sign(event.deltaY);
    if(event.timeStamp-lastWheel>gestureQuiet || !gesture) beginGesture(direction,event.target);
    lastWheel=event.timeStamp;
    if(nestedScroll(event.target,direction)) return;
    const delta=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?height:1);
    const next=main.scrollTop+delta;
    if(next<gesture.min || next>gesture.max) {
      event.preventDefault();
      main.scrollTo({top:clamp(next,gesture.min,gesture.max),behavior:'instant'});
      scheduleRender();
    }
  }
  function positionContent(scene,top) {
    renderedScroll.set(scene,top);
    scene.scrollTop=top;
  }
  function controls() {
    const scene=scenes[active];
    const text=(id,value)=>{if(byId(id).textContent!==value) byId(id).textContent=value;};
    text('page-progress',`${active+1} / ${scenes.length}`);
    text('page-label',locale.t(model[active].label));
    byId('page-prev').disabled=active===0;
    byId('page-next').disabled=active===scenes.length-1;
    document.querySelectorAll('.masthead nav [data-scene]').forEach(button=>{
      if(button.dataset.scene===model[active].chapter) button.setAttribute('aria-current','page');
      else button.removeAttribute('aria-current');
    });
  }
  function render() {
    frame=0;
    if(!height) return;
    const position=main.scrollTop;
    base=0;
    while(base<scenes.length-1 && position>=starts[base+1]-.5) base++;
    progress=base<scenes.length-1?clamp((position-starts[base]-overflow[base])/height,0,1):0;
    between=progress>.001 && progress<.999;
    const next=progress>=.5?base+1:base;
    const previous=scenes[active];
    active=next;
    main.classList.toggle('is-transitioning',between);
    scenes.forEach((scene,index)=>{
      const visible=reduced.matches?index===active:index===base || (progress>0 && index===base+1);
      scene.classList.toggle('is-visible',visible);
      scene.classList.toggle('is-active',index===active);
      scene.inert=index!==active;
      scene.setAttribute('aria-hidden',String(index!==active));
      if(visible) {
        const covering=index===base+1 && progress>0;
        scene.style.zIndex=covering?'2':'1';
        scene.style.transform=covering && !reduced.matches?`translateY(${(1-progress)*height}px)`:'none';
        scene.style.opacity=String(reduced.matches?1:covering?.65+.35*progress:1-.7*progress);
      }
    });
    positionContent(scenes[base],clamp(position-starts[base],0,overflow[base]));
    if(progress>0) positionContent(scenes[base+1],0);
    if(previous!==scenes[active] && previous.contains(document.activeElement)) scenes[active].focus({preventScroll:true});
    if(destination===active && !between) destination=null;
    if(destination===null && window.location.hash!==`#${scenes[active].id}`) {
      try{history.replaceState(null,'',`#${scenes[active].id}`);}catch(_){}
    }
    controls();
  }
  function scheduleRender() {
    if(!frame) frame=requestAnimationFrame(render);
  }
  function layout() {
    if(!started) return;
    const local=starts.length?clamp(main.scrollTop-starts[active],0,overflow[active]):0;
    const nextHeight=main.clientHeight;
    if(!nextHeight) return;
    main.style.setProperty('--deck-height',`${nextHeight}px`);
    const nextOverflow=scenes.map(scene=>Math.max(0,scene.scrollHeight-scene.clientHeight));
    const changed=height!==nextHeight || nextOverflow.some((value,index)=>value!==overflow[index]);
    if(changed) gesture=null;
    height=nextHeight;
    overflow=nextOverflow;
    let offset=0;
    starts=stops.map((stop,index)=>{
      stop.style.height=`${height+overflow[index]}px`;
      const start=offset;
      offset+=height+overflow[index];
      return start;
    });
    if(changed) main.scrollTo({top:starts[active]+Math.min(local,overflow[active]),behavior:'instant'});
    render();
  }
  function go(target,{animate=true,entry='start',historyMode='push'}={}) {
    const next=typeof target==='string'?scenes.findIndex(scene=>scene.id===target):target;
    if(!Number.isInteger(next) || next<0 || next>=scenes.length || !height) return false;
    gesture=null;lastWheel=-Infinity;
    const moved=next!==active;
    destination=next;
    if(historyMode!=='none' && window.location.hash!==`#${scenes[next].id}`) {
      try{history[historyMode==='push'?'pushState':'replaceState'](null,'',`#${scenes[next].id}`);}catch(_){}
    }
    main.scrollTo({top:starts[next]+(entry==='end'?overflow[next]:0),behavior:animate && !reduced.matches?'smooth':'instant'});
    scheduleRender();
    return moved;
  }
  function settle() {
    render();
    if(!between) return;
    // Mandatory CSS snapping is primary; finish any fractional edge left by a host scroll.
    let top=progress>=.5?starts[base+1]:starts[base]+overflow[base];
    if(gesture) top=clamp(top,gesture.min,gesture.max);
    main.scrollTo({top,behavior:reduced.matches?'instant':'smooth'});
    scheduleRender();
  }
  function nestedScroll(target,direction) {
    for(let node=target;node && node!==scenes[active] && node!==main;node=node.parentElement) {
      if(/auto|scroll/.test(getComputedStyle(node).overflowY) && node.scrollHeight>node.clientHeight+2) {
        if(direction>0 && node.scrollTop+node.clientHeight<node.scrollHeight-2) return true;
        if(direction<0 && node.scrollTop>2) return true;
      }
    }
    return false;
  }
  function start() {
    if(started) return;
    const initial=window.location.hash.slice(1);
    document.documentElement.classList.add('deck-ready');
    const stage=document.createElement('div');
    stage.id='deck-stage';
    const track=document.createElement('div');
    track.className='deck-track';
    track.setAttribute('aria-hidden','true');
    stops=scenes.map(scene=>{
      scene.hidden=false;
      scene.tabIndex=-1;
      scene.addEventListener('scroll',()=>{
        if(between || scene!==scenes[active]) return;
        // Ignore our own delayed scroll event even if native scrolling has already moved ahead.
        if(Math.abs(scene.scrollTop-(renderedScroll.get(scene) || 0))<=1) return;
        const expected=clamp(main.scrollTop-starts[active],0,overflow[active]);
        // Keyboard focus can scroll an overflow-hidden scene. Keep the native track in sync.
        if(Math.abs(scene.scrollTop-expected)>1) {
          main.scrollTo({top:starts[active]+scene.scrollTop,behavior:'instant'});
          scheduleRender();
        }
      },{passive:true});
      stage.append(scene);
      const stop=document.createElement('div');
      stop.className='deck-stop';
      track.append(stop);
      return stop;
    });
    main.append(stage,track);
    started=true;
    layout();
    go(scenes.some(scene=>scene.id===initial)?initial:0,{animate:false,historyMode:'replace'});
    render();
    main.addEventListener('scroll',()=>{
      containGesture();
      scheduleRender();
      if(!('onscrollend' in main)) {
        clearTimeout(settleTimer);
        settleTimer=setTimeout(settle,180);
      }
    },{passive:true});
    main.addEventListener('scrollend',settle);
    main.addEventListener('wheel',wheel,{passive:false});
    main.addEventListener('pointerdown',()=>{gesture=null;lastWheel=-Infinity;destination=null;},{passive:true});
    main.addEventListener('touchstart',event=>{
      gesture=null;
      touchOrigin=event.touches.length===1?{x:event.touches[0].clientX,y:event.touches[0].clientY}:null;
    },{passive:true});
    main.addEventListener('touchmove',event=>{
      if(!touchOrigin || gesture || event.touches.length!==1) return;
      const dx=touchOrigin.x-event.touches[0].clientX,dy=touchOrigin.y-event.touches[0].clientY;
      if(Math.abs(dy)>4 && Math.abs(dy)>Math.abs(dx)) beginGesture(Math.sign(dy),event.target);
    },{passive:true});
    main.addEventListener('touchend',()=>{touchOrigin=null;},{passive:true});
    main.addEventListener('touchcancel',()=>{touchOrigin=null;},{passive:true});
    document.addEventListener('click',event=>{
      const control=event.target.closest('[data-scene]');
      if(!control || event.ctrlKey || event.metaKey || event.altKey || event.button>0) return;
      event.preventDefault();
      go(control.dataset.scene);
    });
    byId('page-prev').addEventListener('click',()=>go(active-1,{entry:'end'}));
    byId('page-next').addEventListener('click',()=>go(active+1));
    document.addEventListener('keydown',event=>{
      if(event.defaultPrevented || event.ctrlKey || event.altKey || event.metaKey || event.target.closest('input,select,textarea,[contenteditable="true"],[role="tablist"]')) return;
      const steps={ArrowDown:1,ArrowUp:-1,ArrowRight:1,ArrowLeft:-1,PageDown:1,PageUp:-1};
      let direction=steps[event.key];
      if(event.key===' ' && !event.target.closest('button,a,summary')) direction=event.shiftKey?-1:1;
      if(!direction) return;
      if(event.key==='ArrowDown' || event.key==='ArrowUp') {
        if(nestedScroll(event.target,direction)) return;
        const local=main.scrollTop-starts[active];
        if(!between && (direction>0?local<overflow[active]-2:local>2)) {
          event.preventDefault();
          gesture=null;
          main.scrollTo({top:starts[active]+clamp(local+direction*60,0,overflow[active]),behavior:'instant'});
          scheduleRender();
          return;
        }
        if(event.repeat) {event.preventDefault();return;}
      }
      event.preventDefault();
      go(active+direction,{entry:direction<0?'end':'start'});
    });
    window.addEventListener('resize',layout,{passive:true});
    const followHistory=()=>go(window.location.hash.slice(1),{animate:false,historyMode:'none'});
    window.addEventListener('hashchange',followHistory);
    window.addEventListener('popstate',followHistory);
    reduced.addEventListener('change',()=>{if(reduced.matches) settle();scheduleRender();});
    document.addEventListener('visibilitychange',()=>{if(document.hidden) go(active,{animate:false});});
    if(window.ResizeObserver) {
      const observer=new ResizeObserver(layout);
      observer.observe(main);
      scenes.forEach(scene=>observer.observe(scene.querySelector('.scene-content')));
    }
    if(document.fonts) document.fonts.ready.then(layout);
  }
  window.BRIEFING_DECK={start,go,refresh:layout,get index(){return active;}};
})();
