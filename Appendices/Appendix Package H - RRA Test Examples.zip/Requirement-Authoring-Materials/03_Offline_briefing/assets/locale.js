/* English-only handoff; language preferences from other editions do not apply. */
window.BRIEFING_I18N = Object.freeze({language: 'en', t: text => text, apply() {}, content: source => source});
