# 1. Historical local verification with a real PDF

Date: 2026-09-23. This is local diagnosis, not acceptance of a company upstream interface or a measurement of human-review cost. The method lineup and rules below describe that historical run, not the current implementation.

## 1.1 Materials and reproducible input

- `tests/fixtures/test.pdf`: the real 30-page ASC Salmon Audit Manual. SHA-256: `911b716d6e4f9aacc1e0c7999dbcf1e009f08c3b322269c748d867006521e76d`, matching the original in the former `05` project, which was not changed.
- `tests/fixtures/test-input-partial.json`: read-only conversion of `../05_Working area of requirements side/project-support/validation/product-readiness-20260912/quality/after-v4-pdf/asc-audit/candidate.json`. Original candidate hash: `e3823f29f46427f018d2a0b31c37b59946b6eb5ad9014a41933b677e7337cea4`; converted hash: `4209b5684a49d9cbfaf07b8231c0dee496da6fc23199bfde668babd77265b72b`. It covers physical pages 1 through 3 and is itself marked `partial`; the remaining 27 pages were not processed. Conversion maps block types, existing coordinates and table row/column text without inventing cell positions.
- The former `05` visual-review annotation `legacy-layout/system2/gold/requirements/annotations/audit-manual-p001-p003.json` has 79 fragments from the first three pages. It is a Requirement annotation, not complete PDF-extraction truth.

Run the retained candidate with:

```bash
uv run python -m pdf_validator \
  --pdf tests/fixtures/test.pdf \
  --json tests/fixtures/test-input-partial.json \
  --depth 3 \
  --output project-support/validation/test-partial.report.json
```

The retained historical report uses `local-evidence/7`; see `test-partial.report.json` and `test-partial.report.md`. Running today's implementation may produce different results. The PDF and `05` JSON were read only. The sample PDF, converted JSON and reports were excluded by `.gitignore`.

## 1.2 Observations

- The historical candidate's first three pages contain 3 tables, 81 rows and 182 nonempty cells with row/column indices but no page-local cell coordinates. At Depth 3, pdfplumber found the same number of table rows. The program localized questions to 28 rows and identified 2 instances of table text repeated in separate body blocks. The 27 missing-page findings correspond to the candidate's 27 explicitly unprocessed pages; they do not show that a parser skipped pages it was supposed to process.
- The flagged 28/81 rows are 34.6%; flagged candidate table text was 1,186/3,422 tokens, about 34.7%. This estimates text in candidate review regions, not actual review time or a business pass rate. Row differences included merged-cell anchors and text split across rows, without individual human adjudication.
- Using the 79 visually checked fragments as temporary input produced no fragment-text differences at Depth 1 or 2. The 22 `pdf_region_missing_from_json` findings concerned repeated headers and `Footnote` labels absent from the Requirement annotation. That annotation is unsuitable as complete extraction ground truth.
- Changing `1,500` to `15,000` in `seg-p001-r211-metadata` was missed by the old high paragraph-similarity rule. After checking critical tokens individually, Depth 1 and 2 located the block and reported `critical_text_difference`. Insufficient independent evidence kept the outcome `review_required`. A regression was added to `tests/test_validator.py`.

## 1.3 Conclusion and next checkpoint

Row-level review of real multicolumn tables is more specific than whole-table review, but methods sharing the PDF text layer can share errors. The 34.7% figure does not establish a business workload target. A later evaluation needs current company JSON paired with human-approved samples to check adaptation, row false positives and critical missed errors, then measure actual content reviewed and time at each depth. Correctness probability and business acceptance remain `UNMEASURED`.

## 1.4 Historical depth comparison on the same PDF

`validate(test.pdf, test-input-partial.json, Depth)` ran sequentially on the same machine. Methods, findings and scores below concern only the three covered pages; wall-clock time covers the entire 30-page file. Timings were not repeated and support only rough comparisons.

| Requested depth | Methods on first three pages | Evidence families | Findings on first three pages | Support scores on first three pages | Full-run time |
| ---: | --- | --- | --- | --- | ---: |
| 1 | Poppler | Text layer | 3 tables without located cells; 2 duplicated table-text blocks | 97.8 / 97.3 / 98.9 | 0.86 s |
| 2 | Poppler, Tesseract | Text layer, visual OCR | Same as Depth 1 | 97.8 / 97.3 / 98.9 | 3.92 s |
| 3 | Poppler, Tesseract, pdfplumber | Text layer, visual OCR | 28 specific row differences; 2 duplicates | 97.7 / 96.0 / 97.6 | 4.36 s |
| 4 | The preceding three plus pypdf | Text layer, visual OCR | Same types and counts as Depth 3 | 97.6 / 96.0 / 97.5 | 4.49 s |
| 5 | Same as Depth 4; only four methods | Text layer, visual OCR | Depth 4 findings plus 3 insufficient-depth findings | 97.5 / 95.9 / 97.4 | 4.40 s |

The candidate declared PDFium upstream, so the matching review method was excluded. Depth 5 could not obtain a fifth method and reported `requested_depth_unmet` per page. Depth 3 provided finer row localization, not proof of 28 genuine errors; span and cross-row splitting differences were included. Depth 4 added no finding type or evidence family here. Whole-document support was about 2.8 to 2.9, mainly because the historical candidate deliberately lacked 27 pages; it does not measure the current company parser. Without human labels, this is not a basis for a business default depth or automatic acceptance threshold.

## 1.5 Numeric perturbation in a real table

A temporary candidate copy changed `≥ 70%` to `≥ 700%` in the audit text on PDF page 3, table row 6. The PDF, former `05` project and fixtures were unchanged. That row was not flagged in the original sample. Depth 1/2 added `table_critical_token_difference`. Depth 3 added row 6's `table_row_alignment_disagreement` alongside the table-level numeric finding, at `[192.91, 320.87, 557.86, 337.07]` PDF points. Before the rule repair, Depth 1's table score changed 92.9 to 92.8 and the page score stayed 98.9. With critical numbers scored separately, the same perturbation changed the table score 92.9 to 86.6 and the page score 98.9 to 97.9. These remain support scores under provisional rules, not correctness probabilities or business missed-error rates.
