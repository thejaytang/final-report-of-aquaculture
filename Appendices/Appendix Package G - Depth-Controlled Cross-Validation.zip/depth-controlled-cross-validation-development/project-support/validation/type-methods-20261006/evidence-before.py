"""Four local extraction paths and a reserved model-review layer; absent and overlapping observations stay explicit."""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
import io
from importlib.metadata import version
from pathlib import Path
import subprocess
from time import perf_counter
from tempfile import TemporaryDirectory

from .input import Box


METHODS = ("poppler", "tesseract", "pdfplumber", "pdfium")
FAMILIES = {
    "poppler": "embedded_text",
    "tesseract": "visual_ocr",
    "pdfplumber": "embedded_text",
    "pdfium": "embedded_text",
    "pypdf": "embedded_text",
}
ALIASES = {
    "poppler": {"poppler", "pdftotext"},
    "tesseract": {"tesseract", "tesseract-ocr"},
    "pdfplumber": {"pdfplumber", "pdfminer", "pdfminer.six"},
    "pdfium": {"pdfium", "pypdfium2"},
    "pypdf": {"pypdf", "pypdf2"},
}


@dataclass(frozen=True)
class Word:
    text: str
    box: Box


@dataclass(frozen=True)
class Line:
    text: str
    box: Box
    font_size: float | None = None
    bold: bool | None = None


@dataclass
class Observation:
    method: str
    family: str
    page_index: int
    status: str
    text: str = ""
    words: list[Word] = field(default_factory=list)
    lines: list[Line] = field(default_factory=list)
    tables: list[Box] = field(default_factory=list)
    images: list[Box] = field(default_factory=list)
    error: str | None = None
    shared_with_upstream: bool = False
    family_overlaps_upstream: bool = False
    elapsed_seconds: float = 0.0
    table_rows: list[list[tuple[Box, tuple[str, ...]]]] = field(default_factory=list)

    def has_evidence(self) -> bool:
        return bool(self.text.strip() or self.words or self.tables or self.images)


def page_sizes(path: Path) -> list[tuple[float, float]]:
    import pypdfium2 as pdfium

    try:
        pdf = pdfium.PdfDocument(str(path))
        try:
            if len(pdf) == 0:
                raise ValueError("PDF has no pages")
            return [tuple(float(v) for v in pdf[i].get_size()) for i in range(len(pdf))]
        finally:
            pdf.close()
    except Exception as exc:
        raise ValueError(f"cannot open PDF: {exc}") from exc


def _command(args: list[str], timeout: int = 60) -> bytes:
    try:
        return subprocess.run(args, capture_output=True, check=True, timeout=timeout).stdout
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"{args[0]} unavailable or failed: {type(exc).__name__}") from exc


def _tsv_rows(raw: bytes) -> list[dict[str, str]]:
    return list(csv.DictReader(io.StringIO(raw.decode("utf-8", errors="replace")), delimiter="\t"))


def _box(row: dict[str, str], x: float = 1.0, y: float = 1.0) -> Box:
    left, top, width, height = (float(row[k]) for k in ("left", "top", "width", "height"))
    return Box(left * x, top * y, (left + width) * x, (top + height) * y)


def _group_words(words: list[tuple[tuple[str, ...], Word]]) -> list[Line]:
    groups: dict[tuple[str, ...], list[Word]] = {}
    for key, word in words:
        groups.setdefault(key, []).append(word)
    lines = []
    for group in groups.values():
        b = Box(min(w.box.x0 for w in group), min(w.box.y0 for w in group),
                max(w.box.x1 for w in group), max(w.box.y1 for w in group))
        lines.append(Line(" ".join(w.text for w in group), b))
    return sorted(lines, key=lambda line: (line.box.y0, line.box.x0))


def _poppler(path: Path, index: int) -> Observation:
    rows = _tsv_rows(_command(["pdftotext", "-f", str(index + 1), "-l", str(index + 1),
                               "-tsv", str(path), "-"]))
    keyed = []
    for row in rows:
        if row.get("level") == "5" and row.get("text", "").strip():
            word = Word(row["text"], _box(row))
            keyed.append(((row["block_num"], row["par_num"], row["line_num"]), word))
    words = [w for _, w in keyed]
    lines = _group_words(keyed)
    return Observation("poppler", FAMILIES["poppler"], index, "ok" if words else "empty",
                       "\n".join(line.text for line in lines), words, lines)


def _tesseract(path: Path, index: int, size: tuple[float, float], language: str) -> Observation:
    import pypdfium2 as pdfium

    with TemporaryDirectory(prefix="pdf-validator-ocr-") as temp:
        image = Path(temp) / "page.png"
        pdf = pdfium.PdfDocument(str(path))
        try:
            page = pdf[index]
            bitmap = page.render(scale=2)
            bitmap.to_pil().save(image)
            width_px, height_px = bitmap.width, bitmap.height
        finally:
            pdf.close()
        raw = _command(["tesseract", str(image), "stdout", "-l", language, "tsv"], timeout=120)
    sx, sy = size[0] / width_px, size[1] / height_px
    keyed = []
    for row in _tsv_rows(raw):
        if row.get("level") == "5" and row.get("text", "").strip():
            word = Word(row["text"], _box(row, sx, sy))
            keyed.append(((row["block_num"], row["par_num"], row["line_num"]), word))
    words = [w for _, w in keyed]
    lines = _group_words(keyed)
    return Observation("tesseract", FAMILIES["tesseract"], index,
                       "ok" if words else "empty", "\n".join(line.text for line in lines), words, lines)


def _pdfplumber(path: Path, index: int) -> Observation:
    import pdfplumber

    with pdfplumber.open(path) as pdf:
        page = pdf.pages[index]
        words = [Word(w["text"], Box(w["x0"], w["top"], w["x1"], w["bottom"]))
                 for w in page.extract_words() if w["text"].strip()]
        lines = []
        for item in page.extract_text_lines():
            box = Box(item["x0"], item["top"], item["x1"], item["bottom"])
            chars = item.get("chars", [])
            font_size = max((float(c["size"]) for c in chars), default=None)
            bold = any("bold" in c.get("fontname", "").lower() for c in chars)
            lines.append(Line(item["text"], box, font_size, bold))
        try:
            found_tables = page.find_tables()
            tables = [Box(*table.bbox) for table in found_tables]
            table_rows = [[(Box(*row.bbox), tuple(cell or "" for cell in cells))
                           for row, cells in zip(table.rows, table.extract())]
                          for table in found_tables]
            table_error = None
        except Exception as exc:
            tables, table_rows, table_error = [], [], f"table detection failed: {type(exc).__name__}"
        images = [Box(img["x0"], img["top"], img["x1"], img["bottom"])
                  for img in page.images if all(k in img for k in ("x0", "top", "x1", "bottom"))]
    return Observation("pdfplumber", FAMILIES["pdfplumber"], index,
                       "ok" if words or tables or images else "empty",
                       "\n".join(line.text for line in lines), words, lines, tables, images, table_error,
                       table_rows=table_rows)


def _pdfium(path: Path, index: int) -> Observation:
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(str(path))
    try:
        page = pdf[index]
        textpage = page.get_textpage()
        text = textpage.get_text_range()
        # PDFium character indices are used directly; whitespace closes each word.
        words, chars, boxes = [], [], []
        def flush():
            if chars and boxes:
                words.append(Word("".join(chars), Box(min(b.x0 for b in boxes), min(b.y0 for b in boxes),
                                                     max(b.x1 for b in boxes), max(b.y1 for b in boxes))))
            chars.clear()
            boxes.clear()
        height = page.get_height()
        for i in range(textpage.count_chars()):
            char = textpage.get_text_range(i, 1)
            if not char or char.isspace():
                flush()
                continue
            left, bottom, right, top = textpage.get_charbox(i)
            if right > left and top > bottom:
                chars.append(char)
                boxes.append(Box(left, height - top, right, height - bottom))
        flush()
        lines = _group_words([((str(round(w.box.y0 / 5)),), w) for w in words])
    finally:
        pdf.close()
    return Observation("pdfium", FAMILIES["pdfium"], index, "ok" if text.strip() else "empty",
                       text, words, lines)


def selected_methods(depth: int, native_text_present: bool, document_type: str = "general") -> tuple[str, ...]:
    if type(depth) is not int or not 1 <= depth <= 5:
        raise ValueError("Depth must be an integer from 1 to 5")
    order = {
        "product_certificate": ("poppler", "pdfium", "pdfplumber", "tesseract"),
        "user_manual": ("poppler", "pdfplumber", "pdfium", "tesseract"),
        "deployment_report": ("pdfplumber", "poppler", "pdfium", "tesseract"),
        "facility_certificate": ("pdfplumber", "poppler", "pdfium", "tesseract"),
    }.get(document_type, METHODS)
    if not native_text_present:
        order = ("tesseract",) + tuple(name for name in order if name != "tesseract")
    return order[:depth]


def read_page(path: Path, index: int, size: tuple[float, float], depth: int,
              upstream_engines: tuple[str, ...], language: str = "eng", document_type: str = "general") -> list[Observation]:
    probe_start = perf_counter()
    probe = None
    try:
        probe = _pdfium(path, index)
        native_text_present = bool(probe.text.strip())
    except Exception:
        native_text_present = False
    probe_elapsed = perf_counter() - probe_start
    observations = []
    engine_names = {e.strip().lower() for e in upstream_engines}
    upstream_families = {FAMILIES[name] for name in METHODS if ALIASES[name] & engine_names}
    available = [name for name in selected_methods(5, native_text_present, document_type)
                 if not ALIASES[name] & engine_names]
    for name in available[:min(depth, 4)]:
        started = perf_counter()
        try:
            obs = {
                "poppler": lambda: _poppler(path, index),
                "tesseract": lambda: _tesseract(path, index, size, language),
                "pdfplumber": lambda: _pdfplumber(path, index),
                "pdfium": lambda: probe if probe is not None else _pdfium(path, index),
            }[name]()
        except Exception as exc:
            obs = Observation(name, FAMILIES[name], index, "error", error=f"{type(exc).__name__}: {exc}")
        obs.elapsed_seconds = round(perf_counter() - started + (probe_elapsed if name == "pdfium" else 0), 6)
        obs.shared_with_upstream = bool(ALIASES[name] & engine_names)
        obs.family_overlaps_upstream = obs.family in upstream_families
        observations.append(obs)
    if depth == 5:
        observations.append(Observation("other_model", "model_review", index, "not_implemented",
                                        error="Depth 5 reserves a different model from upstream; no model is called."))
    return observations


def versions() -> dict[str, str]:
    found = {}
    for name, package in (("pdfplumber", "pdfplumber"), ("pdfium", "pypdfium2"),
                          ("pypdf", "pypdf")):
        found[name] = version(package)
    for name, command in (("poppler", ["pdftotext", "-v"]),
                          ("tesseract", ["tesseract", "--version"])):
        try:
            result = subprocess.run(command, capture_output=True, timeout=5, check=True)
            found[name] = (result.stdout or result.stderr).decode(errors="replace").splitlines()[0]
        except (OSError, subprocess.SubprocessError, IndexError):
            found[name] = "unavailable"
    return found
