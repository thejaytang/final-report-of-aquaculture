# PDF extraction validation

- Result: **failed**
- Evidence support score: **2.9 / 100**
- Pages: 30
- Requested Depth: 3
- Calibrated probability of correctness: unavailable (no independently labeled data)

| PDF page | Accuracy | Structure | Tables | Formula/Figures | Cleanliness | Total | Status | Methods | Findings |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| 1 | 98.3 | not_applicable | 91.6 | not_applicable | 100.0 | 97.7 | review_required | 3 | 11 |
| 2 | 97.4 | not_applicable | 84.4 | not_applicable | 100.0 | 96.0 | review_required | 3 | 9 |
| 3 | 100.0 | not_applicable | 84.3 | not_applicable | 100.0 | 97.6 | review_required | 3 | 10 |
| 4 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 5 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 6 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 7 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 8 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 9 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 10 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 11 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 12 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 13 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 14 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 15 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 16 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 17 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 18 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 19 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 20 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 21 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 22 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 23 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 24 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 25 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 26 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 27 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 28 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 29 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |
| 30 | 0.0 | unverified | unverified | unverified | unverified | 0.0 | failed | 1 | 1 |

## Document dimensions

| Dimension | Score | Coverage | State |
| --- | ---: | ---: | --- |
| accuracy | 6.7 | 1.0 | assessed |
| structure | None | 0.0 | unverified |
| tables | 1.4 | 0.016 | partial |
| formula_figures | None | 0.0 | unverified |
| cleanliness | 0.2 | 0.002 | partial |

## Located findings

- **F00001**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r1c1; bbox: [50.895, 92.45999999999998, 557.86499875, 101.21999999999997]
- **F00002**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r3c1; bbox: [50.895, 139.1400033333333, 557.86499875, 145.64000000000004]
- **F00003**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r4c1; bbox: [50.895, 145.64000000000004, 557.86499875, 151.87999999999994]
- **F00004**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r15c0, r15c1, r15c2, r15c3; bbox: [50.895, 348.34998999999993, 557.86499875, 401.48867]
- **F00005**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r16c1, r16c2, r16c3; bbox: [192.9114285714286, 364.55000500000006, 557.86499875, 380.74999]
- **F00006**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r18c1; bbox: [50.895, 401.48867, 557.86499875, 408.00999]
- **F00007**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r19c1; bbox: [50.895, 408.00999, 557.86499875, 414.490005]
- **F00008**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r23c0, r23c1, r23c2; bbox: [50.895, 497.0500025, 557.86499875, 705.7600033333333]
- **F00009**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r27c1, r27c2, r27c3; bbox: [192.9114285714286, 588.640005, 557.86499875, 617.920005]
- **F00010**, PDF page 1: tables / table_row_alignment_disagreement / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, r31c0, r31c2; bbox: [50.895, 705.7600033333333, 557.86499875, 714.5599833333334]
- **F00011**, PDF page 1: accuracy / duplicate_table_content / major; upstream IDs: block-e7ee66d7e64a15c05f65e0d4, block-83935f631842960e649da9c7; bbox: [376.5580139160156, 660.4167938232422, 557.5612182617188, 664.5495986938477]
- **F00012**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r1c0, r1c1, r1c2; bbox: [50.9, 173.83999999999997, 557.8628557142857, 398.48867]
- **F00013**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r5c1, r5c2, r5c3; bbox: [192.9114285714286, 265.39999000000006, 557.8628557142857, 286.18998999999997]
- **F00014**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r7c1, r7c2, r7c3; bbox: [192.9114285714286, 306.95000500000003, 557.8628557142857, 327.710005]
- **F00015**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r13c0, r13c1, r13c2, r13c3; bbox: [50.9, 425.5499933333333, 557.8628557142857, 537.8320033333334]
- **F00016**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r15c1, r15c2, r15c3; bbox: [192.9114285714286, 467.05000500000006, 557.8628557142857, 487.81000500000005]
- **F00017**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r18c0, r18c2; bbox: [50.9, 537.8320033333334, 557.8628557142857, 546.6600033333334]
- **F00018**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r19c0, r19c1, r19c2, r19c3; bbox: [50.9, 546.6600033333334, 557.8628557142857, 617.4199833333333]
- **F00019**, PDF page 2: tables / table_row_alignment_disagreement / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, r21c1, r21c2, r21c3; bbox: [192.9114285714286, 596.6800049999999, 557.8628557142857, 617.4199833333333]
- **F00020**, PDF page 2: accuracy / duplicate_table_content / major; upstream IDs: block-ed4a9b5c5a6b3d2d0b4391a4, block-56f8bb71b79a9b6564de9369; bbox: [376.6012268066406, 333.443603515625, 557.375244140625, 337.6195983886719]
- **F00021**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r0c1; bbox: [50.89714285714286, 99.64000000000003, 557.86499875, 106.14000000000004]
- **F00022**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r10c0, r10c2; bbox: [50.89714285714286, 416.3899933333333, 557.86499875, 425.17000500000006]
- **F00023**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r12c0, r12c2; bbox: [50.89714285714286, 433.93000500000005, 557.86499875, 442.70999333333333]
- **F00024**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r13c0, r13c1, r13c2, r13c3; bbox: [50.89714285714286, 442.70999333333333, 557.86499875, 489.72999000000004]
- **F00025**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r15c0, r15c1, r15c2, r15c3; bbox: [50.89714285714286, 489.72999000000004, 557.86499875, 569.0600033333334]
- **F00026**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r16c1, r16c2, r16c3; bbox: [192.91333333333336, 519.0100050000001, 557.86499875, 548.319975]
- **F00027**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r20c0, r20c2; bbox: [50.89714285714286, 589.600005, 557.86499875, 598.360005]
- **F00028**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r22c0, r22c1, r22c2, r22c3; bbox: [50.89714285714286, 616.6200033333333, 557.86499875, 682.8400033333334]
- **F00029**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r23c1, r23c2, r23c3; bbox: [192.91333333333336, 645.879975, 557.86499875, 664.360005]
- **F00030**, PDF page 3: tables / table_row_alignment_disagreement / major; upstream IDs: block-672017a57cc898b8ecc61e05, r25c0, r25c2; bbox: [50.89714285714286, 682.8400033333334, 557.86499875, 691.6400033333333]
- **F00031**, PDF page 4: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00032**, PDF page 5: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00033**, PDF page 6: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00034**, PDF page 7: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00035**, PDF page 8: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00036**, PDF page 9: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00037**, PDF page 10: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00038**, PDF page 11: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00039**, PDF page 12: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00040**, PDF page 13: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00041**, PDF page 14: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00042**, PDF page 15: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00043**, PDF page 16: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00044**, PDF page 17: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00045**, PDF page 18: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00046**, PDF page 19: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00047**, PDF page 20: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00048**, PDF page 21: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00049**, PDF page 22: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00050**, PDF page 23: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00051**, PDF page 24: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00052**, PDF page 25: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00053**, PDF page 26: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00054**, PDF page 27: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00055**, PDF page 28: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00056**, PDF page 29: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None
- **F00057**, PDF page 30: accuracy / missing_pdf_page_in_json / critical; upstream IDs: none; bbox: None

Scores represent evidence support, not a proven probability of correctness.
