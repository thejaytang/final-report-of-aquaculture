# PDF extraction validation

- Result: **review_required**
- Evidence support score: **90.8 / 100**
- Pages: 1
- Requested Depth: 1
- Document type / scope: product_certificate / full_document
- Elapsed seconds: 0.335883
- Depth 5: {'status': 'not_implemented', 'executed': False, 'upstream_model': None, 'review_model': None, 'budget_tier': 'highest', 'requires': ['different_model_identity', 'original_pdf', 'unchanged_candidate', 'fixed_scope', 'append_only_findings', 'explicit_remote_authorization']}
- Cost ordering: configured_priority_not_measured_ranking
- Calibrated probability of correctness: unavailable (no independently labeled data)

| PDF page | Accuracy | Structure | Tables | Formula/Figures | Cleanliness | Total | Status | Methods | Findings |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| 1 | 100.0 | 70.0 | not_applicable | not_applicable | 100.0 | 90.8 | review_required | 1 | 1 |

## Document dimensions

| Dimension | Score | Coverage | State |
| --- | ---: | ---: | --- |
| accuracy | 100.0 | 1.0 | assessed |
| structure | 70.0 | 1.0 | assessed |
| tables | None | None | not_applicable |
| formula_figures | None | None | not_applicable |
| cleanliness | 100.0 | 1.0 | assessed |

## Located findings

- **F8b30d01d74bbd094**, PDF page 1: structure / field_entity_association_difference / major; upstream IDs: fa, b; bbox: [55.0, 110.0, 300.0, 133.0]; method: tesseract

## Actual methods

| Page | Method | Status | Scope complete | Seconds | CPU seconds |
| --- | --- | --- | --- | --- | --- |
| 1 | tesseract | ok | True | 0.262942 | 0.251335 |

Scores represent evidence support, not a proven probability of correctness.
