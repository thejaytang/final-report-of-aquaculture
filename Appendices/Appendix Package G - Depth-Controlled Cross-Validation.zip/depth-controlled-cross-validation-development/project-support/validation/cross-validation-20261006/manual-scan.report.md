# PDF extraction validation

- Result: **review_required**
- Evidence support score: **96.9 / 100**
- Pages: 1
- Requested Depth: 4
- Document type / scope: user_manual / sections
- Elapsed seconds: 0.225506
- Depth 5: {'status': 'not_implemented', 'executed': False, 'upstream_model': None, 'review_model': None, 'budget_tier': 'highest', 'requires': ['different_model_identity', 'original_pdf', 'unchanged_candidate', 'fixed_scope', 'append_only_findings', 'explicit_remote_authorization']}
- Cost ordering: configured_priority_not_measured_ranking
- Calibrated probability of correctness: unavailable (no independently labeled data)

| PDF page | Accuracy | Structure | Tables | Formula/Figures | Cleanliness | Total | Status | Methods | Findings |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| 1 | 93.3 | 100.0 | not_applicable | not_applicable | 100.0 | 96.9 | review_required | 1 | 6 |

## Document dimensions

| Dimension | Score | Coverage | State |
| --- | ---: | ---: | --- |
| accuracy | 93.3 | 0.933 | partial |
| structure | 100.0 | 1.0 | assessed |
| tables | None | None | not_applicable |
| formula_figures | None | None | not_applicable |
| cleanliness | 100.0 | 1.0 | assessed |

## Located findings

- **F5a086c4583b17a49**, PDF page 1: accuracy / method_not_executed / warning; upstream IDs: none; bbox: None; method: docling
- **F6f9b84bb8b5fb4ca**, PDF page 1: accuracy / method_not_executed / warning; upstream IDs: none; bbox: None; method: pp_structure_v3
- **F523bc57ea81339c0**, PDF page 1: accuracy / method_not_executed / warning; upstream IDs: none; bbox: None; method: mineru_basic
- **F4833e3c827a6c85f**, PDF page 1: accuracy / block_depth_unmet / warning; upstream IDs: h; bbox: [55.0, 60.0, 160.0, 82.0]; method: input/scope
- **F1bee63cb8a2b47a7**, PDF page 1: accuracy / block_depth_unmet / warning; upstream IDs: p; bbox: [55.0, 105.0, 260.0, 132.0]; method: input/scope
- **F912470d94add0759**, PDF page 1: accuracy / requested_depth_unmet / warning; upstream IDs: none; bbox: None; method: input/scope

## Actual methods

| Page | Method | Status | Scope complete | Seconds | CPU seconds |
| --- | --- | --- | --- | --- | --- |
| 1 | tesseract | ok | True | 0.148881 | 0.143139 |
| 1 | docling | unavailable | False | 0.00014 | 0.00014 |
| 1 | pp_structure_v3 | unavailable | False | 5.4e-05 | 5.3e-05 |
| 1 | mineru_basic | unavailable | False | 3e-05 | 2.9e-05 |

Scores represent evidence support, not a proven probability of correctness.
