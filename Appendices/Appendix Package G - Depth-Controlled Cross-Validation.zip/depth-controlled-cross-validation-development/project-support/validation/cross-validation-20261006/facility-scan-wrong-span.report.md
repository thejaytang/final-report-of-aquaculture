# PDF extraction validation

- Result: **review_required**
- Evidence support score: **90.0 / 100**
- Pages: 1
- Requested Depth: 1
- Document type / scope: facility_certificate / tables
- Elapsed seconds: 0.344193
- Depth 5: {'status': 'not_implemented', 'executed': False, 'upstream_model': None, 'review_model': None, 'budget_tier': 'highest', 'requires': ['different_model_identity', 'original_pdf', 'unchanged_candidate', 'fixed_scope', 'append_only_findings', 'explicit_remote_authorization']}
- Cost ordering: configured_priority_not_measured_ranking
- Calibrated probability of correctness: unavailable (no independently labeled data)

| PDF page | Accuracy | Structure | Tables | Formula/Figures | Cleanliness | Total | Status | Methods | Findings |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| 1 | 100.0 | not_applicable | 75.0 | not_applicable | not_applicable | 90.0 | review_required | 1 | 1 |

## Document dimensions

| Dimension | Score | Coverage | State |
| --- | ---: | ---: | --- |
| accuracy | 100.0 | 1.0 | assessed |
| structure | None | None | not_applicable |
| tables | 75.0 | 1.0 | assessed |
| formula_figures | None | None | not_applicable |
| cleanliness | None | None | not_applicable |

## Located findings

- **F21525861281c3688**, PDF page 1: tables / merged_cell_relationship_difference / major; upstream IDs: t, h; bbox: [59.83333333333333, 191.83333333333331, 359.8333333333333, 241.83333333333331]; method: tesseract

## Actual methods

| Page | Method | Status | Scope complete | Seconds | CPU seconds |
| --- | --- | --- | --- | --- | --- |
| 1 | tesseract | ok | True | 0.261807 | 0.253923 |

Scores represent evidence support, not a proven probability of correctness.
