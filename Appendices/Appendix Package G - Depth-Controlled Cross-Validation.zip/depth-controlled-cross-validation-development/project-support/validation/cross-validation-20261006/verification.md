# 1. Historical verification result

Date: 2026-10-06. PASS: 74/74, 0 failures, 0 errors, 0 skipped. The full run took 53.249 seconds. Counts come from [tests-final.log](tests-final.log) and refer to unittest methods; subcases and repeated debugging runs are not counted again. [Machine-readable record](verification.json).

The user had no original files for the four Evidence categories, so engineering checks used generated samples. These results establish neither real Evidence acceptance nor measured business accuracy. Supplying those files was not a completion requirement.

## 1.1 Test scope

| Test file | Count | Actual scope |
| --- | ---: | --- |
| `tests/test_validator.py` | 41 | Existing content, structure, tables, page numbers, scope, input validation, CLI and real-regulation regression; corrected obsolete OCR-depth expectations. |
| `tests/test_type_methods.py` | 7 | Actual scanned-PDF reading, source grid rows/columns, coordinates, first-depth swapped columns, whole-paragraph omission, refusing invented structure without a grid, exclusion of upstream Tesseract variants. |
| `tests/test_cross_validation.py` | 26 | Fixed scope, cumulative depth and historical differences; numbers/units/negation; certificate names/values/units/product associations; section/list order and whole-section omission; horizontal/vertical spans, changed headers and whole-table omission; mixed scans, invalid OCR language, unavailable/inapplicable/partially failed methods; configuration, read-only protections and Depth 5 boundary. |

Most cases generate actual PDFs. Scan cases render an image-only PDF, then invoke Poppler, pdfplumber or Tesseract through to comparison. A few fault-injection cases use simulated readings to test retained differences and partial method failure; they are not parser-accuracy evidence. Wrapped real calls also verify that every method receives the original PDF path.

The real regulatory fixture has 30 pages. Three related regressions check completely missing pages, document weighting with only one supplied page, and detection of a `70%` to `700%` mutation in a historical candidate. That candidate is neither a current company output nor independent human truth.

## 1.2 Problems found and repaired during that run

- The prior implementation counted configurations of one OCR engine as separate depths and selected the closest reading, potentially hiding other differences. Comparisons are now retained per method.
- Border remnants in image-cell crops disrupted recognition. Removing those lines allowed positive and negative text/scanned-cell and merged-cell cases to pass.
- Penalizing missing pages only in information accuracy allowed other high dimensions to hide document omissions. Missing-page weight now follows visible source content, with unknown weight in other dimensions.
- Paths counting full depth without table structure, field association or reading order were tightened. Partial parser failure retains readings without counting a complete method.

`baseline.log` records 49 old tests rerun at the start. `first-regression.log`, `regression-second.log` and `acceptance-first.log` are development results, including expected semantic changes and failures before repair. They are not the final state. The pre-change source archive is retained in the author's project and excluded from the current English handoff. `development-snapshots/` contains pre-repair diagnostic samples and reports.

# 2. Reproduction

From the project root:

```bash
uv run --locked --extra test python -m unittest discover -s tests -v

uv run --locked python -m pdf_validator \
  --pdf project-support/validation/cross-validation-20261006/examples/certificate-scan.pdf \
  --json project-support/validation/cross-validation-20261006/examples/certificate-scan-wrong-product.json \
  --depth 1 \
  --output project-support/validation/cross-validation-20261006/certificate-scan-wrong-product.report.json

uv run --locked python -m pdf_validator \
  --pdf project-support/validation/cross-validation-20261006/examples/facility-scan.pdf \
  --json project-support/validation/cross-validation-20261006/examples/facility-scan-wrong-span.json \
  --depth 1 \
  --output project-support/validation/cross-validation-20261006/facility-scan-wrong-span.report.json
```

The erroneous samples produce `field_entity_association_difference` and `merged_cell_relationship_difference`, respectively, both with `review_required`. The [three-method legal-text report](legal-text.report.json) is `pass`; its scores indicate support from this evidence only. The [manual Depth 4 report](manual-scan.report.json) states that only Tesseract completed while three candidates were unavailable. Requested depth is not actual depth.

`examples/` contains nine normal PDF/JSON pairs and two deliberately erroneous candidates, all generated without real Evidence content. Source compilation passed. CLI JSON/Markdown output and input protection are included in the 74 checks above.

# 3. Cost and unexecuted capabilities

[Environment](environment.json) records interpreter, platform, CPU/memory, tool versions and dependency-file hashes. [Raw costs](cost-measurements.json) contain three sequential runs per method on the same input, scope and hardware: 24 measurements, not 24 additional functional tests.

| Generated sample | Method | Median wall-clock seconds |
| --- | --- | ---: |
| Short text regulation | Poppler | 0.014106 |
| Same text regulation | pdfplumber | 0.001030 |
| Same text regulation | Tesseract | 0.214279 |
| Text certificate | pdfplumber | 0.001488 |
| Same text certificate | Tesseract | 0.241460 |
| Text table | pdfplumber | 0.001229 |
| Same text table | Tesseract | 0.221939 |
| Scanned table | Tesseract | 0.242220 |

These observations concern short synthetic pages and cannot establish a ranking for all regulations. Priority remains configurable and explicitly not a measured business ranking. Method wall-clock time covers its actual work; full validation also includes inspection and comparison. CPU includes parent and child processes. RSS is a process-lifetime peak, with no per-method memory isolation. API charges are 0; local monetary compute cost is unknown.

Unexecuted capabilities: Docling, PP-StructureV3, MinerU Basic, Camelot, Table Transformer inference and Depth 5 model review. Passing an unavailable-state test does not mean that engine inference passed. Native Windows, company JSON adaptation, real Evidence and independently labelled accuracy remain unverified and are excluded from the 74 engineering passes.

# 4. Change boundary

Source, tests, README, AGENTS, design, state and evidence were within the project then named `PDF Extraction Validation`. Dependency declarations and lockfile hashes were unchanged; no model or dependency was installed.

The Word report and parent content mirror were read only for design context. Their ending hashes differed from the starting records due to concurrent changes outside this task's write scope. Before/after hashes and modification times were retained; the task did not claim those files stayed unchanged or revert another writer's work. It did not write the Word report, HTML, adjacent Workbench or public copy.

This is an English translation of historical evidence, not a new execution receipt.
