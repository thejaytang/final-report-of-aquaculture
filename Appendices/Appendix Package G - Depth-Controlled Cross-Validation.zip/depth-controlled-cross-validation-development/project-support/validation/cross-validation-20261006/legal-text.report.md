# PDF extraction validation

- Result: **pass**
- Evidence support score: **100.0 / 100**
- Pages: 1
- Requested Depth: 3
- Document type / scope: legal / full_document
- Elapsed seconds: 0.227775
- Depth 5: {'status': 'not_implemented', 'executed': False, 'upstream_model': None, 'review_model': None, 'budget_tier': 'highest', 'requires': ['different_model_identity', 'original_pdf', 'unchanged_candidate', 'fixed_scope', 'append_only_findings', 'explicit_remote_authorization']}
- Cost ordering: configured_priority_not_measured_ranking
- Calibrated probability of correctness: unavailable (no independently labeled data)

| PDF page | Accuracy | Structure | Tables | Formula/Figures | Cleanliness | Total | Status | Methods | Findings |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| 1 | 100.0 | not_applicable | not_applicable | not_applicable | 100.0 | 100.0 | pass | 3 | 0 |

## Document dimensions

| Dimension | Score | Coverage | State |
| --- | ---: | ---: | --- |
| accuracy | 100.0 | 1.0 | assessed |
| structure | None | None | not_applicable |
| tables | None | None | not_applicable |
| formula_figures | None | None | not_applicable |
| cleanliness | 100.0 | 1.0 | assessed |

## Located findings

No located discrepancy was found by the available checks.

## Actual methods

| Page | Method | Status | Scope complete | Seconds | CPU seconds |
| --- | --- | --- | --- | --- | --- |
| 1 | poppler | ok | True | 0.0114 | 0.010506 |
| 1 | pdfplumber | ok | True | 0.001322 | 0.001323 |
| 1 | tesseract | ok | True | 0.212209 | 0.207494 |

Scores represent evidence support, not a proven probability of correctness.
