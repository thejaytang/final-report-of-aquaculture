# Historical English design illustrations

These retained images explain earlier designs. Some depict the former Poppler/Tesseract/pdfplumber/PDFium/pypdf lineup, older report fields or proposed behavior. They do not establish the current implemented methods or acceptance. Use the package README and project-support/design/validation-design.md for current scope. Superseded Chinese visual variants remain in the author's project archive and are excluded from this English handoff.
