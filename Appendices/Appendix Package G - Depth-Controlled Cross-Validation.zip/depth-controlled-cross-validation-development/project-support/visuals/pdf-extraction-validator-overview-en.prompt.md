# English infographic prompt

Generated with the built-in imagegen tool. Final asset: [pdf-extraction-validator-overview-en.png](pdf-extraction-validator-overview-en.png).

References: `pdf-extraction-validator-overview-v3.png` for the polished panoramic navy/teal/coral visual style; `pdf-extraction-validator-figma-en.png` for the corrected English content and JSON-panel structure.

Use case: infographic-diagram. Asset type: final wide English project infographic. Recreate the elegant three-stage editorial composition with warm white background, navy-to-pale-blue stage ribbons, teal connectors, coral accents, and readable serif title. Stage 1 shows Original PDF and Upstream JSON. Stage 2 shows Depth 1–5 as N additional extraction methods applied in parallel to the SAME PAGE, SAME REGION, SAME BLOCK, then aligned and compared. The methods are Poppler / pdftotext, Tesseract OCR, pdfplumber, PDFium / pypdfium2, and pypdf. After comparison, show the five scoring dimensions: TEXT ACCURACY, STRUCTURE & LINKS, TABLES, FORMULAS & FIGURES, CLEANLINESS. Stage 3 shows a monospaced report.json code panel, not a file tree. Use large, exact English text; no Chinese, invented metrics, confidence percentages, checkmarks, or approval badge.

Exact right-panel JSON excerpt:

```json
{
  "requested_depth": 3,
  "document": {
    "overall_support_score": 2.9,
    "status": "failed"
  },
  "pages": [{
    "page_index": 0,
    "overall_support_score": 97.7,
    "status": "review_required"
  }],
  "findings": [{"id": "F00001"}],
  "review_items": [{"finding_id": "F00001"}]
}
```
