# 1. Current engineering design

Implementation reference dated 2026-10-06; English handoff dated 2026-10-07. This design supersedes the earlier approach that counted OCR configurations as separate depths. The prior source snapshot remains in the author's project archive and is excluded from this handoff. Inputs and invocation examples are defined in [README](../../README.md). Real files for the four Evidence categories were unavailable; generated text/scanned PDFs were used for program-behavior checks.

## 1.1 Shared execution path

`CLI / validate()` → validate inputs and hash originals → `inspect_page()` establishes page type and fixed regions → `read_page()` applies capability and configured priority → each method reopens the original PDF → independent per-method content, coverage, association and table checks → appended findings and five-dimensional summaries → JSON/Markdown.

| Module | Responsibility |
| --- | --- |
| `input.py` | Existing-contract adaptation; validate section/table inventories, spans, certificate fields and upstream model IDs. |
| `evidence.py` | Independent source inspection; text/scan/mixed routing; actual readers and structured image tables; method/component identity; failure and uninstalled states. |
| `validate.py` | Compare each method within fixed scope; PDF-to-candidate omissions and candidate-to-PDF differences; field/product relations, section order/parent links, cells and spans; accumulate findings and effective depth. |
| `__main__.py` | Read priority configuration, call the validator, write JSON/Markdown; refuse to overwrite inputs or their hard links. |

There is no standalone UI or invocation through the adjacent Workbench. The recorded work added no environment, parsing service or heavy dependency.

## 1.2 Validation invariants

Every method compares the same candidate and source scope. The source inventory is fixed before method execution and is independent of requested depth. Input files remain read-only. Located text and table readings are stored in `comparisons`; differences carry method names and stable IDs. Increasing depth cannot replace disagreeing readings with agreeing ones. Cross-source corroboration appends a separate finding and preserves existing evidence and judgments.

All depths check content correctness. Pages or sections with tables require structured methods from Depth 1. If the candidate contains a table the source detector missed, a plain-text method cannot count as a complete table check. Unresolved scope, missing source rows/columns, absent certificate association or method failure retain unverified status and insufficient depth.

Certificate checks compare labels, values, units and source product labels. Manuals compare headings, text, lists, order and parent-heading relationships within source regions. Regulations compare text, numbers, units, negation, paragraph relationships and omissions. Whole-section/table omissions depend on independent inventories or source-PDF detection. Only pages outside a declared scope may be marked inapplicable.

## 1.3 Depth and component overlap

The current maxima reflect implemented, executed methods: three for text bodies, two for text tables and one for scanned content. Scope and local evidence further limit complete checks per page. Known matching upstream methods/components are excluded. An opaque upstream name leaves provenance unknown; it does not establish independence.

Poppler and pdfplumber share embedded PDF text. The Tesseract table path uses PDFium rendering, Pillow line detection and pdfplumber's intersection/rectangular-cell assembly algorithm. Text recognition differs, but structural components overlap. Configuration variants add no depth, and component overlap must not be represented as independent voting.

Depth 5 is explicitly unexecuted. Its contract requires different upstream/review model identities, identical input hashes and scope, appended differences and a maximum budget. There is no callable model adapter. Installing a package, naming a model or providing simulated output does not change that state.

# 2. Tool references and selection

These official references were consulted on 2026-10-06. They describe capabilities and installation requirements; they do not establish local engine execution or a cost ranking. The recorded environment is in [environment.json](../validation/cross-validation-20261006/environment.json).

| Candidate | Official reference and engineering assessment | Recorded status |
| --- | --- | --- |
| Poppler | `pdftotext -tsv` returns positioned text. Suitable for selectable text bodies; it does not reconstruct table relationships. | Executed and retained. |
| pdfplumber | [Repository](https://github.com/jsvine/pdfplumber): based on pdfminer.six, with text, lines, tables and cells. Suitable for ruled tables with a text layer; not scan OCR. | Executed and retained; rectangular source spans are compared. |
| Tesseract | [Quality guide](https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html): image quality, borders and segmentation affect OCR. Cell crops must exclude border lines; table geometry supplies recognition positions. | Executed as one method; configurations do not add depth. |
| Docling / TableFormer | [Installation](https://docling-project.github.io/docling/getting_started/installation/), [advanced options](https://docling-project.github.io/docling/usage/advanced_options/), [full-page OCR](https://docling-project.github.io/docling/_generated/examples/full_page_ocr/): local models and OCR choices. Integration must record actual OCR, PDF backend and TableFormer configuration and check component overlap. | Uninstalled, no verified adapter. A candidate for later structural checks; models were not downloaded. |
| PP-StructureV3 | [Pipeline](https://www.paddleocr.ai/main/en/version3.x/pipeline_usage/PP-StructureV3.html): layout, text, table structure and cell components; requires a framework and models. Configurable model names alone do not establish independence. | PaddleOCR/PaddlePaddle uninstalled; no verified adapter. |
| MinerU Basic | [Model sources](https://opendatalab.github.io/MinerU/usage/model_source/) includes a non-VLM basic tier; [extensions](https://opendatalab.github.io/MinerU/quick_start/extension_modules/) distinguish components. Pin versions and actual recognition/table components before assessing overlap with Paddle methods. | Uninstalled, no verified adapter; independence unconfirmed. |
| Table Transformer + text reader | [Repository](https://github.com/microsoft/table-transformer): requires separately supplied PDF text or OCR; detection alone does not produce populated tables. | PyTorch/Transformers uninstalled; not integrated. Its accompanying Tesseract cannot count as another independent vote. |
| Camelot | [Repository](https://github.com/camelot-dev/camelot): multiple table parsers. Traditional text-table paths overlap with existing text-layer evidence; actual components depend on the parser. | Uninstalled and not integrated. Existing pdfplumber covered ruled text tables without another dependency. |

Configured defaults differ from combinations proposed in the report: text bodies reuse installed Tesseract for a third visual reading; text tables use pdfplumber followed by structured Tesseract. A configured tool name is not an implemented engine. The Word report's candidate table remains a proposal; that report was not rewritten in this work.

# 3. Cost, migration and acceptance

## 3.1 Cost evidence

`cost.ordering_basis=configured_priority_not_measured_ranking`. Each run records fixed input hashes, scope hash, platform, component versions, wall-clock time and CPU time for the process and children. Peak RSS is the Python process's lifetime high-water mark; it does not measure exclusive model memory. API charges are 0. Electricity, hardware depreciation and local monetary compute cost were not measured.

Repeated timing used the same generated sample, scope and hardware, retaining raw local readings. Uninstalled methods have no observed run costs. This small sample cannot establish a final company-document ranking or a causal accuracy benefit from depth. Default priority remains configured.

## 3.2 Migration

Existing `pages/blocks/cells` inputs remain readable. New fields are optional, but absent certificate fields or table cells prevent corresponding association checks. Unspecified spans default to 1×1, so source mismatches may appear; callers should supply actual `row_span/column_span` values.

Report version `/3` uses stable hash IDs and adds `comparisons`, source-scope hashes, cost and method components. `depth_5` is an object. `effective_depth` counts distinct methods completing required checks in the current scope, not OCR configurations. Historical JSON/Markdown reports retain their original status and need not be overwritten.

## 3.3 Completion criteria and remaining scope

Engineering checks covered existing regression; text/scanned source reading; synthetic content for the four Evidence categories and regulations; injected omissions, numbers, units, negation, associations, swapped columns, horizontal/vertical spans, section order and whole-section/table omissions; fixed scope and retained historical differences; failure, unavailability, inapplicability and upstream overlap; CLI output and immutable inputs.

Candidate model engines and Depth 5 inference were not executed and do not count as engine passes. Company Evidence files were unavailable, so there is no business acceptance claim or requirement to supply them for this stage. Future accuracy or review-benefit evaluation requires independently labelled data. See [historical verification](../validation/cross-validation-20261006/verification.md).
