"""Behavior checks with a controlled PDF and one real PDF from the 05 workspace."""

from __future__ import annotations

import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import pdfplumber
from reportlab.pdfgen import canvas

from pdf_validator.evidence import Observation, page_sizes, selected_methods, _pdfium
from pdf_validator.input import InputError
from pdf_validator.validate import validate


REAL_PDF = Path(__file__).parent / "fixtures" / "test.pdf"
REAL_INPUT = REAL_PDF.with_name("test-input-partial.json")


def sample_pdf(path: Path) -> dict:
    pdf = canvas.Canvas(str(path), pagesize=(612, 792))
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(60, 720, "Policy")
    pdf.setFont("Helvetica", 11)
    pdf.drawString(60, 670, "Dose must not exceed 10 mg.")
    for x in (60, 160, 260):
        pdf.line(x, 520, x, 600)
    for y in (520, 560, 600):
        pdf.line(60, y, 260, y)
    for x, y, label in ((70, 575, "A"), (170, 575, "B"),
                        (70, 535, "1"), (170, 535, "2")):
        pdf.drawString(x, y, label)
    pdf.drawString(300, 30, "1")
    pdf.save()
    return {"document_type": "general", "printed_page_label": None,
            "pages": [{"page_index": 0, "printed_page_label": "1", "blocks": [
                {"id": "h", "type": "heading", "text": "Policy", "bbox": [55, 60, 160, 82],
                 "heading_level": 1, "order": 0},
                {"id": "p", "type": "paragraph", "text": "Dose must not exceed 10 mg.",
                 "bbox": [55, 105, 260, 132], "parent_id": "h", "order": 1},
                {"id": "t", "type": "table", "bbox": [60, 192, 260, 272], "order": 2,
                 "cells": [
                     {"id": "a", "row": 0, "column": 0, "text": "A", "bbox": [60, 192, 160, 232]},
                     {"id": "b", "row": 0, "column": 1, "text": "B", "bbox": [160, 192, 260, 232]},
                     {"id": "one", "row": 1, "column": 0, "text": "1", "bbox": [60, 232, 160, 272]},
                     {"id": "two", "row": 1, "column": 1, "text": "2", "bbox": [160, 232, 260, 272]},
                 ]},
                {"id": "n", "type": "page_number", "text": "1", "bbox": [285, 742, 320, 772]},
            ]}]}


class ValidatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.pdf = self.root / "source.pdf"
        self.data = sample_pdf(self.pdf)
        self.json_path = self.root / "input.json"

    def run_validation(self, depth: int = 2) -> dict:
        self.json_path.write_text(json.dumps(self.data), encoding="utf-8")
        return validate(self.pdf, self.json_path, depth)

    def test_critical_number_difference_has_two_evidence_families(self) -> None:
        self.data["pages"][0]["blocks"][1]["text"] = "Dose must not exceed 100 mg."
        report = self.run_validation()
        matches = [f for f in report["findings"] if f["kind"] == "critical_text_difference"]
        self.assertTrue(matches, report["findings"])
        self.assertEqual(matches[0]["upstream_ids"], ["p"])
        self.assertEqual(matches[0]["disposition"], "review_required")
        self.assertTrue(any(f["kind"] == "corroborated_critical_difference" for f in report["findings"]))
        self.assertEqual(report["document"]["status"], "failed")
        self.assertIsNone(report["document"]["calibrated_correctness"])
        self.assertEqual(set(report["pages"][0]["evidence_families"]),
                         {"embedded_text", "visual_ocr"})

    def test_small_changes_inside_long_blocks_are_found(self) -> None:
        lines = [
            "The monthly control record confirms that every sample is checked before the laboratory result is approved: 1,500 units.",
            "The auditor shall inspect submitted reports and retain the approved copy for the annual review cycle.",
        ]
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.setFont("Helvetica", 8)
        pdf.drawString(60, 700, lines[0])
        pdf.drawString(60, 660, lines[1])
        pdf.save()
        self.data = {"pages": [{"page_index": 0, "blocks": [
            {"id": "number", "type": "paragraph", "text": lines[0].replace("1,500", "15,000"),
             "bbox": [55, 80, 560, 110]},
            {"id": "word", "type": "paragraph", "text": lines[1].replace("reports", "records"),
             "bbox": [55, 120, 560, 150]},
        ]}]}
        report = self.run_validation(depth=1)
        kinds = {(f["upstream_ids"][0], f["kind"]) for f in report["findings"]
                 if f["upstream_ids"]}
        self.assertIn(("number", "critical_text_difference"), kinds)
        self.assertIn(("word", "text_difference"), kinds)

    def test_correct_control_page_reports_missing_block_evidence(self) -> None:
        report = self.run_validation(depth=2)
        self.assertEqual(report["document"]["status"], "review_required")
        self.assertEqual({f["kind"] for f in report["findings"]}, {"block_depth_unmet"})
        self.assertTrue(all(f["evidence"]["effective"] == 1 for f in report["findings"]))
        self.assertTrue(report["upstream_lineage_unknown"])

    def test_omitted_pdf_region_is_located(self) -> None:
        self.data["pages"][0]["blocks"].pop(1)
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "pdf_region_missing_from_json" and f["bbox"]
                            for f in report["findings"]))

    def test_substantive_top_margin_text_is_not_skipped(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.drawString(60, 760, "Important scope limitation")
        pdf.save()
        self.data = {"pages": [{"page_index": 0, "blocks": []}]}
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "pdf_region_missing_from_json" and
                            "Important scope limitation" in str(f["evidence"])
                            for f in report["findings"]))

    def test_repeated_margin_decoration_is_not_called_omitted(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        for _ in range(2):
            pdf.drawString(60, 760, "Confidential")
            pdf.showPage()
        pdf.save()
        self.data = {"pages": [{"page_index": i, "blocks": []} for i in range(2)]}
        report = self.run_validation(depth=1)
        self.assertFalse(any(f["kind"] == "pdf_region_missing_from_json"
                             for f in report["findings"]))

    def test_table_wrong_cell_and_geometry_are_located(self) -> None:
        table = self.data["pages"][0]["blocks"][2]
        table["cells"][2]["text"] = "9"
        table["cells"][2]["bbox"] = [160, 232, 260, 272]
        table["cells"][3]["bbox"] = [60, 232, 160, 272]
        report = self.run_validation()
        kinds = {f["kind"] for f in report["findings"]}
        self.assertIn("cell_content_difference", kinds)
        self.assertIn("cell_row_column_conflict", kinds)
        self.assertTrue(any(f["upstream_ids"] == ["t", "one"]
                            for f in report["findings"] if f["kind"] == "cell_content_difference"))

    def test_unlocated_table_cells_are_checked_as_one_region(self) -> None:
        cells = self.data["pages"][0]["blocks"][2]["cells"]
        for cell in cells:
            cell.pop("bbox")
        report = self.run_validation(depth=1)
        table_findings = [f for f in report["findings"] if f["dimension"] == "tables"]
        self.assertEqual(table_findings, [])
        self.assertNotEqual(report["document"]["status"], "failed")
        cells[2]["text"] = "9"
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "table_critical_token_difference"
                            for f in report["findings"]))
        cells[2]["text"] = "1"
        cells[0]["text"] = "C"
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "table_aggregate_text_difference"
                            for f in report["findings"]))

    def test_table_rows_can_be_checked_without_upstream_cell_boxes(self) -> None:
        cells = self.data["pages"][0]["blocks"][2]["cells"]
        for cell in cells:
            cell.pop("bbox")
        clean = self.run_validation(depth=1)
        self.assertEqual(clean["findings"], [])
        cells[2]["column"], cells[3]["column"] = 1, 0
        changed = self.run_validation(depth=1)
        rows = [f for f in changed["findings"] if f["kind"] == "table_row_alignment_disagreement"]
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["evidence"]["row"], 1)
        self.assertIsNotNone(rows[0]["bbox"])

    def test_duplicate_table_coordinate_without_boxes_fails(self) -> None:
        cells = self.data["pages"][0]["blocks"][2]["cells"]
        for cell in cells:
            cell.pop("bbox")
        cells[3]["column"] = 0
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "duplicate_cell_coordinate" and
                            f["disposition"] == "failed" for f in report["findings"]))

    def test_duplicate_text_inside_table_is_flagged(self) -> None:
        self.data["pages"][0]["blocks"].append(
            {"id": "dup", "type": "paragraph", "text": "A B 1 2",
             "bbox": [62, 198, 258, 268]})
        report = self.run_validation(depth=1)
        duplicates = [f for f in report["findings"] if f["kind"] == "duplicate_table_content"]
        self.assertEqual(len(duplicates), 1)
        self.assertEqual(duplicates[0]["upstream_ids"], ["t", "dup"])

    def test_shared_upstream_reader_is_replaced(self) -> None:
        self.data["parser_engines"] = ["pdftotext"]
        report = self.run_validation(depth=1)
        self.assertEqual(report["pages"][0]["effective_methods"], ["pdfplumber"])
        self.assertNotIn("poppler", report["pages"][0]["effective_methods"])

    def test_shared_text_layer_does_not_confirm_critical_error(self) -> None:
        self.data["parser_engines"] = ["pdfplumber"]
        self.data["pages"][0]["blocks"][1]["text"] = "Dose must not exceed 100 mg."
        report = self.run_validation(depth=2)
        finding = next(f for f in report["findings"] if f["kind"] == "critical_text_difference")
        self.assertEqual(finding["disposition"], "review_required")
        self.assertTrue(report["pages"][0]["methods"][0]["family_overlaps_upstream"])

    def test_structure_and_page_number_pollution(self) -> None:
        blocks = self.data["pages"][0]["blocks"]
        blocks[1].update(type="heading", heading_level=3, parent_id="missing")
        blocks[3]["type"] = "paragraph"
        report = self.run_validation(depth=1)
        kinds = {f["kind"] for f in report["findings"]}
        self.assertIn("invalid_parent_relation", kinds)
        self.assertIn("heading_level_jump", kinds)
        self.assertIn("page_number_in_body", kinds)

    def test_missing_reading_order_is_explicitly_unverified(self) -> None:
        for block in self.data["pages"][0]["blocks"]:
            block.pop("order", None)
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "reading_order_unverified" for f in report["findings"]))
        self.assertEqual(report["pages"][0]["status"], "review_required")

    def test_unpositioned_source_text_cannot_prove_pdf_coverage(self) -> None:
        self.data["pages"][0]["blocks"] = []
        self.json_path.write_text(json.dumps(self.data), encoding="utf-8")
        observation = Observation("pdfium", "embedded_text", 0, "ok", text="Visible PDF text")
        with patch("pdf_validator.validate.read_page", return_value=[observation]):
            report = validate(self.pdf, self.json_path, 1)
        self.assertTrue(any(f["kind"] == "pdf_coverage_unverified" for f in report["findings"]))
        self.assertNotEqual(report["pages"][0]["status"], "pass")

    def test_unpositioned_upstream_text_is_not_called_omitted(self) -> None:
        paragraph = self.data["pages"][0]["blocks"][1]
        paragraph.pop("bbox")
        report = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "pdf_region_position_unverified" and
                            "p" in f["upstream_ids"] for f in report["findings"]))
        self.assertFalse(any(f["kind"] == "pdf_region_missing_from_json" and
                             "Dose must not exceed" in str(f["evidence"])
                             for f in report["findings"]))

    def test_page_of_total_footer_is_kept_out_of_body(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.drawString(280, 30, "Page 1 of 30")
        pdf.save()
        self.data = {"pages": [{"page_index": 0, "blocks": []}]}
        missing = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "printed_page_number_not_separated"
                            for f in missing["findings"]))
        self.data["pages"][0]["blocks"] = [
            {"id": "bad-body", "type": "paragraph", "text": "Page 1 of 30",
             "bbox": [270, 744, 360, 770]}]
        polluted = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "page_number_in_body" for f in polluted["findings"]))
        self.data["pages"][0]["printed_page_label"] = "2"
        mismatched = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "printed_page_label_mismatch"
                            for f in mismatched["findings"]))

    def test_page_number_in_header_is_not_body(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.drawString(280, 760, "Page 1 of 30")
        pdf.save()
        self.data = {"pages": [{"page_index": 0, "blocks": [
            {"id": "bad-body", "type": "paragraph", "text": "Page 1 of 30",
             "bbox": [270, 20, 360, 45]}]}]}
        polluted = self.run_validation(depth=1)
        self.assertTrue(any(f["kind"] == "page_number_in_body" for f in polluted["findings"]))
        self.data["pages"][0]["blocks"][0]["type"] = "page_number"
        separated = self.run_validation(depth=1)
        self.assertFalse(any(f["kind"] in {"page_number_in_body", "printed_page_number_not_separated"}
                             for f in separated["findings"]))

    def test_formula_and_vector_figure_remain_unverified(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.drawString(60, 700, "E = mc2")
        pdf.rect(60, 590, 120, 60)
        pdf.save()
        self.data = {"pages": [{"page_index": 0, "blocks": [
            {"id": "e", "type": "equation", "text": "E = mc2", "bbox": [55, 80, 180, 110]},
            {"id": "f", "type": "figure", "bbox": [60, 142, 180, 202]},
        ]}]}
        report = self.run_validation(depth=3)
        kinds = {f["kind"] for f in report["findings"]}
        self.assertIn("formula_semantics_unverified", kinds)
        self.assertIn("figure_presence_unverified", kinds)
        self.assertIsNone(report["document"]["calibrated_correctness"])

    def test_no_text_evidence_does_not_pass(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.showPage()
        pdf.save()
        report = self.run_validation(depth=1)
        self.assertEqual(report["pages"][0]["effective_depth"], 0)
        self.assertNotEqual(report["document"]["status"], "pass")
        self.assertTrue(any(f["kind"] == "requested_depth_unmet" for f in report["findings"]))

    def test_bad_input_type_is_diagnosed(self) -> None:
        self.data["pages"][0]["blocks"][0]["type"] = []
        with self.assertRaisesRegex(InputError, "unsupported block type"):
            self.run_validation(depth=1)

    def test_declared_source_hash_must_match_pdf(self) -> None:
        self.data["source_sha256"] = "0" * 64
        with self.assertRaisesRegex(InputError, "does not match"):
            self.run_validation(depth=1)

    def test_swapped_json_pages_are_detected(self) -> None:
        pdf = canvas.Canvas(str(self.pdf), pagesize=(612, 792))
        pdf.drawString(60, 700, "Alpha requires 10 units")
        pdf.showPage()
        pdf.drawString(60, 700, "Beta requires 20 units")
        pdf.save()
        self.data = {"pages": [
            {"page_index": 0, "blocks": [{"id": "a", "type": "paragraph",
                                          "text": "Beta requires 20 units", "bbox": [55, 80, 260, 110]}]},
            {"page_index": 1, "blocks": [{"id": "b", "type": "paragraph",
                                          "text": "Alpha requires 10 units", "bbox": [55, 80, 260, 110]}]},
        ]}
        report = self.run_validation(depth=1)
        self.assertEqual({f["page_index"] for f in report["findings"]
                          if f["kind"] == "critical_text_difference"}, {0, 1})
        self.assertEqual(report["document"]["status"], "review_required")

    @unittest.skipUnless(REAL_PDF.exists(), "local real PDF fixture is not present")
    def test_real_pdf_missing_pages_are_reported_once(self) -> None:
        self.assertEqual(len(page_sizes(REAL_PDF)), 30)
        self.json_path.write_text('{"pages": []}', encoding="utf-8")
        report = validate(REAL_PDF, self.json_path, 1)
        self.assertEqual(sum(f["kind"] == "missing_pdf_page_in_json" for f in report["findings"]), 30)
        self.assertTrue(all(p["effective_depth"] == 0 for p in report["pages"]))
        self.assertEqual(report["document"]["status"], "failed")

    @unittest.skipUnless(REAL_PDF.exists(), "local real PDF fixture is not present")
    def test_real_pdf_one_supplied_page_cannot_dominate_whole_score(self) -> None:
        # Diagnostic input derived from the PDF; it is not independent ground truth.
        with pdfplumber.open(REAL_PDF) as pdf:
            lines = pdf.pages[0].extract_text_lines()
        blocks = [{"id": f"line-{i}", "type": "paragraph", "text": line["text"],
                   "bbox": [line[k] for k in ("x0", "top", "x1", "bottom")], "order": i}
                  for i, line in enumerate(lines)]
        self.json_path.write_text(json.dumps({"parser_engines": ["pdfplumber"],
                                              "pages": [{"page_index": 0, "blocks": blocks}]}),
                                  encoding="utf-8")
        report = validate(REAL_PDF, self.json_path, 1)
        self.assertGreater(report["pages"][0]["overall_support_score"], 50)
        self.assertLess(report["document"]["overall_support_score"], 10)

    @unittest.skipUnless(REAL_PDF.exists() and REAL_INPUT.exists(), "local real PDF pair is not present")
    def test_real_pdf_critical_table_number_reduces_page_score(self) -> None:
        baseline = validate(REAL_PDF, REAL_INPUT, 1)
        data = json.loads(REAL_INPUT.read_text())
        cell = next(c for c in data["pages"][2]["blocks"][0]["cells"]
                    if c["row"] == 6 and c["column"] == 3)
        cell["text"] = cell["text"].replace("70%", "700%", 1)
        self.json_path.write_text(json.dumps(data), encoding="utf-8")
        changed = validate(REAL_PDF, self.json_path, 1)
        self.assertTrue(any(f["kind"] == "table_critical_token_difference" and f["page_index"] == 2
                            for f in changed["findings"]))
        self.assertLess(changed["pages"][2]["overall_support_score"],
                        baseline["pages"][2]["overall_support_score"])

    def test_profile_methods_are_nested_and_local_depth_is_capped(self):
        for profile in ("product_certificate", "user_manual", "deployment_report", "facility_certificate"):
            for native in (True, False):
                full = selected_methods(5, native, profile)
                self.assertEqual(len(set(full)), 4)
                self.assertNotIn("pypdf", full)
                for depth in range(1, 5):
                    self.assertEqual(selected_methods(depth, native, profile), full[:depth])
                if not native and profile == "product_certificate":
                    self.assertEqual(full[0], "tesseract")
        self.assertEqual(selected_methods(1, True, "deployment_report"), ("pdfplumber",))
        self.assertEqual(selected_methods(4, True, "deployment_report"), selected_methods(4, True, "facility_certificate"))

    def test_pdfium_evidence_is_positioned(self):
        obs = _pdfium(self.pdf, 0)
        self.assertTrue(any(w.text == "Policy" and 55 < w.box.y0 < 82 for w in obs.words))
        self.assertTrue(any(w.text == "10" and 105 < w.box.y0 < 132 for w in obs.words))

    def test_product_certificate_combines_text_and_visual_evidence(self):
        self.data["document_type"] = "product_certificate"
        report = self.run_validation(3)
        self.assertEqual([m["name"] for m in report["pages"][0]["methods"] if m["status"] == "ok"], ["pdfplumber", "tesseract"])
        self.assertEqual(report["pages"][0]["effective_depth"], 0)
        self.assertTrue(any(f["kind"] == "certificate_fields_unstructured" for f in report["findings"]))
        self.assertTrue(any(f["kind"] == "block_depth_unmet" and f["upstream_ids"] == ["n"] for f in report["findings"]))

    def test_table_profiles_do_not_report_excluded_prose(self):
        self.data["pages"][0]["blocks"] = [self.data["pages"][0]["blocks"][2]]
        self.data["expected_regions"] = [{"page_index": 0, "bbox": [60, 192, 260, 272]}]
        for profile in ("deployment_report", "facility_certificate"):
            self.data["document_type"] = profile
            report = self.run_validation(2)
            self.assertEqual(report["extraction_scope"], "tables")
            self.assertEqual(report["document"]["status"], "pass", report["findings"])
            self.assertEqual(report["pages"][0]["effective_depth"], 2)

    def test_automatic_table_inventory_is_provisional_and_finds_omission(self):
        self.data["document_type"] = "deployment_report"
        self.data["pages"][0]["blocks"] = []
        report = self.run_validation(1)
        kinds = {f["kind"] for f in report["findings"]}
        self.assertIn("extraction_scope_unverified", kinds)
        self.assertIn("possible_table_omission", kinds)
        self.assertTrue(all(not f["bbox"] or f["bbox"][1] >= 192
                            for f in report["findings"] if f["kind"] == "pdf_region_missing_from_json"))

    def test_section_scope_checks_expected_content_not_entire_page(self):
        self.data["document_type"] = "user_manual"
        self.data["expected_regions"] = [{"page_index": 0, "bbox": [50, 55, 280, 140]}]
        self.data["pages"][0]["blocks"] = self.data["pages"][0]["blocks"][:2]
        report = self.run_validation(1)
        self.assertEqual(report["document"]["status"], "pass", report["findings"])
        self.data["pages"][0]["blocks"].pop()
        changed = self.run_validation(3)
        self.assertTrue(any(f["kind"] == "pdf_region_missing_from_json" for f in changed["findings"]))
        self.assertFalse(any(f["kind"] == "whole_page_text_disagreement" for f in changed["findings"]))

    def test_missing_scope_never_passes(self):
        self.data["document_type"] = "user_manual"
        report = self.run_validation(1)
        self.assertNotEqual(report["document"]["status"], "pass")
        self.assertTrue(any(f["kind"] == "extraction_scope_unverified" for f in report["findings"]))

    def test_expected_region_on_absent_page_is_not_silently_skipped(self):
        self.data["document_type"] = "user_manual"
        self.data["expected_regions"] = [{"page_index": 0, "bbox": [50, 55, 280, 140]}]
        self.data["pages"] = []
        report = self.run_validation(1)
        self.assertEqual(report["document"]["status"], "failed")

    def test_scope_and_stage_are_validated(self):
        for extra in ({"extraction_stage": "target_extraction"},
                      {"extraction_scope": "invalid"},
                      {"extraction_scope": "sections", "expected_regions": []},
                      {"extraction_scope": "sections", "expected_regions": [{"page_index": 0}]},
                      {"extraction_scope": "sections", "expected_regions": [{"page_index": 8, "bbox": [1, 2, 3, 4]}]}):
            self.data = sample_pdf(self.pdf)
            self.data.update(extra)
            with self.assertRaises(InputError):
                self.run_validation(1)

    def test_fifth_layer_is_explicitly_unimplemented(self):
        self.data["document_type"] = "product_certificate"
        before = self.pdf.read_bytes()
        report = self.run_validation(5)
        methods = report["pages"][0]["methods"]
        self.assertEqual(methods[-1]["name"], "other_model")
        self.assertEqual(methods[-1]["status"], "not_implemented")
        self.assertEqual(report["pages"][0]["effective_depth"], 0)
        self.assertNotEqual(report["document"]["status"], "pass")
        self.assertGreater(report["elapsed_seconds"], 0)
        self.assertTrue(all(m["elapsed_seconds"] >= 0 for m in methods))
        self.assertEqual(before, self.pdf.read_bytes())

    def test_pages_outside_declared_sections_are_not_missing(self):
        from pypdf import PdfReader, PdfWriter
        writer = PdfWriter()
        source = PdfReader(self.pdf)
        writer.add_page(source.pages[0])
        writer.add_blank_page(612, 792)
        writer.write(self.root / "two.pdf")
        self.pdf = self.root / "two.pdf"
        self.data["document_type"] = "user_manual"
        self.data["expected_regions"] = [{"page_index": 0, "bbox": [50, 55, 280, 140]}]
        self.data["pages"][0]["blocks"] = self.data["pages"][0]["blocks"][:2]
        report = self.run_validation(1)
        self.assertEqual(report["pages"][1]["status"], "not_applicable")
        self.assertEqual(report["document"]["status"], "pass")

    def test_extra_candidate_is_reported_not_silently_discarded(self):
        self.data["document_type"] = "user_manual"
        self.data["expected_regions"] = [{"page_index": 0, "bbox": [50, 55, 280, 140]}]
        report = self.run_validation(1)
        self.assertTrue(any(f["kind"] == "candidate_outside_or_unlocated_in_scope"
                            and f["upstream_ids"] == ["t"] for f in report["findings"]))

    def test_scoped_table_number_mutation_is_detected(self):
        self.data["document_type"] = "deployment_report"
        table = self.data["pages"][0]["blocks"][2]
        self.data["pages"][0]["blocks"] = [table]
        self.data["expected_regions"] = [{"page_index": 0, "bbox": table["bbox"]}]
        table["cells"][2]["text"] = "100"
        report = self.run_validation(3)
        self.assertTrue(any("difference" in f["kind"] or "disagreement" in f["kind"]
                            for f in report["findings"]))
        self.assertNotEqual(report["document"]["status"], "pass")

    def test_cli_writes_profile_reports_without_changing_inputs(self):
        import subprocess
        import sys
        from hashlib import sha256
        for profile in ("product_certificate", "user_manual", "deployment_report", "facility_certificate"):
            data = sample_pdf(self.pdf)
            data["document_type"] = profile
            if profile == "user_manual":
                data["pages"][0]["blocks"] = data["pages"][0]["blocks"][:2]
                data["expected_regions"] = [{"page_index": 0, "bbox": [50, 55, 280, 140]}]
            elif profile in {"deployment_report", "facility_certificate"}:
                data["pages"][0]["blocks"] = [data["pages"][0]["blocks"][2]]
                data["expected_regions"] = [{"page_index": 0, "bbox": [60, 192, 260, 272]}]
            self.json_path.write_text(json.dumps(data))
            hashes = [sha256(f.read_bytes()).hexdigest() for f in (self.pdf, self.json_path)]
            output = self.root / (profile + ".json")
            result = subprocess.run([sys.executable, "-m", "pdf_validator", "--pdf", str(self.pdf),
                                     "--json", str(self.json_path), "--depth", "3", "--output", str(output)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            report = json.loads(output.read_text())
            self.assertTrue(all(m["status"] in {"ok", "empty", "unavailable", "not_implemented"} for m in report["pages"][0]["methods"]), report["pages"][0]["methods"])
            self.assertTrue(all(f["kind"] in {"block_depth_unmet", "requested_depth_unmet", "method_not_executed", "certificate_fields_unstructured"} for f in report["findings"]), report["findings"])
            self.assertIn(profile, output.with_suffix(".md").read_text())
            self.assertEqual(hashes, [sha256(f.read_bytes()).hexdigest() for f in (self.pdf, self.json_path)])


if __name__ == "__main__":
    unittest.main()
