# 1. Controlled error-detection experiment

One authored pump-check page is supplied as a text PDF and a 216 dpi image-only simulated scan. Each form uses one clean control and nine independently mutated JSON candidates. Expected differences and success criteria were frozen before execution.

| Location | Contents |
| --- | --- |
| [materials/source.md](materials/source.md) | Authored test text. |
| [materials/output/pdf/](materials/output/pdf/) | Text and simulated scanned PDFs. |
| [materials/candidates/](materials/candidates/) | Clean control and nine mutated JSON files. |
| [materials/experiment.json](materials/experiment.json) | Frozen criteria, target locations, input and validator hashes. |
| `materials/tmp/pdfs/` | PDF previews and scan-generation images. |
| [Initial results](results/initial-20261006/results.md) | First run, case reports and word-order diagnosis. |
| [Relocation rerun](results/run-20261006T125704-991792Z/results.md) | Actual rerun after relocation, with logs. |
| `run_experiment.py` | Reproduction script; each run writes a new result directory. |

# 2. Current result

Historical result: FAIL, 18/20 passed, 2 failed. All 18 mutated cases located their specified errors; both clean controls had the same word-order false positive. Relocation reproduced 18/20 with unchanged inputs, criteria and validator hashes. The separate 74-test engineering pass does not replace the failed controls.

English packaging translates labels and report prose only. Experimental inputs, expected finding kinds/targets and validator hashes are preserved. Historical results retain the original experiment metadata hash for provenance, so it differs from the translated experiment.json hash. Execution facts are unchanged.

# 3. Reproduction

From the extracted project root, after rebuilding its environment:

```bash
uv run --locked --extra test python tests/controlled-example-20261006/run_experiment.py run
```

Exit code 1 means some experiment cases failed. Inspect the new `results/run-*/results.md`, `results.json` and `reports/`. Keep frozen materials; `prepare` refuses to overwrite them. The experiment uses local dependencies without remote models. It is not a measure of business accuracy.

# 4. English-output reproduction on 2026-10-07

The translated runner was executed against the same frozen inputs. It produced English Markdown/JSON labels and again returned FAIL, 18/20, with the same two clean-control failures. Input and validator hashes were unchanged. [English rerun](results/run-20261007T070231-676733Z/results.md) · [Raw result](results/run-20261007T070231-676733Z/results.json). This confirms report language and reproducibility of the existing behavior; it does not repair the validator.
