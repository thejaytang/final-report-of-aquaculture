"""One authored page, two PDF forms, and nine isolated candidate mutations.

Run with the project's .venv Python: this_file.py prepare, then this_file.py run.
The validator is not mocked or changed. Inputs and expectations freeze before run.
"""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MATERIALS = HERE / "materials"
sys.path.insert(0, str(ROOT))

from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import pdfplumber
from pdf_validator.evidence import _render
from pdf_validator.validate import validate


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def prepare():
    if (MATERIALS / "experiment.json").exists():
        raise SystemExit("Frozen materials already exist; use run to reproduce them.")
    pdf_dir, preview = MATERIALS / "output/pdf", MATERIALS / "tmp/pdfs"
    pdf_dir.mkdir(parents=True, exist_ok=True)
    preview.mkdir(parents=True, exist_ok=True)
    native, scan = pdf_dir / "pump-check-native.pdf", pdf_dir / "pump-check-scan.pdf"
    # Authoring truth is specified here, never extracted by any validation reader.
    blocks = [
        {"id": "title", "type": "heading", "text": "Pump check sheet", "heading_level": 1,
         "bbox": [55, 65, 555, 92], "order": 0},
        {"id": "limit-heading", "type": "heading", "text": "1 Operating limit", "heading_level": 2,
         "bbox": [55, 112, 555, 140], "order": 1},
        {"id": "limit", "type": "paragraph", "text": "Pressure must not exceed 10 bar.",
         "parent_id": "limit-heading", "bbox": [55, 150, 555, 175], "order": 2},
        {"id": "inspection-heading", "type": "heading", "text": "2 Inspection", "heading_level": 2,
         "bbox": [55, 205, 555, 232], "order": 3},
        {"id": "inspection", "type": "paragraph", "text": "Inspect the inlet filter every 20 days.",
         "parent_id": "inspection-heading", "bbox": [55, 243, 555, 268], "order": 4},
        {"id": "pressure-table", "type": "table", "bbox": [60, 320, 552, 452], "order": 5,
         "cells": [
             {"id": "pressure-header", "row": 0, "column": 0, "column_span": 2, "text": "Pressure (bar)"},
             {"id": "alpha-label", "row": 1, "column": 0, "text": "Pump Alpha"},
             {"id": "beta-label", "row": 1, "column": 1, "text": "Pump Beta"},
             {"id": "alpha-value", "row": 2, "column": 0, "text": "10"},
             {"id": "beta-value", "row": 2, "column": 1, "text": "20"},
         ]},
    ]
    clean = {"document_type": "user_manual", "extraction_scope": "full_document",
             "extraction_stage": "full_page_extraction", "parser_engines": ["authored-simulation"],
             "expected_tables": [{"page_index": 0, "bbox": [60, 320, 552, 452]}],
             "pages": [{"page_index": 0, "blocks": blocks}]}
    (MATERIALS / "source.md").write_text(
        "# Pump check sheet\n\n## 1 Operating limit\n\nPressure must not exceed 10 bar.\n\n"
        "## 2 Inspection\n\nInspect the inlet filter every 20 days.\n\n"
        "Table: the top header 'Pressure (bar)' spans both columns.\n\n"
        "| Pump Alpha | Pump Beta |\n| --- | --- |\n| 10 | 20 |\n\n"
        "Synthetic test content only; not operating guidance.\n", encoding="utf-8")
    c = canvas.Canvas(str(native), pagesize=(612, 792), invariant=1)
    c.setTitle("Pump check sheet - synthetic validation sample")
    for i, baseline in enumerate((85, 133, 168, 225, 261)):
        c.setFont("Helvetica-Bold" if blocks[i]["type"] == "heading" else "Helvetica",
                  18 if i == 0 else 14 if blocks[i]["type"] == "heading" else 12)
        c.drawString(60, 792 - baseline, blocks[i]["text"])
    c.setLineWidth(1)
    for top in (320, 364, 408, 452):
        c.line(60, 792 - top, 552, 792 - top)
    for x in (60, 552):
        c.line(x, 792 - 320, x, 792 - 452)
    c.line(306, 792 - 364, 306, 792 - 452)
    for i, (x, top) in enumerate(((76, 348), (76, 392), (322, 392), (76, 436), (322, 436))):
        c.setFont("Helvetica-Bold" if i < 3 else "Helvetica", 12)
        c.drawString(x, 792 - top, blocks[-1]["cells"][i]["text"])
    c.save()
    native_image = _render(native, 0)
    native_image.save(preview / "native.png")
    native_image.convert("L").save(preview / "scan-source.jpg", quality=90, dpi=(216, 216))
    c = canvas.Canvas(str(scan), pagesize=(612, 792), invariant=1)
    c.setTitle("Pump check sheet - image-only simulated scan")
    c.drawImage(ImageReader(str(preview / "scan-source.jpg")), 0, 0, 612, 792)
    c.save()
    _render(scan, 0).save(preview / "scan.png")
    pdf_checks = {}
    for name, path in (("native", native), ("scan", scan)):
        with pdfplumber.open(path) as pdf:
            pdf_checks[name] = {"pages": len(pdf.pages), "text_characters": len(pdf.pages[0].chars),
                                "images": len(pdf.pages[0].images), "size": [pdf.pages[0].width, pdf.pages[0].height]}
    assert pdf_checks["native"]["text_characters"] > 0
    assert pdf_checks["scan"]["text_characters"] == 0 and pdf_checks["scan"]["images"] == 1
    cases = [{"id": "clean", "label": "Clean control", "change": "Unchanged", "expected": []}]
    save(MATERIALS / "candidates/clean.json", clean)
    # Each candidate is a fresh copy. For swapped cells, require both locations.
    mutations = [
        ("number", "Body number", "10 bar → 100 bar", [["critical_text_difference", "limit"]]),
        ("unit", "Body unit", "10 bar → 10 kPa", [["critical_text_difference", "limit"]]),
        ("negation", "Negation", "must not exceed → must exceed", [["critical_text_difference", "limit"]]),
        ("section", "Whole-section omission", "Remove the section 2 heading and body", [["pdf_region_missing_from_json", None]]),
        ("table-value", "Table value", "Pump Alpha: 10 → 100", [["table_row_alignment_disagreement", "alpha-value"]]),
        ("table-swap", "Swapped columns", "Swap 10 and 20 between columns", [["table_row_alignment_disagreement", "alpha-value"], ["table_row_alignment_disagreement", "beta-value"]]),
        ("table-unit", "Header unit", "Pressure (bar) → Pressure (kPa)", [["table_row_alignment_disagreement", "pressure-header"]]),
        ("table-span", "Merged cell", "Header spans 2 columns → 1 column", [["merged_cell_relationship_difference", "pressure-header"]]),
        ("table-omission", "Whole-table omission", "Remove the table; retain the independent source inventory", [["expected_table_missing", None]]),
    ]
    for name, label, change, expected in mutations:
        candidate = deepcopy(clean)
        b = candidate["pages"][0]["blocks"]
        if name == "number": b[2]["text"] = b[2]["text"].replace("10", "100")
        elif name == "unit": b[2]["text"] = b[2]["text"].replace("bar", "kPa")
        elif name == "negation": b[2]["text"] = b[2]["text"].replace(" not", "")
        elif name == "section": del b[3:5]
        elif name == "table-value": b[-1]["cells"][3]["text"] = "100"
        elif name == "table-swap":
            b[-1]["cells"][3]["text"], b[-1]["cells"][4]["text"] = "20", "10"
        elif name == "table-unit": b[-1]["cells"][0]["text"] = "Pressure (kPa)"
        elif name == "table-span": b[-1]["cells"][0]["column_span"] = 1
        elif name == "table-omission": b.pop()
        case = {"id": name, "label": label, "change": change, "expected": expected}
        if name == "section": case["target_bbox"] = [55, 205, 555, 268]
        if name == "table-omission": case["target_bbox"] = [60, 320, 552, 452]
        cases.append(case)
        save(MATERIALS / f"candidates/{name}.json", candidate)
    inputs = [native, scan, MATERIALS / "source.md", *sorted((MATERIALS / "candidates").glob("*.json"))]
    save(MATERIALS / "experiment.json", {
        "prepared_at": datetime.now(timezone.utc).isoformat(), "cases": cases, "pdf_checks": pdf_checks,
        "depths": {"native": 2, "scan": 1},
        "expected_methods": {"native": ["pdfplumber", "tesseract"], "scan": ["tesseract"]},
        "scan_recipe": "Native PDF rendered at 216 dpi, grayscale JPEG quality 90, image-only PDF; no OCR layer",
        "success_rule": "Clean: pass with zero findings. Mutation: all specified kinds/targets located and review or failure. All requested methods must complete and independently meet each case expectation.",
        "input_sha256": {str(p.relative_to(MATERIALS)): digest(p) for p in inputs},
        "validator_sha256": {str(p.relative_to(ROOT)): digest(p) for p in sorted((ROOT / "pdf_validator").glob("*.py"))},
    })
    print("Prepared two PDFs, one clean candidate and nine isolated mutations; expectations frozen.", flush=True)


def matched(finding, kind, target, box):
    if finding["kind"] != kind or not finding["bbox"]:
        return False
    if target is not None:
        return target in finding["upstream_ids"]
    x0, y0, x1, y1 = finding["bbox"]
    return box[0] <= (x0 + x1) / 2 <= box[2] and box[1] <= (y0 + y1) / 2 <= box[3]


def run():
    output = HERE / "results" / datetime.now(timezone.utc).strftime("run-%Y%m%dT%H%M%S-%fZ")
    output.mkdir(parents=True, exist_ok=False)
    print(f"Results: {output}", flush=True)
    experiment = json.loads((MATERIALS / "experiment.json").read_text())
    for base, key in ((MATERIALS, "input_sha256"), (ROOT, "validator_sha256")):
        assert all(digest(base / p) == h for p, h in experiment[key].items()), f"Changed frozen files: {key}"
    started = perf_counter()
    rows = []
    for form in ("native", "scan"):
        for case in experiment["cases"]:
            pdf = MATERIALS / f"output/pdf/pump-check-{form}.pdf"
            candidate = MATERIALS / f"candidates/{case['id']}.json"
            report = validate(pdf, candidate, experiment["depths"][form])
            report_name = f"reports/{form}-{case['id']}.json"
            save(output / report_name, report)
            methods = report["pages"][0]["effective_methods"]
            checks = {}
            matching = []
            for method in experiment["expected_methods"][form]:
                findings = [f for f in report["findings"] if f["method"] == method]
                if not case["expected"]:
                    checks[method] = not findings
                else:
                    checks[method] = all(any(matched(f, kind, target, case.get("target_bbox")) for f in findings)
                                         for kind, target in case["expected"])
                    matching.extend(f["id"] for f in findings if any(
                        matched(f, kind, target, case.get("target_bbox")) for kind, target in case["expected"]))
            status = report["document"]["status"]
            expected_status = status == "pass" and not report["findings"] if not case["expected"] else status in {"failed", "review_required"}
            passed = expected_status and methods == experiment["expected_methods"][form] and all(checks.values())
            row = {"form": form, "case": case["id"], "label": case["label"], "change": case["change"],
                   "passed": passed, "status": status, "effective_methods": methods,
                   "method_expectations_met": checks, "matching_finding_ids": matching,
                   "finding_kinds": sorted({f["kind"] for f in report["findings"]}), "report": report_name}
            rows.append(row)
            print(f"{form:6} {case['id']:15} {'PASS' if passed else 'FAIL'} {status} {checks}", flush=True)
    unchanged = all(digest(MATERIALS / p) == h for p, h in experiment["input_sha256"].items())
    code_unchanged = all(digest(ROOT / p) == h for p, h in experiment["validator_sha256"].items())
    success = all(r["passed"] for r in rows) and unchanged and code_unchanged
    result = {"status": "PASS" if success else "FAIL", "executed_at": datetime.now(timezone.utc).isoformat(),
              "total": len(rows), "passed": sum(r["passed"] for r in rows), "elapsed_seconds": round(perf_counter()-started, 3),
              "inputs_unchanged": unchanged, "validator_unchanged": code_unchanged,
              "experiment_sha256": digest(MATERIALS / "experiment.json"), "rows": rows}
    save(output / "results.json", result)
    lines = ["# 1. Error detection on the same content in text and simulated scanned PDFs", "",
             f"Test: {result['status']}｜{result['passed']}/{result['total']} passed. The unit is PDF form × candidate JSON: 2 × 10 cases.", "",
             "## 1.1 Content and procedure", "",
             "An authored pump-check page is rendered as a selectable-text PDF and an image-only simulated scan. The scan is a 216 dpi grayscale JPEG embedded in PDF, with no hidden text layer.", "",
             "The same clean JSON and nine independently mutated candidates are used for both PDF forms. Errors, target locations and success criteria are frozen in experiment.json before execution. The text PDF requests Depth 2 and requires pdfplumber and Tesseract each to locate the targets; the scan requests Depth 1 and requires Tesseract.", "",
             "Success requires the clean control to pass with no findings. Each mutation must produce the specified finding kind at the relevant paragraph, cell or missing region. Incomplete methods, unrelated alerts and score changes alone do not count as success.", "",
             "## 1.2 Observed results", "", "| JSON change | Text PDF | Simulated scan |", "| --- | --- | --- |"]
    for case in experiment["cases"]:
        pair = [next(r for r in rows if r["form"] == form and r["case"] == case["id"]) for form in ("native", "scan")]
        cells = [f"[{'PASS' if r['passed'] else 'FAIL'}]({r['report']})" for r in pair]
        lines.append(f"| {case['label']}: {case['change']} | {cells[0]} | {cells[1]} |")
    lines += ["", f"Elapsed: {result['elapsed_seconds']} seconds. Inputs unchanged: {unchanged}; validator unchanged: {code_unchanged}. Per-method results, finding locations, raw readings and tool versions are in reports/.", "",
              "## 1.3 Interpretation and reproduction", "",
              "This is a small controlled functional experiment. Its findings apply to the listed errors and the two PDF forms. They do not measure business accuracy, and repeated detection does not establish an incremental benefit from additional methods.", "",
              "Whole-table omission uses expected_tables fixed with the source and retained in every mutated candidate. Expected scope is not regenerated from erroneous candidates. The simulated scan does not include camera skew, low resolution or complex backgrounds.", "",
              "[Authored text](../../materials/source.md) · [Text PDF](../../materials/output/pdf/pump-check-native.pdf) · [Simulated scan](../../materials/output/pdf/pump-check-scan.pdf) · [Clean JSON](../../materials/candidates/clean.json) · [Frozen experiment](../../materials/experiment.json) · [Machine-readable results](results.json)", "",
              "From the project root, reproduce the frozen inputs using the project environment:", "", "```bash",
              ".venv/bin/python tests/controlled-example-20261006/run_experiment.py run", "```", "",
              "prepare refuses to overwrite frozen materials; each run saves results in a new directory.", ""]
    (output / "results.md").write_text("\n".join(lines), encoding="utf-8")
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in {"prepare", "run"}:
        raise SystemExit("Usage: run_experiment.py prepare|run")
    prepare() if sys.argv[1] == "prepare" else run()
