# Pump check sheet

## 1 Operating limit

Pressure must not exceed 10 bar.

## 2 Inspection

Inspect the inlet filter every 20 days.

Table: the top header 'Pressure (bar)' spans both columns.

| Pump Alpha | Pump Beta |
| --- | --- |
| 10 | 20 |

Synthetic test content only; not operating guidance.
