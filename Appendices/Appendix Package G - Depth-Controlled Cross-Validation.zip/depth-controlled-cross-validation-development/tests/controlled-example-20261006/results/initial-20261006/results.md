# 1. Error detection on the same content in text and simulated scanned PDFs

Test: FAIL｜18/20 passed. The unit is PDF form × candidate JSON: 2 × 10 cases.

## 1.1 Content and procedure

An authored pump-check page is rendered as a selectable-text PDF and an image-only simulated scan. The scan is a 216 dpi grayscale JPEG embedded in PDF, with no hidden text layer.

The same clean JSON and nine independently mutated candidates are used for both PDF forms. Errors, target locations and success criteria are frozen in experiment.json before execution. The text PDF requests Depth 2 and requires pdfplumber and Tesseract each to locate the targets; the scan requests Depth 1 and requires Tesseract.

Success requires the clean control to pass with no findings. Each mutation must produce the specified finding kind at the relevant paragraph, cell or missing region. Incomplete methods, unrelated alerts and score changes alone do not count as success.

## 1.2 Observed results

| JSON change | Text PDF | Simulated scan |
| --- | --- | --- |
| Clean control: Unchanged | [FAIL](reports/native-clean.json) | [FAIL](reports/scan-clean.json) |
| Body number: 10 bar → 100 bar | [PASS](reports/native-number.json) | [PASS](reports/scan-number.json) |
| Body unit: 10 bar → 10 kPa | [PASS](reports/native-unit.json) | [PASS](reports/scan-unit.json) |
| Negation: must not exceed → must exceed | [PASS](reports/native-negation.json) | [PASS](reports/scan-negation.json) |
| Whole-section omission: Remove the section 2 heading and body | [PASS](reports/native-section.json) | [PASS](reports/scan-section.json) |
| Table value: Pump Alpha: 10 → 100 | [PASS](reports/native-table-value.json) | [PASS](reports/scan-table-value.json) |
| Swapped columns: Swap 10 and 20 between columns | [PASS](reports/native-table-swap.json) | [PASS](reports/scan-table-swap.json) |
| Header unit: Pressure (bar) → Pressure (kPa) | [PASS](reports/native-table-unit.json) | [PASS](reports/scan-table-unit.json) |
| Merged cell: Header spans 2 columns → 1 column | [PASS](reports/native-table-span.json) | [PASS](reports/scan-table-span.json) |
| Whole-table omission: Remove the table; retain the independent source inventory | [PASS](reports/native-table-omission.json) | [PASS](reports/scan-table-omission.json) |

Elapsed: 13.953 seconds. Inputs unchanged: True; validator unchanged: True. Per-method results, finding locations, raw readings and tool versions are in reports/.

## 1.3 Interpretation and reproduction

All nine injected error types were detected in both PDF forms: 18/18 mutated cases met the frozen localization criteria. Both clean controls had the same false positive, leaving overall acceptance at 18/20. These are nine errors tested in two forms, not 18 independent documents.

For the text PDF, pdfplumber returned no findings on the clean control and detected all nine errors. Tesseract detected all nine errors in both forms but also falsely flagged the correct inspection paragraph. That unrelated alert was not counted as successful detection of an injected error.

Diagnosis: the source and raw OCR both read `Inspect the inlet filter every 20 days.`, but the comparison evidence reads `Inspect the inlet filter 20 days. every`. `_text_in_box()` in `pdf_validator/validate.py` sorts by `(round(y0 / 5), x0)`. The top coordinate of `every`, 254.333 points, falls into group 51; the other words are around 252.333 points in group 50. Splitting one line into two groups changes word order. Each clean-control report has one `text_difference` for this paragraph.

The next repair is same-line order reconstruction, followed by rerunning both clean controls and corresponding mutations without changing these inputs. The original testing task retained its failures; it did not modify validator code, adjust samples or relax acceptance criteria.

This is a small controlled functional experiment. Its findings apply to the listed errors and the two PDF forms. They do not measure business accuracy, and repeated detection does not establish an incremental benefit from additional methods.

Whole-table omission uses expected_tables fixed with the source and retained in every mutated candidate. Expected scope is not regenerated from erroneous candidates. The simulated scan does not include camera skew, low resolution or complex backgrounds.

[Authored text](../../materials/source.md) · [Text PDF](../../materials/output/pdf/pump-check-native.pdf) · [Simulated scan](../../materials/output/pdf/pump-check-scan.pdf) · [Clean JSON](../../materials/candidates/clean.json) · [Frozen experiment](../../materials/experiment.json) · [Machine-readable results](results.json)

From the project root, reproduce the frozen inputs using the project environment:

```bash
.venv/bin/python tests/controlled-example-20261006/run_experiment.py run
```

Use prepare only in a fresh experiment directory; it refuses to overwrite frozen materials. Then use run.

English translation of the historical report. Execution dates, findings and outcomes are unchanged. The original experiment hash in results.json identifies the pre-translation metadata; PDF, candidate and validator hashes remain unchanged.
