"""Real text/raster PDF routing and structured source-cell checks."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from pdf_validator.evidence import _tesseract_pipeline, _render, _pdfium, read_page, selected_methods
from pdf_validator.input import Box
from pdf_validator.validate import validate
from test_validator import sample_pdf


class TypeMethodTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); self.pdf = self.root / 'native.pdf'
        self.data = sample_pdf(self.pdf)
        self.scan = self.root / 'scan.pdf'
        c = canvas.Canvas(str(self.scan), pagesize=(612, 792))
        c.drawImage(ImageReader(_render(self.pdf,0)), 0, 0, 612, 792); c.save()
        self.region = (Box(60,192,260,272),)

    def report(self,data,depth=1):
        p=self.root/'candidate.json';p.write_text(json.dumps(data))
        return validate(self.scan,p,depth)

    def test_regulatory_scan_has_one_real_method_not_four_ocr_settings(self):
        self.assertFalse(_pdfium(self.scan,0).text.strip())
        obs=read_page(self.scan,0,(612,792),4,(),document_type='legal')
        self.assertEqual([o.method for o in obs if o.status=='ok'],['tesseract'])
        self.assertTrue(all(o.status=='unavailable' for o in obs[1:]))

    def test_table_pipeline_returns_source_coordinates_and_cells(self):
        o=_tesseract_pipeline(self.scan,0,(612,792),'eng',self.region,True)
        self.assertEqual(o.status,'ok',o.error)
        self.assertEqual({w.text for w in o.words},{'A','B','1','2'})
        self.assertTrue(all(self.region[0].contains_center(w.box) for w in o.words))
        self.assertEqual([(c.row,c.column,c.text,c.row_span,c.column_span) for c in o.table_cells[0]],
                         [(0,0,'A',1,1),(0,1,'B',1,1),(1,0,'1',1,1),(1,1,'2',1,1)])

    def test_scan_table_swapped_values_without_cell_boxes_are_detected_at_depth_one(self):
        self.data.update(document_type='deployment_report',expected_regions=[{'page_index':0,'bbox':[60,192,260,272]}])
        table=self.data['pages'][0]['blocks'][2];self.data['pages'][0]['blocks']=[table]
        for cell in table['cells']:cell.pop('bbox')
        baseline=self.report(self.data)
        self.assertEqual(baseline['document']['status'],'pass',baseline['findings'])
        table['cells'][2]['text'],table['cells'][3]['text']='2','1'
        bad=self.report(self.data)
        self.assertTrue(any(f['kind']=='table_row_alignment_disagreement' and f['bbox'] for f in bad['findings']))

    def test_scan_manual_missing_section_content_is_located(self):
        self.data.update(document_type='user_manual',expected_regions=[{'page_index':0,'bbox':[50,55,280,140]}])
        self.data['pages'][0]['blocks']=self.data['pages'][0]['blocks'][:1]
        report=self.report(self.data)
        self.assertTrue(any(f['kind']=='pdf_region_missing_from_json' and f['bbox'] for f in report['findings']))
        self.assertEqual(report['pages'][0]['evidence_families'],['visual_ocr'])

    def test_borderless_region_never_invents_structure_or_effective_depth(self):
        o=_tesseract_pipeline(self.scan,0,(612,792),'eng',(Box(50,55,280,140),),True)
        self.assertEqual(o.status,'empty');self.assertFalse(o.table_cells)
        self.assertIn('unverified',o.error)
        self.data.update(document_type='facility_certificate',expected_regions=[{'page_index':0,'bbox':[50,55,280,140]}])
        self.data['pages'][0]['blocks']=[]
        report=self.report(self.data)
        self.assertEqual(report['pages'][0]['effective_depth'],0)
        self.assertTrue(any(f['kind']=='expected_table_missing' for f in report['findings']))

    def test_upstream_tesseract_alias_excludes_all_ocr_settings(self):
        for alias in ('tesseract','cell_ocr','highres_ocr'):
            obs=read_page(self.scan,0,(612,792),1,(alias,),document_type='user_manual')
            self.assertTrue(all(o.status!='ok' for o in obs))
            self.assertEqual(obs[0].status,'excluded_upstream')

    def test_methods_follow_content_and_actual_text_availability(self):
        self.assertEqual(selected_methods(1,True,'legal'),('poppler',))
        self.assertEqual(selected_methods(1,True,'legal',tables=True),('pdfplumber',))
        self.assertEqual(selected_methods(1,False,'legal',tables=True),('tesseract',))
        self.assertEqual(selected_methods(1,True,'user_manual'),('tesseract',))
        self.assertEqual(selected_methods(1,True,'user_manual',tables=True),('pdfplumber',))

if __name__=='__main__':unittest.main()
