"""Acceptance checks: source PDFs to findings, plus explicit fault-injection boundaries."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from pdf_validator.evidence import _render, _pdfplumber, Observation, read_page
from pdf_validator.input import InputError
from pdf_validator.validate import validate
from test_validator import sample_pdf


class CrossValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.pdf=self.root/'source.pdf';self.candidate=self.root/'candidate.json'
        self.data=sample_pdf(self.pdf)

    def report(self,depth=1,order=None):
        self.candidate.write_text(json.dumps(self.data))
        return validate(self.pdf,self.candidate,depth,method_order=order)

    def rasterize(self):
        image=_render(self.pdf,0)
        pdf=canvas.Canvas(str(self.pdf),pagesize=(612,792))
        pdf.drawImage(ImageReader(image),0,0,612,792);pdf.save()

    def prose(self):
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.setFont('Helvetica',12)
        c.drawString(60,700,'Dose must not exceed 10 mg.');c.save()
        self.data={'document_type':'legal','pages':[{'page_index':0,'blocks':[
            {'id':'p','type':'paragraph','text':'Dose must not exceed 10 mg.','bbox':[55,78,400,106],'order':0}]}]}

    def certificate(self):
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.setFont('Helvetica',12)
        for text,y in [('Product Pump Alpha',700),('Pressure: 10 bar',670),('Product Pump Beta',600),('Pressure: 20 bar',570)]:
            c.drawString(60,y,text)
        c.save()
        self.data={'document_type':'product_certificate','pages':[{'page_index':0,'blocks':[
            {'id':'a','type':'heading','text':'Product Pump Alpha','bbox':[55,78,300,105],'heading_level':1,'order':0},
            {'id':'fa','type':'field','field_name':'Pressure','value':'10','unit':'bar','entity_id':'a','bbox':[55,110,300,133],'order':1},
            {'id':'b','type':'heading','text':'Product Pump Beta','bbox':[55,178,300,205],'heading_level':1,'order':2},
            {'id':'fb','type':'field','field_name':'Pressure','value':'20','unit':'bar','entity_id':'b','bbox':[55,210,300,233],'order':3}]}]}

    def merged_table(self):
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.setFont('Helvetica',12)
        for y in (600,550,500):c.line(60,y,360,y)
        for x in (60,360):c.line(x,500,x,600)
        c.line(210,500,210,550)
        for text,x,y in [('Pressure (bar)',75,575),('10',75,525),('20',225,525)]:c.drawString(x,y,text)
        c.save()
        self.data={'document_type':'facility_certificate','expected_regions':[{'page_index':0,'bbox':[60,192,360,292]}],
                   'pages':[{'page_index':0,'blocks':[{'id':'t','type':'table','bbox':[60,192,360,292],
                       'cells':[{'id':'h','row':0,'column':0,'column_span':2,'text':'Pressure (bar)'},
                                {'id':'a','row':1,'column':0,'text':'10'}, {'id':'b','row':1,'column':1,'text':'20'}]}]}]}

    def test_native_prose_three_distinct_readings_and_stable_scope(self):
        self.prose();self.data['pages'][0]['blocks'][0]['text']='Dose must exceed 100 kg.'
        reports=[self.report(d) for d in (1,2,3,4,5)]
        self.assertEqual(len({r['scope_sha256'] for r in reports}),1)
        self.assertEqual([r['pages'][0]['effective_depth'] for r in reports],[1,2,3,3,3])
        for left,right in zip(reports,reports[1:]):
            prior={f['id']:f for f in left['findings'] if f['method']}
            newer={f['id']:f for f in right['findings'] if f['method']}
            self.assertTrue(all(newer.get(k)==v for k,v in prior.items()))
        self.assertEqual(reports[0]['pages'][0]['effective_methods'],['poppler'])
        self.assertEqual(reports[2]['pages'][0]['effective_methods'],['poppler','pdfplumber','tesseract'])

    def test_matching_later_reader_cannot_erase_earlier_discrepancy(self):
        self.prose(); self.data['pages'][0]['blocks'][0]['text']='Dose must exceed 10 mg.'
        original=_pdfplumber(self.pdf,0)
        from dataclasses import replace
        # Fault injection: a later reader omits the same negation as the candidate.
        bad=replace(original,words=[w for w in original.words if w.text!='not'],text='Dose must exceed 10 mg.')
        d1=self.report(1)
        with patch('pdf_validator.evidence._pdfplumber',return_value=bad):d2=self.report(2)
        prior=[f for f in d1['findings'] if f['method']=='poppler']
        self.assertTrue(prior)
        self.assertTrue(all(f in d2['findings'] for f in prior))
        self.assertNotEqual(d2['document']['status'],'pass')

    def test_scan_prose_omission_number_unit_negation(self):
        self.prose();self.rasterize();clean=self.report(1)
        self.assertEqual(clean['document']['status'],'pass',clean['findings'])
        for text in ('Dose must not exceed 100 mg.','Dose must not exceed 10 kg.','Dose must exceed 10 mg.','Dose must not exceed.'):
            with self.subTest(text=text):
                self.data['pages'][0]['blocks'][0]['text']=text;r=self.report(1)
                self.assertTrue(any(f['kind']=='critical_text_difference' and f['method']=='tesseract' for f in r['findings']))

    def test_certificate_name_value_unit_and_product_associations_native(self):
        self.certificate();clean=self.report(1)
        self.assertEqual(clean['document']['status'],'pass',clean['findings'])
        original=deepcopy(self.data)
        for field,value,kind in [('field_name','Temperature','text_difference'),('value','100','critical_text_difference'),
                                 ('unit','kg','critical_text_difference'),('entity_id','b','field_entity_association_difference')]:
            with self.subTest(field=field):
                self.data=deepcopy(original);self.data['pages'][0]['blocks'][1][field]=value
                self.assertTrue(any(f['kind']==kind for f in self.report(1)['findings']))

    def test_certificate_scan_wrong_product_association(self):
        self.certificate();self.rasterize();clean=self.report(1)
        self.assertEqual(clean['document']['status'],'pass',clean['findings'])
        self.data['pages'][0]['blocks'][3]['entity_id']='a'
        r=self.report(1)
        self.assertTrue(any(f['kind']=='field_entity_association_difference' for f in r['findings']))
        self.assertEqual(r['pages'][0]['source_type'],'scan')

    def test_manual_whole_section_omission_order_and_parent(self):
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.setFont('Helvetica',12)
        for text,y in [('1 Installation',700),('Do not exceed 10 bar.',670),('2 Operation',600),('Inspect every 20 days.',570)]:
            c.drawString(60,y,text)
        c.save();self.rasterize()
        self.data={'document_type':'user_manual','expected_regions':[{'page_index':0,'bbox':[50,75,400,140]},
                      {'page_index':0,'bbox':[50,175,400,240]}], 'pages':[{'page_index':0,'blocks':[
            {'id':'s1','type':'heading','text':'1 Installation','heading_level':1,'order':0,'bbox':[55,78,350,106]},
            {'id':'p1','type':'list_item','text':'Do not exceed 10 bar.','order':1,'parent_id':'s1','bbox':[55,110,350,135]},
            {'id':'s2','type':'heading','text':'2 Operation','heading_level':1,'order':2,'bbox':[55,178,350,206]},
            {'id':'p2','type':'list_item','text':'Inspect every 20 days.','order':3,'parent_id':'s2','bbox':[55,210,350,235]}]}]}
        good=self.report(1);self.assertEqual(good['document']['status'],'pass',good['findings'])
        original=deepcopy(self.data)
        self.data['pages'][0]['blocks']=self.data['pages'][0]['blocks'][:2]
        absent=self.report(1)
        self.assertEqual(good['scope_sha256'],absent['scope_sha256'])
        self.assertTrue(any(f['kind']=='pdf_region_missing_from_json' and f['bbox'][1]>175 for f in absent['findings']))
        self.data=deepcopy(original);self.data['pages'][0]['blocks'][2]['order']=0
        self.data['pages'][0]['blocks'][0]['order']=2
        self.assertTrue(any(f['kind']=='reading_order_conflict' for f in self.report()['findings']))
        self.data=original;self.data['pages'][0]['blocks'][3]['parent_id']='s1'
        self.assertTrue(any(f['kind']=='paragraph_association_difference' for f in self.report()['findings']))

    def test_native_merged_table_header_units_and_span(self):
        self.merged_table();clean=self.report(1)
        self.assertEqual(clean['document']['status'],'pass',clean['findings'])
        cell=self.data['pages'][0]['blocks'][0]['cells'][0];cell['column_span']=1
        self.assertTrue(any(f['kind']=='merged_cell_relationship_difference' for f in self.report()['findings']))
        cell['column_span']=2;cell['text']='Pressure (kPa)'
        self.assertTrue(any(f['kind']=='table_row_alignment_disagreement' and f['upstream_ids']==['t','h'] for f in self.report()['findings']))

    def test_scan_merged_table_source_relationships(self):
        self.merged_table();self.rasterize();clean=self.report(1)
        self.assertEqual(clean['document']['status'],'pass',clean['findings'])
        self.data['pages'][0]['blocks'][0]['cells'][0]['column_span']=1
        self.assertTrue(any(f['kind']=='merged_cell_relationship_difference' for f in self.report()['findings']))

    def test_tables_inside_regulation_and_manual_use_structure_at_depth_one(self):
        self.merged_table()
        for profile in ('legal','user_manual'):
            with self.subTest(profile=profile):
                self.data['document_type']=profile
                if profile=='legal':self.data['extraction_scope']='tables'
                self.data['pages'][0]['blocks'][0]['cells'][1]['column']=1
                self.data['pages'][0]['blocks'][0]['cells'][2]['column']=0
                r=self.report(1)
                self.assertEqual(r['pages'][0]['methods'][0]['name'],'pdfplumber')
                self.assertTrue(any(f['kind']=='table_row_alignment_disagreement' for f in r['findings']))

    def test_whole_table_missing_in_all_four_business_profiles(self):
        self.merged_table()
        for profile in ('legal','user_manual','deployment_report','facility_certificate'):
            self.data.update(document_type=profile,extraction_scope='tables')
            self.data['pages'][0]['blocks']=[]
            r=self.report(1)
            self.assertTrue(any(f['kind']=='expected_table_missing' for f in r['findings']),profile)
        self.rasterize();r=self.report(1)
        self.assertTrue(any(f['kind']=='expected_table_missing' and f['method']=='tesseract' for f in r['findings']))

    def test_unknown_table_layout_is_unverified_at_depth_one(self):
        self.prose();self.data['expected_tables']=[{'page_index':0,'bbox':[55,78,400,106]}]
        self.data['pages'][0]['blocks']=[{'id':'t','type':'table','text':'Dose must not exceed 10 mg.','bbox':[55,78,400,106]}]
        r=self.report(1)
        self.assertEqual(r['pages'][0]['effective_depth'],0)
        self.assertTrue(any(f['kind']=='table_structure_unverified' for f in r['findings']))
        self.assertNotIn('poppler',[m['name'] for m in r['pages'][0]['methods']])

    def test_actual_missing_ocr_language_reports_error_and_zero_depth(self):
        self.prose();self.rasterize();self.candidate.write_text(json.dumps(self.data))
        r=validate(self.pdf,self.candidate,1,language='not_installed_language')
        self.assertEqual(r['pages'][0]['methods'][0]['status'],'error')
        self.assertEqual(r['pages'][0]['effective_depth'],0)
        self.assertTrue(any(f['kind']=='method_failed' for f in r['findings']))

    def test_unavailable_method_falls_back_and_records_unexecuted_status(self):
        self.prose()
        r=self.report(1,{'text':['docling','poppler']})
        self.assertEqual(r['pages'][0]['methods'][0]['status'],'unavailable')
        self.assertEqual(r['pages'][0]['effective_methods'],['poppler'])

    def test_inapplicable_text_reader_is_not_counted_on_scan(self):
        self.prose();self.rasterize()
        r=self.report(1,{'scan':['poppler','pdfplumber','tesseract']})
        self.assertEqual([m['status'] for m in r['pages'][0]['methods']],['not_applicable','not_applicable','ok'])
        self.assertEqual(r['pages'][0]['effective_depth'],1)

    def test_ocr_variants_duplicate_names_and_bad_configuration_rejected(self):
        for order in ({'text':['tesseract','highres_ocr']},{'text':['poppler','poppler']}, {'invalid':['poppler']},[],{'text':[]}):
            with self.subTest(order=order),self.assertRaises(InputError):self.report(1,order)

    def test_invalid_spans_fields_inventory_and_model_rejected(self):
        original=deepcopy(self.data)
        for value in (0,-1,True,1.5):
            self.data=deepcopy(original);self.data['pages'][0]['blocks'][2]['cells'][0]['row_span']=value
            with self.assertRaises(InputError):self.report()
        self.data=deepcopy(original);self.data['expected_tables']=[{'page_index':0}]
        with self.assertRaises(InputError):self.report()
        self.data=deepcopy(original);self.data['upstream_model']=[]
        with self.assertRaises(InputError):self.report()
        self.certificate();self.data['pages'][0]['blocks'][1]['value']=10
        with self.assertRaises(InputError):self.report()

    def test_candidate_and_original_immutable_and_fifth_layer_never_executes(self):
        self.prose();self.data['upstream_model']='upstream-model-identifier'
        original=self.pdf.read_bytes();r=self.report(5);candidate=self.candidate.read_bytes()
        self.assertEqual(r['pdf_sha256'],sha256(original).hexdigest())
        self.assertEqual(r['input_json_sha256'],sha256(candidate).hexdigest())
        self.assertEqual(self.pdf.read_bytes(),original)
        self.assertFalse(r['depth_5']['executed']);self.assertIsNone(r['depth_5']['review_model'])
        self.assertEqual(r['pages'][0]['methods'][-1]['status'],'not_implemented')
        self.assertEqual(r['cost']['api_fee'],0);self.assertIsNone(r['cost']['compute_fee'])
        self.assertEqual(r['cost']['ordering_basis'],'configured_priority_not_measured_ranking')
        self.assertEqual(r['cost']['method_seconds'],round(sum(m['elapsed_seconds'] for m in r['pages'][0]['methods']),6))
        self.assertTrue(all(m['cpu_seconds']>=0 for m in r['pages'][0]['methods']))

    def test_each_method_reads_original_pdf_not_previous_output(self):
        self.prose()
        from pdf_validator.evidence import _poppler,_tesseract_pipeline
        with patch('pdf_validator.evidence._poppler',wraps=_poppler) as poppler, \
             patch('pdf_validator.evidence._pdfplumber',wraps=_pdfplumber) as plumber, \
             patch('pdf_validator.evidence._tesseract_pipeline',wraps=_tesseract_pipeline) as ocr:
            r=self.report(3)
        for reader in (poppler,plumber,ocr):
            self.assertTrue(reader.called)
            self.assertTrue(all(c.args[0]==self.pdf for c in reader.call_args_list))
        self.assertEqual(len(r['pages'][0]['comparisons']),3)

    def test_mixed_page_selectable_footer_does_not_hide_scan(self):
        self.prose();image=_render(self.pdf,0)
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.drawImage(ImageReader(image),0,0,612,792)
        c.drawString(300,30,'1');c.save()
        self.data['pages'][0]['printed_page_label']='1'
        r=self.report(1)
        self.assertEqual(r['pages'][0]['source_type'],'mixed')
        self.assertEqual(r['pages'][0]['effective_methods'],['tesseract'])

    def test_table_inside_full_regulation_and_manual_section(self):
        for profile in ('legal','user_manual'):
            self.data=sample_pdf(self.pdf);self.data['document_type']=profile
            if profile=='user_manual':
                self.data['expected_regions']=[{'page_index':0,'bbox':[50,55,400,300]}]
                self.data['pages'][0]['blocks']=self.data['pages'][0]['blocks'][:3]
            self.data['pages'][0]['blocks'][2]['cells'][0]['text']='Wrong header'
            r=self.report(1)
            self.assertEqual(r['pages'][0]['methods'][0]['name'],'pdfplumber')
            self.assertTrue(any(f['kind']=='table_row_alignment_disagreement' for f in r['findings']))

    def test_vertical_merge_is_checked_native_and_scan(self):
        c=canvas.Canvas(str(self.pdf),pagesize=(612,792));c.setFont('Helvetica',12)
        for x in (60,210,360):c.line(x,500,x,600)
        for y in (500,600):c.line(60,y,360,y)
        c.line(210,550,360,550)
        for text,x,y in [('Pressure bar',75,575),('10',225,575),('20',225,525)]:c.drawString(x,y,text)
        c.save()
        self.data={'document_type':'deployment_report','expected_regions':[{'page_index':0,'bbox':[60,192,360,292]}],
                   'pages':[{'page_index':0,'blocks':[{'id':'t','type':'table','bbox':[60,192,360,292],
                       'cells':[{'id':'h','row':0,'column':0,'row_span':2,'text':'Pressure bar'},
                                {'id':'a','row':0,'column':1,'text':'10'}, {'id':'b','row':1,'column':1,'text':'20'}]}]}]}
        for scanned in (False,True):
            if scanned:self.rasterize()
            clean=self.report();self.assertEqual(clean['document']['status'],'pass',clean['findings'])
            self.data['pages'][0]['blocks'][0]['cells'][0]['row_span']=1
            self.assertTrue(any(f['kind']=='merged_cell_relationship_difference' for f in self.report()['findings']))
            self.data['pages'][0]['blocks'][0]['cells'][0]['row_span']=2

    def test_unstructured_certificate_never_claims_complete_field_depth(self):
        self.data['document_type']='product_certificate'
        r=self.report(2)
        self.assertEqual(r['pages'][0]['effective_depth'],0)
        self.assertTrue(any(f['kind']=='certificate_fields_unstructured' for f in r['findings']))
        self.assertTrue(all(not c['complete_for_scope'] for c in r['pages'][0]['comparisons']))

    def test_missing_page_is_failed_without_inventing_method_checks(self):
        self.data['pages']=[]
        r=self.report(4)
        self.assertEqual(r['pages'][0]['effective_depth'],0)
        self.assertFalse(r['pages'][0]['methods'])
        self.assertEqual(r['pages'][0]['source_inventory']['method_skip_reason'],'candidate_page_absent')
        self.assertEqual(r['document']['status'],'failed')

    def test_same_candidate_different_depths_keep_table_scope_and_every_prior_method_finding(self):
        table=self.data['pages'][0]['blocks'][2]
        self.data.update(document_type='deployment_report',expected_regions=[{'page_index':0,'bbox':table['bbox']}])
        self.data['pages'][0]['blocks']=[table];table['cells'][2]['text']='100'
        low,high=self.report(1),self.report(4)
        self.assertEqual(low['scope_sha256'],high['scope_sha256'])
        self.assertTrue(all(f in high['findings'] for f in low['findings'] if f['method']))
        self.assertEqual(low['pages'][0]['comparisons'][0],high['pages'][0]['comparisons'][0])

    def test_cli_rejects_hardlink_overwrite_and_summary_collision(self):
        import subprocess,sys,os
        self.candidate.write_text(json.dumps(self.data));before=self.candidate.read_bytes()
        output=self.root/'input-alias.json';os.link(self.candidate,output)
        for destination in (output,self.root/'report.md'):
            result=subprocess.run([sys.executable,'-m','pdf_validator','--pdf',str(self.pdf),
                '--json',str(self.candidate),'--depth','1','--output',str(destination)],capture_output=True,text=True)
            self.assertEqual(result.returncode,2,result.stderr)
        self.assertEqual(before,self.candidate.read_bytes())

    def test_partial_source_parser_preserves_reads_but_cannot_claim_complete_depth(self):
        self.prose()
        from dataclasses import replace
        partial=replace(_pdfplumber(self.pdf,0),error='table detection incomplete')
        with patch('pdf_validator.evidence._pdfplumber',return_value=partial):
            r=self.report(1,{'text':['pdfplumber']})
        self.assertEqual(r['pages'][0]['effective_depth'],0)
        self.assertTrue(r['pages'][0]['comparisons'][0]['source_reading']['text'])
        self.assertTrue(any(f['kind']=='method_partial' for f in r['findings']))
        self.assertNotEqual(r['document']['status'],'pass')

if __name__=='__main__':unittest.main()
