"""Independent, read-only PDF extraction validation."""

__version__ = "0.1.0"
