"""Type-specific local reading strategies and a reserved model-review layer."""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
import io
from importlib.metadata import version, PackageNotFoundError
import importlib.util
import re
import shutil
try:
    import resource
except ImportError:  # Windows: resource measurements remain unknown.
    resource = None
from pathlib import Path
import subprocess
from time import perf_counter
from tempfile import TemporaryDirectory

from .input import Box, Cell, InputError


# Configuration priority only, not a measured cost ranking.
METHODS = ("poppler", "pdfplumber", "tesseract", "docling")
DEFAULT_ORDERS = {
    "text": METHODS,
    "fields": ("pdfplumber", "tesseract", "docling", "pp_structure_v3"),
    "scan": ("tesseract", "docling", "pp_structure_v3", "mineru_basic"),
    "tables_text": ("pdfplumber", "tesseract", "docling", "pp_structure_v3"),
    "tables_scan": ("tesseract", "docling", "pp_structure_v3", "mineru_basic"),
}
FAMILIES = {"poppler": "embedded_text", "pdfplumber": "embedded_text",
            "pdfium": "embedded_text", "pypdf": "embedded_text", "tesseract": "visual_ocr",
            "docling": "structured_pipeline", "pp_structure_v3": "structured_pipeline",
            "mineru_basic": "structured_pipeline", "other_model": "model_review"}
ALIASES = {
    "poppler": {"poppler", "pdftotext"},
    "pdfplumber": {"pdfplumber", "pdfminer", "pdfminer.six"},
    "pdfium": {"pdfium", "pypdfium2"}, "pypdf": {"pypdf", "pypdf2"},
    "tesseract": {"tesseract", "tesseract-ocr", "region_ocr", "sparse_ocr",
                  "row_ocr", "cell_ocr", "highres_ocr"},
    "docling": {"docling", "tableformer"},
    "pp_structure_v3": {"pp_structure_v3", "pp-structurev3", "paddleocr"},
    "mineru_basic": {"mineru", "mineru_basic"},
}
COMPONENTS = {"poppler": ["poppler", "pdf_text_layer"],
              "pdfplumber": ["pdfminer.six", "pdf_text_layer", "pdfplumber.table_geometry"],
              "tesseract": ["tesseract", "pdfium.render", "pillow.ruling_lines", "pdfplumber.table_geometry"]}
OPTIONAL_PACKAGES = {"docling": "docling", "pp_structure_v3": "paddleocr", "mineru_basic": "mineru"}


@dataclass(frozen=True)
class Word:
    text: str
    box: Box


@dataclass(frozen=True)
class Line:
    text: str
    box: Box
    font_size: float | None = None
    bold: bool | None = None


@dataclass
class Observation:
    method: str
    family: str
    page_index: int
    status: str
    text: str = ""
    words: list[Word] = field(default_factory=list)
    lines: list[Line] = field(default_factory=list)
    tables: list[Box] = field(default_factory=list)
    images: list[Box] = field(default_factory=list)
    error: str | None = None
    shared_with_upstream: bool = False
    family_overlaps_upstream: bool = False
    elapsed_seconds: float = 0.0
    table_rows: list[list[tuple[Box, tuple[str, ...]]]] = field(default_factory=list)

    table_cells: list[list[Cell]] = field(default_factory=list)
    cpu_seconds: float | None = 0.0
    components: list[str] = field(default_factory=list)
    route: str = ""
    source_type: str = "unknown"

    def has_evidence(self) -> bool:
        return bool(self.text.strip() or self.words or self.tables or self.images)


def page_sizes(path: Path) -> list[tuple[float, float]]:
    import pypdfium2 as pdfium

    try:
        pdf = pdfium.PdfDocument(str(path))
        try:
            if len(pdf) == 0:
                raise ValueError("PDF has no pages")
            return [tuple(float(v) for v in pdf[i].get_size()) for i in range(len(pdf))]
        finally:
            pdf.close()
    except Exception as exc:
        raise ValueError(f"cannot open PDF: {exc}") from exc


def _command(args: list[str], timeout: int = 60) -> bytes:
    try:
        return subprocess.run(args, capture_output=True, check=True, timeout=timeout).stdout
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(f"{args[0]} unavailable or failed: {type(exc).__name__}") from exc


def _tsv_rows(raw: bytes) -> list[dict[str, str]]:
    return list(csv.DictReader(io.StringIO(raw.decode("utf-8", errors="replace")), delimiter="\t"))


def _box(row: dict[str, str], x: float = 1.0, y: float = 1.0) -> Box:
    left, top, width, height = (float(row[k]) for k in ("left", "top", "width", "height"))
    return Box(left * x, top * y, (left + width) * x, (top + height) * y)


def _group_words(words: list[tuple[tuple[str, ...], Word]]) -> list[Line]:
    groups: dict[tuple[str, ...], list[Word]] = {}
    for key, word in words:
        groups.setdefault(key, []).append(word)
    lines = []
    for group in groups.values():
        b = Box(min(w.box.x0 for w in group), min(w.box.y0 for w in group),
                max(w.box.x1 for w in group), max(w.box.y1 for w in group))
        lines.append(Line(" ".join(w.text for w in group), b))
    return sorted(lines, key=lambda line: (line.box.y0, line.box.x0))


def _poppler(path: Path, index: int) -> Observation:
    rows = _tsv_rows(_command(["pdftotext", "-f", str(index + 1), "-l", str(index + 1),
                               "-tsv", str(path), "-"]))
    keyed = []
    for row in rows:
        if row.get("level") == "5" and row.get("text", "").strip():
            word = Word(row["text"], _box(row))
            keyed.append(((row["block_num"], row["par_num"], row["line_num"]), word))
    words = [w for _, w in keyed]
    lines = _group_words(keyed)
    return Observation("poppler", FAMILIES["poppler"], index, "ok" if words else "empty",
                       "\n".join(line.text for line in lines), words, lines)


def _pdfplumber(path: Path, index: int) -> Observation:
    import pdfplumber

    with pdfplumber.open(path) as pdf:
        page = pdf.pages[index]
        words = [Word(w["text"], Box(w["x0"], w["top"], w["x1"], w["bottom"]))
                 for w in page.extract_words() if w["text"].strip()]
        lines = []
        for item in page.extract_text_lines():
            box = Box(item["x0"], item["top"], item["x1"], item["bottom"])
            chars = item.get("chars", [])
            font_size = max((float(c["size"]) for c in chars), default=None)
            bold = any("bold" in c.get("fontname", "").lower() for c in chars)
            lines.append(Line(item["text"], box, font_size, bold))
        try:
            found_tables = page.find_tables()
            tables = [Box(*table.bbox) for table in found_tables]
            table_rows = [[(Box(*row.bbox), tuple(cell or "" for cell in cells))
                           for row, cells in zip(table.rows, table.extract())]
                          for table in found_tables]
            table_cells = [cells_from_boxes([Box(*b) for b in t.cells],
                                              lambda b: " ".join(w.text for w in words if b.contains_center(w.box, 0)))
                           for t in found_tables]
            table_error = None
        except Exception as exc:
            tables, table_rows, table_cells, table_error = [], [], [], f"table detection failed: {type(exc).__name__}"
        images = [Box(img["x0"], img["top"], img["x1"], img["bottom"])
                  for img in page.images if all(k in img for k in ("x0", "top", "x1", "bottom"))]
    return Observation("pdfplumber", FAMILIES["pdfplumber"], index,
                       "ok" if words or tables or images else "empty",
                       "\n".join(line.text for line in lines), words, lines, tables, images, table_error,
                       table_rows=table_rows, table_cells=table_cells)


def _pdfium(path: Path, index: int) -> Observation:
    import pypdfium2 as pdfium

    pdf = pdfium.PdfDocument(str(path))
    try:
        page = pdf[index]
        textpage = page.get_textpage()
        text = textpage.get_text_range()
        # PDFium character indices are used directly; whitespace closes each word.
        words, chars, boxes = [], [], []
        def flush():
            if chars and boxes:
                words.append(Word("".join(chars), Box(min(b.x0 for b in boxes), min(b.y0 for b in boxes),
                                                     max(b.x1 for b in boxes), max(b.y1 for b in boxes))))
            chars.clear()
            boxes.clear()
        height = page.get_height()
        for i in range(textpage.count_chars()):
            char = textpage.get_text_range(i, 1)
            if not char or char.isspace():
                flush()
                continue
            left, bottom, right, top = textpage.get_charbox(i)
            if right > left and top > bottom:
                chars.append(char)
                boxes.append(Box(left, height - top, right, height - bottom))
        flush()
        lines = _group_words([((str(round(w.box.y0 / 5)),), w) for w in words])
    finally:
        pdf.close()
    return Observation("pdfium", FAMILIES["pdfium"], index, "ok" if text.strip() else "empty",
                       text, words, lines)


def cells_from_boxes(boxes: list[Box], read_text) -> list[Cell]:
    """Physical source cell rectangles define spans, including blank cells."""
    xs = sorted({v for b in boxes for v in (b.x0, b.x1)})
    ys = sorted({v for b in boxes for v in (b.y0, b.y1)})
    return [Cell(f"source-{i}", ys.index(b.y0), xs.index(b.x0), read_text(b), b,
                 ys.index(b.y1) - ys.index(b.y0), xs.index(b.x1) - xs.index(b.x0))
            for i, b in enumerate(sorted(boxes, key=lambda b: (b.y0, b.x0)))]


def _render(path: Path, index: int):
    import pypdfium2 as pdfium
    with pdfium.PdfDocument(str(path)) as pdf:
        return pdf[index].render(scale=3).to_pil().copy()


def image_tables(image, size: tuple[float, float]) -> list[list[Box]]:
    """Source-image lines, never candidate cells. Rectangular merged cells are retained."""
    from PIL import Image
    from pdfplumber.table import merge_edges, edges_to_intersections, intersections_to_cells, cells_to_tables
    binary = image.convert("L").point(lambda p: 0 if p < 140 else 255)
    sx, sy = size[0] / image.width, size[1] / image.height
    edges = []
    # ponytail: axis-aligned solid rules >= 12 pt; skewed, dotted and borderless tables need another parser.
    for vertical, view in ((False, binary), (True, binary.transpose(Image.Transpose.TRANSPOSE))):
        raw = view.tobytes()
        minimum = round(12 / (sy if vertical else sx))
        pattern = re.compile(rb"\x00{" + str(minimum).encode() + rb",}")
        for i in range(view.height):
            for match in pattern.finditer(raw[i * view.width:(i + 1) * view.width]):
                a, b = match.span()
                edges.append({"x0": i * sx if vertical else a * sx,
                              "x1": i * sx if vertical else b * sx,
                              "top": a * sy if vertical else i * sy,
                              "bottom": b * sy if vertical else i * sy,
                              "height": (b-a)*sy if vertical else 0,
                              "width": 0 if vertical else (b-a)*sx,
                              "orientation": "v" if vertical else "h"})
    if len(edges) > 20000:
        raise ValueError("Source image exceeds 20000 ruling segments; table geometry unverified")
    edges = merge_edges(edges, 2, 2, 2, 2)
    if len(edges) > 1500:
        raise ValueError("Source image exceeds 1500 merged rules; table geometry unverified")
    tables = cells_to_tables(intersections_to_cells(edges_to_intersections(edges, 2, 2)))
    return [[Box(*b) for b in table] for table in tables if len(table) > 1]


def _bounds(boxes: list[Box]) -> Box:
    return Box(min(b.x0 for b in boxes), min(b.y0 for b in boxes),
               max(b.x1 for b in boxes), max(b.y1 for b in boxes))


def inspect_page(path: Path, index: int, size: tuple[float, float], regions=None) -> dict:
    """Freeze source classification and inventory before any depth-dependent read."""
    started = perf_counter()
    errors = []
    content_weight = 20
    try:
        probe = _pdfium(path, index)
        native = any(regions is None or any(r.contains_center(w.box,0) for r in regions) for w in probe.words)
    except Exception as exc:
        native = False
        errors.append(str(exc))
    try:
        layout = _pdfplumber(path, index)
        if layout.error:
            errors.append(layout.error)
        content_weight = max(20, sum(max(1,min(20,len(line.text.split()))) for line in layout.lines
                                    if regions is None or any(r.contains_center(line.box,0) for r in regions)))
        scope_boxes = regions if regions is not None else (Box(0,0,*size),)
        large_raster = any(image.overlap(r) > r.area() * .5 for image in layout.images for r in scope_boxes)
        source_type = "mixed" if native and large_raster else "text" if native else "scan"
        native = native and not large_raster
        tables = layout.tables if native else [
            _bounds(boxes) for boxes in image_tables(_render(path, index), size)]
    except Exception as exc:
        tables = []
        errors.append(str(exc))
        source_type = "text" if native else "scan"
    if regions is not None:
        tables = [b for b in tables if any(r.contains_center(b, 0) for r in regions)]
    return {"source_type": source_type, "tables": tables,
            "content_weight": content_weight,
            "inventory_basis": "source_detection_provisional", "errors": errors,
            "elapsed_seconds": round(perf_counter() - started, 6)}


def _tesseract_pipeline(path: Path, index: int, size: tuple[float, float], language: str,
                        regions: tuple[Box, ...] | None, table_only: bool) -> Observation:
    from PIL import ImageOps
    image = _render(path, index)
    sx, sy = size[0] / image.width, size[1] / image.height
    words, lines, tables, all_cells, table_rows, errors = [], [], [], [], [], []
    try:
        grids = image_tables(image, size)
    except ValueError as exc:
        grids = []
        errors.append(str(exc))
    if regions is not None:
        grids = [g for g in grids if any(r.contains_center(_bounds(g), 0) for r in regions)]
    with TemporaryDirectory(prefix="pdf-validator-ocr-") as temp:
        target = Path(temp) / "region.png"
        def recognise(box, cell=False):
            inset = 4 if cell else 0
            x, y = max(0, round(box.x0 / sx) + inset), max(0, round(box.y0 / sy) + inset)
            right, bottom = min(image.width, round(box.x1 / sx) - inset), min(image.height, round(box.y1 / sy) - inset)
            if right <= x or bottom <= y:
                return ""
            ImageOps.expand(image.crop((x, y, right, bottom)), 10, "white").save(target)
            raw = _command(["tesseract", str(target), "stdout", "-l", language,
                            "--psm", "6" if cell or regions is not None else "3", "tsv"], timeout=120)
            keyed = []
            for row in _tsv_rows(raw):
                if row.get("level") == "5" and row.get("text", "").strip():
                    b = _box(row)
                    position = Box((x + b.x0 - 10)*sx, (y + b.y0 - 10)*sy,
                                   (x + b.x1 - 10)*sx, (y + b.y1 - 10)*sy)
                    keyed.append(((row["block_num"], row["par_num"], row["line_num"]), Word(row["text"], position)))
            words.extend(w for _, w in keyed)
            lines.extend(_group_words(keyed))
            return " ".join(w.text for _, w in keyed)
        if not table_only:
            for region in regions if regions is not None else (Box(0, 0, *size),):
                recognise(region)
            boxes = [_bounds(g) for g in grids]
            words[:] = [w for w in words if not any(b.contains_center(w.box, 0) for b in boxes)]
            lines[:] = [l for l in lines if not any(b.contains_center(l.box, 0) for b in boxes)]
        for grid in grids:
            if len(grid) > 200:
                errors.append("Source grid exceeds 200 cells; structure unverified")
                continue
            cells = cells_from_boxes(grid, lambda b: recognise(b, cell=True))
            tables.append(_bounds(grid)); all_cells.append(cells)
            rows = []
            for row in range(max(c.row + c.row_span for c in cells)):
                row_cells = [c for c in cells if c.row == row]
                if row_cells:
                    width = max(c.column + c.column_span for c in cells)
                    rows.append((_bounds([c.bbox for c in row_cells]),
                                 tuple(next((c.text for c in row_cells if c.column == col), "") for col in range(width))))
            table_rows.append(rows)
    if table_only and not tables:
        errors.append("No source ruling-line table recovered; structure unverified")
    return Observation("tesseract", "visual_ocr", index, "ok" if words or tables else "empty",
                       "\n".join(l.text for l in lines), words, lines, tables=tables,
                       table_rows=table_rows, table_cells=all_cells, error="; ".join(errors) or None)


def validate_orders(orders: dict | None) -> dict:
    if orders is None:
        return dict(DEFAULT_ORDERS)
    if not isinstance(orders, dict) or set(orders) - set(DEFAULT_ORDERS):
        raise InputError("method order must map supported routes to method name arrays")
    result = dict(DEFAULT_ORDERS)
    for route, names in orders.items():
        if not isinstance(names, (list, tuple)) or not names or any(not isinstance(n, str) for n in names):
            raise InputError(f"{route}: expected a non-empty method name array")
        if len(names) != len(set(names)) or len(names) > 4 or any(n not in METHODS + ("pp_structure_v3", "mineru_basic") for n in names):
            raise InputError(f"{route}: use up to four distinct supported method identities; OCR variants are not methods")
        result[route] = tuple(names)
    return result


def route_name(native_text_present: bool, document_type: str, tables: bool = False) -> str:
    if tables or document_type in {"deployment_report", "facility_certificate"}:
        return "tables_text" if native_text_present else "tables_scan"
    if not native_text_present or document_type == "user_manual":
        return "scan"
    return "fields" if document_type == "product_certificate" else "text"


def selected_methods(depth: int, native_text_present: bool, document_type: str = "general",
                     tables: bool = False, orders: dict | None = None) -> tuple[str, ...]:
    if type(depth) is not int or not 1 <= depth <= 5:
        raise ValueError("Depth must be an integer from 1 to 5")
    return tuple(validate_orders(orders)[route_name(native_text_present, document_type, tables)][:min(depth, 4)])


def read_page(path: Path, index: int, size: tuple[float, float], depth: int,
              upstream_engines: tuple[str, ...], language: str = "eng", document_type: str = "general",
              regions: tuple[Box, ...] | None = None, *, plan: dict | None = None,
              orders: dict | None = None, scope: str = "full_document") -> list[Observation]:
    plan = plan if plan is not None else inspect_page(path, index, size, regions)
    native = plan["source_type"] == "text"
    table_route = bool(plan["tables"]) or plan.get("requires_tables", False) or scope == "tables"
    route = route_name(native, document_type, table_route)
    names = selected_methods(4, native, document_type, table_route, orders)
    engine_names = {e.strip().lower() for e in upstream_engines}
    upstream_families = {FAMILIES[n] for n in ALIASES if ALIASES[n] & engine_names}
    observations = []
    attempted = 0
    for name in names:
        if attempted >= min(depth, 4):
            break
        started = perf_counter()
        cpu_start = _cpu_time()
        shared = bool(ALIASES[name] & engine_names)
        if shared:
            obs = Observation(name, FAMILIES[name], index, "excluded_upstream", error="Same upstream engine/component")
        elif (name == "poppler" and table_route) or (name in {"poppler", "pdfplumber"} and not native):
            obs = Observation(name, FAMILIES[name], index, "not_applicable", error="Source/content requires visual or structured table reading")
        else:
            try:
                if name in OPTIONAL_PACKAGES:
                    installed = importlib.util.find_spec(OPTIONAL_PACKAGES[name]) is not None
                    obs = Observation(name, FAMILIES[name], index, "not_implemented" if installed else "unavailable",
                                      error="No verified adapter; not executed" if installed else "Package/model pipeline not installed; not executed")
                elif name == "poppler":
                    obs = _poppler(path, index)
                elif name == "pdfplumber":
                    obs = _pdfplumber(path, index)
                else:
                    obs = _tesseract_pipeline(path, index, size, language, regions, scope == "tables")
            except Exception as exc:
                status = "unavailable" if isinstance(exc, (ImportError, ModuleNotFoundError)) or not shutil.which("tesseract" if name == "tesseract" else "pdftotext") and name != "pdfplumber" else "error"
                obs = Observation(name, FAMILIES[name], index, status, error=f"{type(exc).__name__}: {exc}")
        obs.elapsed_seconds = round(perf_counter() - started, 6)
        obs.cpu_seconds = round(_cpu_time() - cpu_start, 6) if cpu_start is not None else None
        obs.shared_with_upstream = shared
        obs.family_overlaps_upstream = obs.family in upstream_families
        obs.components = COMPONENTS.get(name, [])
        obs.route, obs.source_type = route, plan["source_type"]
        observations.append(obs)
        if obs.status == "ok" and obs.words and (not table_route or obs.table_cells):
            attempted += 1
    if depth == 5:
        observations.append(Observation("other_model", "model_review", index, "not_implemented",
                                        error="Different upstream model identity and explicit remote authorization required; no API called"))
    return observations


def _cpu_time() -> float | None:
    if resource is None:
        return None
    return sum(r.ru_utime + r.ru_stime for r in
               (resource.getrusage(resource.RUSAGE_SELF), resource.getrusage(resource.RUSAGE_CHILDREN)))


def versions() -> dict[str, str]:
    found = {}
    for name, package in (("pdfplumber", "pdfplumber"), ("pdfium", "pypdfium2"),
                          ("pypdf", "pypdf"), ("pillow", "Pillow"), *OPTIONAL_PACKAGES.items()):
        try:
            found[name] = version(package)
        except PackageNotFoundError:
            found[name] = "not_installed"
    for name, command in (("poppler", ["pdftotext", "-v"]), ("tesseract", ["tesseract", "--version"])):
        try:
            result = subprocess.run(command, capture_output=True, timeout=5, check=True)
            found[name] = (result.stdout or result.stderr).decode(errors="replace").splitlines()[0]
        except (OSError, subprocess.SubprocessError, IndexError):
            found[name] = "unavailable"
    return found
