"""Evidence-backed checks and page/document support scores (not probabilities)."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, replace
import json
import platform
import sys
from difflib import SequenceMatcher
from hashlib import sha256
from itertools import combinations
from pathlib import Path
from time import perf_counter
import re
import unicodedata

from . import __version__
from .evidence import ALIASES, Line, Observation, inspect_page, page_sizes, read_page, resource, versions, validate_orders
from .input import Block, Box, Document, Page, load_document


DIMENSIONS = ("accuracy", "structure", "tables", "formula_figures", "cleanliness")
WEIGHTS = {
    # Provisional policy, not a calibrated probability model.
    "general": dict(zip(DIMENSIONS, (0.30, 0.20, 0.20, 0.15, 0.15))),
    "financial": dict(zip(DIMENSIONS, (0.30, 0.15, 0.35, 0.10, 0.10))),
    "legal": dict(zip(DIMENSIONS, (0.40, 0.30, 0.10, 0.05, 0.15))),
}
RULES_VERSION = "local-evidence/10"
BODY_KINDS = {"heading", "paragraph", "list_item", "table", "equation", "figure", "field"}
TEXT_KINDS = {"heading", "paragraph", "list_item", "footnote", "header", "footer", "sidebar", "field"}
CRITICAL_WORDS = {"not", "no", "never", "without", "ikke", "ingen", "不得", "不", "禁止", "mg", "kg", "g", "ml", "mm", "cm", "m", "bar", "pa", "kpa", "mpa", "kw", "v", "hz"}
KNOWN_ENGINE_NAMES = set().union(*ALIASES.values())


def tokens(text: str) -> list[str]:
    text = unicodedata.normalize("NFKC", text).casefold().replace("−", "-")
    return re.findall(r"[+-]?\d+(?:[.,:/]\d+)*|[^\W\d_]+|[≥≤<>%=]", text, re.UNICODE)


def critical(values: list[str]) -> list[str]:
    return [v for v in values if any(c.isdigit() for c in v) or v in CRITICAL_WORDS
            or v in {"≥", "≤", ">", "<", "%", "="}]


def similarity(expected: str, actual: str) -> float:
    a, b = tokens(expected), tokens(actual)
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    common = sum((Counter(a) & Counter(b)).values())
    bag = 2 * common / (len(a) + len(b))
    order = SequenceMatcher(None, a, b, autojunk=False).ratio()
    return 0.8 * bag + 0.2 * order


@dataclass
class Score:
    total: float = 0
    measured: float = 0
    support: float = 0

    def add(self, weight: float, value: float | None) -> None:
        self.total += weight
        if value is not None:
            self.measured += weight
            self.support += weight * min(1, max(0, value))

    def result(self) -> dict:
        if self.total == 0:
            return {"score": None, "coverage": None, "state": "not_applicable"}
        if self.measured == 0:
            return {"score": None, "coverage": 0.0, "state": "unverified"}
        coverage = self.measured / self.total
        return {"score": round(100 * self.support / self.total, 1),
                "coverage": round(coverage, 3),
                "state": "assessed" if coverage >= 0.999 else "partial"}


def _combined(scores: dict[str, dict], weights: dict[str, float]) -> float | None:
    applicable = [(weights[d], scores[d]["score"]) for d in DIMENSIONS
                  if scores[d]["state"] != "not_applicable"]
    if not applicable or not any(score is not None for _, score in applicable):
        return None
    denominator = sum(weight for weight, _ in applicable)
    return round(sum(weight * (score or 0) for weight, score in applicable) / denominator, 1)


def _text_in_box(obs: Observation, box: Box) -> str:
    selected = [w for w in obs.words if box.contains_center(w.box)]
    selected.sort(key=lambda w: (round(w.box.y0 / 5), w.box.x0))
    return " ".join(w.text for w in selected)


def _comparison(expected: str, box: Box | None, observations: list[Observation]) -> tuple[float | None, list[dict], list[str]]:
    if box is None:
        return None, [], ["missing_bbox"]
    candidates = []
    for obs in observations:
        if obs.status != "ok" or not obs.words or obs.shared_with_upstream:
            continue
        actual = _text_in_box(obs, box)
        if actual:
            candidates.append({"method": obs.method, "family": obs.family,
                               "family_overlaps_upstream": obs.family_overlaps_upstream,
                               "text": actual, "similarity": round(similarity(expected, actual), 3)})
    if not candidates:
        return None, [], ["no_independent_positioned_text"]
    # Multiple readers of the same embedded text are one correlated family.
    by_family: dict[str, dict] = {}
    for candidate in candidates:
        family = candidate["family"]
        if family not in by_family or candidate["similarity"] > by_family[family]["similarity"]:
            by_family[family] = candidate
    family_scores = [c["similarity"] for c in by_family.values()]
    # ponytail: a weak OCR read on tiny print must not outweigh a clear text-layer match;
    # replace this ceiling with reliability learned from labeled pages when available.
    support = max(family_scores) if max(family_scores) >= 0.90 else sum(family_scores) / len(family_scores)
    return support, candidates, []


def _difference(expected: str, candidates: list[dict]) -> tuple[str | None, bool]:
    """Find small lexical/critical changes even inside otherwise matching long blocks."""
    representatives: dict[str, dict] = {}
    for candidate in candidates:
        family = candidate["family"]
        if family not in representatives or candidate["similarity"] > representatives[family]["similarity"]:
            representatives[family] = candidate
    expected_critical = tuple(critical(tokens(expected)))

    def critical_change(candidate: dict) -> bool:
        return tuple(critical(tokens(candidate["text"]))) != expected_critical

    def lexical_change(candidate: dict) -> bool:
        actual = candidate["text"]
        compact = lambda value: re.sub(r"\s+", "", unicodedata.normalize("NFKC", value).casefold())
        return tokens(actual) != tokens(expected) and compact(actual) != compact(expected)

    strong = [c for c in representatives.values() if c["similarity"] >= 0.90]
    if strong:
        changed = [c for c in strong if critical_change(c) or lexical_change(c)]
        if changed:
            important = any(critical_change(c) for c in changed)
            if len(changed) < len(strong):
                return ("critical_method_disagreement" if important else "method_disagreement"), False
            corroborating = [tuple(critical(tokens(c["text"]))) for c in changed
                             if not c["family_overlaps_upstream"]]
            confirmed = important and any(a == b for i, a in enumerate(corroborating)
                                              for b in corroborating[i + 1:])
            return ("critical_text_difference" if important else "text_difference"), confirmed
        if any(c["similarity"] >= 0.85 and critical_change(c)
               for c in representatives.values() if c not in strong):
            return "critical_method_disagreement", False
        return None, False

    important = any(critical_change(c) for c in representatives.values())
    corroborating = [tuple(critical(tokens(c["text"]))) for c in representatives.values()
                     if critical_change(c) and not c["family_overlaps_upstream"]]
    confirmed = important and any(a == b for i, a in enumerate(corroborating)
                                  for b in corroborating[i + 1:])
    return ("critical_text_difference" if important else "text_difference"), confirmed


def _status(findings: list[dict], observed: bool) -> str:
    if any(f["disposition"] == "failed" for f in findings):
        return "failed"
    if any(f["disposition"] == "review_required" for f in findings):
        return "review_required"
    return "pass" if observed else "unverifiable"


def _scope_observations(obs: list[Observation], regions: tuple[Box, ...]) -> list[Observation]:
    def inside(box):
        return any(region.contains_center(box, slack=0) for region in regions)
    result = []
    for o in obs:
        words = [w for w in o.words if inside(w.box)]
        tables = [(b, o.table_rows[i] if i < len(o.table_rows) else [],
                   o.table_cells[i] if i < len(o.table_cells) else [])
                  for i, b in enumerate(o.tables) if inside(b)]
        # Split coverage into positioned words so a line crossing a scope edge is not lost.
        result.append(replace(o, text=" ".join(w.text for w in words), words=words,
                              lines=[Line(w.text, w.box) for w in words],
                              tables=[b for b, _, _ in tables], table_rows=[r for _, r, _ in tables],
                              table_cells=[c for _, _, c in tables],
                              images=[b for b in o.images if inside(b)]))
    return result


def _method_complete(obs: Observation, tables: list[Box], regions) -> bool:
    if obs.status != "ok" or obs.shared_with_upstream or not obs.has_evidence():
        return False
    if regions is not None and (not regions or any(not _text_in_box(obs, r) for r in regions)):
        return False
    return all(any(i < len(obs.table_cells) and obs.table_cells[i] and
                       b.overlap(table) / max(1, table.area()) > .8
                       for i, b in enumerate(obs.tables)) for table in tables)


def validate(pdf_path: Path, json_path: Path, depth: int, language: str = "eng",
             method_order: dict | None = None) -> dict:
    if type(depth) is not int or not 1 <= depth <= 5:
        raise ValueError("Depth must be an integer from 1 to 5")
    started = perf_counter()
    orders = validate_orders(method_order)
    pdf_path, json_path = Path(pdf_path), Path(json_path)
    pdf_hash, json_hash = sha256(pdf_path.read_bytes()).hexdigest(), sha256(json_path.read_bytes()).hexdigest()
    sizes = page_sizes(pdf_path)
    document = load_document(json_path, sizes, pdf_hash)
    plans, observations = {}, {}
    for i, size in enumerate(sizes):
        regions = document.expected_regions.get(i, ()) if document.expected_regions is not None else None
        plan = inspect_page(pdf_path, i, size, regions)
        plan["requires_tables"] = any(b.kind == "table" for b in document.pages.get(i, Page(i,None,())).blocks)
        if document.expected_tables is not None:
            for box in document.expected_tables.get(i, ()):
                if not any(box.overlap(b) / max(1, box.area()) > .8 for b in plan["tables"]):
                    plan["tables"].append(box)
        if document.scope == "tables" and regions is not None:
            # Explicit inventory can name a table no parser detects at all.
            for box in regions:
                if not any(box.overlap(b) / max(1, box.area()) > .8 for b in plan["tables"]):
                    plan["tables"].append(box)
        if document.scope == "tables" and regions is None:
            regions = tuple(plan["tables"])
        plan["regions"] = regions
        plan["scope_unknown"] = document.scope != "full_document" and document.expected_regions is None
        plans[i] = plan
        observations[i] = [] if i not in document.pages or (regions == () and not plan["scope_unknown"]) else read_page(
            pdf_path, i, size, depth, document.upstream_engines, language, document.document_type,
            regions, plan=plan, orders=orders, scope=document.scope)
    weights = WEIGHTS.get(document.document_type, WEIGHTS["general"])
    all_blocks = {b.id: b for p in document.pages.values() for b in p.blocks}
    findings, pages = [], []
    document_scores = {d: Score() for d in DIMENSIONS}
    # Margin decisions are local to each method, independent of requested depth.
    marginal_by_method = {name: _repeated_marginals({i: [o for o in values if o.method == name]
                              for i, values in observations.items()}, sizes)
                          for name in {o.method for values in observations.values() for o in values}}
    for index, size in enumerate(sizes):
        page = document.pages.get(index, Page(index, None, ()))
        obs, plan = observations[index], plans[index]
        regions, scope_unknown = plan["regions"], plan["scope_unknown"]
        in_scope = regions is None or bool(regions) or scope_unknown
        page_findings, comparisons = [], []
        scores = {d: Score() for d in DIMENSIONS}
        method = None
        def issue(dimension, kind, severity, box, upstream_ids, evidence, disposition="review_required"):
            item = {"dimension": dimension, "kind": kind, "severity": severity, "page_index": index,
                    "bbox": box.as_list() if box else None, "upstream_ids": upstream_ids,
                    "evidence": evidence, "disposition": disposition, "method": method}
            item["id"] = "F" + sha256(json.dumps(item, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
            if not any(f["id"] == item["id"] for f in page_findings):
                findings.append(item); page_findings.append(item)
        if scope_unknown:
            scores["accuracy"].add(5, None)
            issue("accuracy", "extraction_scope_unverified", "warning", None, [],
                  {"scope": document.scope, "reason": "Independent expected_regions required; detected inventory is provisional"})
        if plan["errors"]:
            issue("accuracy", "source_inspection_incomplete", "warning", None, [], plan["errors"])
        for block in page.blocks:
            if regions is not None and not scope_unknown and (block.bbox is None or not any(
                    r.overlap(block.bbox) >= block.bbox.area()-1 for r in regions)):
                issue("accuracy", "candidate_outside_or_unlocated_in_scope", "major", block.bbox,
                      [block.id], {"scope": document.scope})
            if document.scope == "tables" and block.kind != "table":
                issue("cleanliness", "non_table_in_table_extraction", "warning", block.bbox, [block.id], {"type": block.kind})
        if index not in document.pages and in_scope:
            scores["accuracy"].add(plan["content_weight"], 0)
            for dimension in DIMENSIONS[1:]:
                scores[dimension].add(plan["content_weight"], None)
            issue("accuracy", "missing_pdf_page_in_json", "critical", None, [], {"pdf_page_index": index}, "failed")
        _duplicate_table_content(page, scores, issue)
        for original in obs:
            method = original.method
            scoped = _scope_observations([original], regions)[0] if regions is not None else original
            method_scores = {d: Score() for d in DIMENSIONS}
            before = len(page_findings)
            if original.error and original.status == "ok":
                issue("accuracy", "method_partial", "warning", None, [], {"reason": original.error})
            if original.status in {"ok", "empty"}:
                for block in page.blocks:
                    if block.kind not in TEXT_KINDS:
                        continue
                    dimension = "cleanliness" if block.kind in {"header", "footer", "sidebar"} else "accuracy"
                    support, candidates, reasons = _comparison(block.text, block.bbox, [original])
                    kind, _ = _difference(block.text, candidates) if candidates else (None, False)
                    method_scores[dimension].add(max(1, min(20, len(tokens(block.text)))),
                                                min(support, .5) if kind else support)
                    if reasons:
                        issue(dimension, "text_not_verifiable", "warning", block.bbox, [block.id], reasons)
                    elif kind:
                        issue(dimension, kind, "critical" if kind.startswith("critical") else "major",
                              block.bbox, [block.id], candidates)
                if index in document.pages:
                    _coverage(page, [scoped], size, marginal_by_method[method], method_scores, issue)
                    if document.scope == "full_document":
                        _page_text_check(page, [scoped], method_scores, issue)
                    _structure(page, all_blocks, [original], method_scores, issue)
                    _tables(page, [scoped], method_scores, issue)
                    if document.scope != "tables":
                        _formula_figures(page, [scoped], method_scores, issue)
                        _cleanliness(page, [original], size, marginal_by_method[method], method_scores, issue)
                    if document.document_type == "product_certificate":
                        _fields(page, [original], method_scores, issue)
                for table in plan["tables"]:
                    if not any(b.kind == "table" and b.bbox and b.bbox.overlap(table)/max(1,table.area()) > .4 for b in page.blocks):
                        issue("tables", "expected_table_missing", "major", table, [], {"basis": "fixed_source_inventory"})
                    if not _method_complete(scoped, [table], None):
                        method_scores["tables"].add(5, None)
                        issue("tables", "table_structure_unverified", "warning", table, [],
                              {"reason": "No structured source cells for this expected table"})
            else:
                issue("accuracy", "method_not_executed" if original.status != "error" else "method_failed", "warning",
                      None, [], {"status": original.status, "reason": original.error})
            incomplete_checks = {"table_structure_unverified", "table_cells_not_available",
                                 "certificate_fields_unstructured", "field_association_unverified",
                                 "reading_order_unverified", "pdf_coverage_unverified"}
            complete = not scope_unknown and not plan["errors"] and not original.error and _method_complete(scoped, plan["tables"], regions) and not any(
                f["kind"] in incomplete_checks for f in page_findings[before:])
            comparisons.append({"method": method, "status": original.status, "complete_for_scope": complete,
                                "finding_ids": [f["id"] for f in page_findings[before:]],
                                "dimension_scores": {d: method_scores[d].result() for d in DIMENSIONS},
                                "source_reading": {"text": scoped.text,
                                    "words": [{"text": w.text, "bbox": w.box.as_list()} for w in scoped.words],
                                    "tables": [{"bbox": b.as_list(), "cells": [asdict(c) for c in scoped.table_cells[i]]
                                                if i < len(scoped.table_cells) else []} for i,b in enumerate(scoped.tables)]}})
            for d in DIMENSIONS:
                scores[d].total += method_scores[d].total
                scores[d].measured += method_scores[d].measured
                scores[d].support += method_scores[d].support
        method = None
        # Corroboration adds a separate finding; original method discrepancies never change.
        groups = defaultdict(list)
        for f in page_findings:
            if f["kind"] in {"critical_text_difference", "cell_content_difference"} and f["severity"] == "critical" and isinstance(f["evidence"], list):
                for e in f["evidence"]:
                    if isinstance(e, dict) and e.get("text") and not e.get("family_overlaps_upstream"):
                        groups[(tuple(f["upstream_ids"]), tuple(critical(tokens(e["text"]))))].append((e.get("family"), f))
        for group in groups.values():
            if len({family for family, _ in group}) > 1:
                f = group[0][1]
                issue(f["dimension"], "corroborated_critical_difference", "critical", Box(*f["bbox"]) if f["bbox"] else None,
                      f["upstream_ids"], {"finding_ids": [v["id"] for _,v in group]}, "failed")
        effective = [c["method"] for c in comparisons if c["complete_for_scope"]]
        block_depths = []
        for block in page.blocks:
            methods = []
            for o in obs:
                if block.kind == "table":
                    supported = block.bbox is not None and _method_complete(o, [block.bbox], None)
                else:
                    supported = bool(_comparison(block.text, block.bbox, [o])[1]) if block.text.strip() else False
                if supported:
                    methods.append(o.method)
            block_depths.append({"block_id": block.id, "effective_depth": len(methods), "effective_methods": methods,
                                 "scope": "structured_cells" if block.kind == "table" else "positioned_content",
                                 "requested_depth": depth})
            if len(methods) < depth:
                issue("accuracy", "block_depth_unmet", "warning", block.bbox, [block.id], {"requested": depth, "effective": len(methods)})
        if in_scope and len(effective) < depth:
            scores["accuracy"].add(1, None)
            issue("accuracy", "requested_depth_unmet", "warning", None, [], {"requested": depth, "effective": len(effective)})
        result_scores = {d: scores[d].result() for d in DIMENSIONS}
        for d in DIMENSIONS:
            document_scores[d].total += scores[d].total
            document_scores[d].measured += scores[d].measured
            document_scores[d].support += scores[d].support
        pages.append({"page_index": index, "printed_page_label": page.printed_page_label,
                      "requested_depth": depth, "effective_depth": len(effective), "effective_methods": effective,
                      "source_type": plan["source_type"],
                      "source_inventory": {"tables": [b.as_list() for b in plan["tables"]],
                                           "regions": None if regions is None else [b.as_list() for b in regions],
                                           "method_skip_reason": "candidate_page_absent" if index not in document.pages else None,
                                           "basis": plan["inventory_basis"], "inspection_seconds": plan["elapsed_seconds"]},
                      "scope_status": "unverified" if scope_unknown else "in_scope" if in_scope else "out_of_scope",
                      "block_depths": block_depths, "comparisons": comparisons,
                      "evidence_families": sorted({o.family for o in obs if o.method in effective}),
                      "dimension_scores": result_scores, "overall_support_score": _combined(result_scores, weights),
                      "calibrated_correctness": None,
                      "status": _status(page_findings, bool(effective)) if in_scope or page.blocks else "not_applicable",
                      "finding_ids": [f["id"] for f in page_findings],
                      "methods": [{"name": o.method, "family": o.family, "status": o.status,
                                   "shared_with_upstream": o.shared_with_upstream, "family_overlaps_upstream": o.family_overlaps_upstream,
                                   "has_evidence": o.has_evidence(), "error": o.error, "route": o.route,
                                   "components": o.components, "elapsed_seconds": o.elapsed_seconds, "cpu_seconds": o.cpu_seconds,
                                   "api_fee": 0, "compute_fee": None} for o in obs]})
    dimension_scores = {d: document_scores[d].result() for d in DIMENSIONS}
    scope_data = [{"page_index": p["page_index"], "regions": p["source_inventory"]["regions"],
                   "tables": p["source_inventory"]["tables"]} for p in pages]
    return {"schema_version": "validation-report/3", "validator_version": __version__, "rules_version": RULES_VERSION,
            "pdf_sha256": pdf_hash, "input_json_sha256": json_hash,
            "scope_sha256": sha256(json.dumps(scope_data, sort_keys=True).encode()).hexdigest(),
            "requested_depth": depth, "document_type": document.document_type, "extraction_scope": document.scope,
            "extraction_stage": "full_page_extraction",
            "expected_regions": None if document.expected_regions is None else [
                {"page_index": i, "bbox": b.as_list()} for i,boxes in document.expected_regions.items() for b in boxes],
            "elapsed_seconds": round(perf_counter()-started, 6),
            "cost": {"ordering_basis": "configured_priority_not_measured_ranking", "method_order": orders,
                     "method_seconds": round(sum(o.elapsed_seconds for values in observations.values() for o in values),6),
                     "method_cpu_seconds": round(sum(o.cpu_seconds or 0 for values in observations.values() for o in values),6) if resource else None,
                     "api_fee": 0, "compute_fee": None, "peak_process_rss": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss if resource else None,
                     "peak_rss_unit": "bytes" if sys.platform == "darwin" else "KiB",
                     "memory_scope": "process_lifetime_high_water_mark_not_per_method", "hardware": platform.platform(),
                     "architecture": platform.machine(), "python": platform.python_version()},
            "depth_5": {"status": "not_implemented", "executed": False, "upstream_model": document.upstream_model,
                        "review_model": None, "budget_tier": "highest", "requires": ["different_model_identity",
                        "original_pdf", "unchanged_candidate", "fixed_scope", "append_only_findings", "explicit_remote_authorization"]},
            "upstream_engines": list(document.upstream_engines),
            "upstream_lineage_unknown": not document.upstream_engines or any(e.strip().lower() not in KNOWN_ENGINE_NAMES for e in document.upstream_engines),
            "upstream_workflow": "Requirement: regulatory PDF" if document.document_type == "legal" else {
                "product_certificate": "Evidence: PDF Inspector (text) / LLM image (scan)",
                "user_manual": "Evidence: LLM image sections", "deployment_report": "Evidence: LLM image tables",
                "facility_certificate": "Evidence: LLM image tables"}.get(document.document_type, "unspecified"),
            "tool_versions": versions(), "document": {"page_count": len(sizes), "dimension_scores": dimension_scores,
                "overall_support_score": _combined(dimension_scores, weights), "calibrated_correctness": None,
                "status": _status(findings, any(p["effective_depth"] for p in pages)),
                "review_page_indices": [p["page_index"] for p in pages if p["status"] not in {"pass", "not_applicable"}]},
            "pages": pages, "findings": findings,
            "review_items": [{"finding_id": f["id"], "page_index": f["page_index"], "bbox": f["bbox"],
                              "upstream_ids": f["upstream_ids"]} for f in findings if f["disposition"] == "review_required"],
            "score_interpretation": "Evidence support only; not a probability of correctness. More methods do not guarantee more accuracy.",
            "business_acceptance": {"critical_miss_rate": "UNMEASURED", "manual_review_fraction": "UNMEASURED"}}


def _reference(obs: list[Observation]) -> Observation | None:
    for name in ("poppler", "tesseract", "pdfplumber", "pdfium"):
        found = next((o for o in obs if o.method == name and o.words and not o.shared_with_upstream), None)
        if found:
            return found
    return next((o for o in obs if o.words and o.status == "ok" and not o.shared_with_upstream), None)


def _coverage(page: Page, obs: list[Observation], size: tuple[float, float],
              repeated_marginals: set[str], scores: dict, issue) -> None:
    reference = _reference(obs)
    if reference is None:
        scores["accuracy"].add(5, None)
        issue("accuracy", "pdf_coverage_unverified", "warning", None, [],
              ["no independent positioned source text"])
        return
    for line in reference.lines:
        if not tokens(line.text):
            continue
        marginal = line.box.y0 < size[1] * 0.08 or line.box.y1 > size[1] * 0.93
        if marginal and (_page_label(line.text, page.page_index) or
                         " ".join(tokens(line.text)) in repeated_marginals):
            continue
        covered = any(block.bbox and block.bbox.overlap(line.box) / max(1, line.box.area()) > 0.25
                      for block in page.blocks)
        weight = max(1, min(10, len(tokens(line.text))))
        if covered:
            scores["accuracy"].add(weight, 1)
            continue
        line_tokens = Counter(tokens(line.text))
        unpositioned = next((block for block in page.blocks if block.bbox is None and
                             line_tokens <= Counter(tokens(" ".join(c.text for c in block.cells)
                                                          if block.cells else block.text))), None)
        if unpositioned:
            scores["accuracy"].add(weight, None)
            issue("accuracy", "pdf_region_position_unverified", "warning", line.box,
                  [unpositioned.id], {"method": reference.method, "text": line.text})
        else:
            scores["accuracy"].add(weight, 0)
            issue("accuracy", "pdf_region_missing_from_json", "critical", line.box, [],
                  [{"method": reference.method, "text": line.text}])


def _page_text_check(page: Page, obs: list[Observation], scores: dict, issue) -> None:
    expected = " ".join((" ".join(c.text for c in b.cells) if b.cells else b.text)
                        for b in page.blocks if b.kind != "figure")
    if not expected.strip():
        return
    for observation in obs:
        if observation.method not in {"pdfium", "pypdf"} or observation.shared_with_upstream:
            continue
        weight = max(1, min(8, len(tokens(expected)) / 8))
        if observation.status != "ok":
            scores["accuracy"].add(weight, None)
            continue
        score = similarity(expected, observation.text)
        scores["accuracy"].add(weight, score)
        if score < 0.65:
            issue("accuracy", "whole_page_text_disagreement", "major", None,
                  [b.id for b in page.blocks],
                  {"method": observation.method, "similarity": round(score, 3)})


def _structure(page: Page, all_blocks: dict[str, Block], obs: list[Observation], scores: dict, issue) -> None:
    tables = [b for b in page.blocks if b.kind == "table" and b.bbox]
    structured = [b for b in page.blocks if b.kind in {"heading", "paragraph", "list_item", "footnote"}
                  and not any(b.bbox and table.bbox.contains_center(b.bbox) for table in tables)]
    for block in structured:
        if block.parent_id:
            parent = all_blocks.get(block.parent_id)
            good = parent is not None and parent.kind in {"heading", "list_item"}
            scores["structure"].add(2, 1 if good else 0)
            if not good:
                issue("structure", "invalid_parent_relation", "major", block.bbox,
                      [block.id], {"parent_id": block.parent_id}, "failed")
        if block.kind == "heading":
            scores["structure"].add(1, 1 if block.heading_level is not None else None)
            if block.heading_level is None:
                issue("structure", "heading_level_unverified", "warning", block.bbox, [block.id], {})
    for block in structured:
        if not block.parent_id or not block.bbox:
            continue
        headings = [h for h in structured if h.kind == "heading" and h.bbox and h.bbox.y1 <= block.bbox.y0
                    and h.bbox.x0 <= block.bbox.x1 and h.bbox.x1 >= block.bbox.x0
                    and _comparison(h.text, h.bbox, obs)[1]]
        if headings:
            nearest = max(headings, key=lambda h:h.bbox.y1)
            parent = all_blocks.get(block.parent_id)
            if parent and parent.kind == "heading" and nearest.id != parent.id:
                issue("structure", "paragraph_association_difference", "major", block.bbox, [block.id,parent.id,nearest.id],
                      {"nearest_source_supported_heading": nearest.id})
    ordered = [b for b in structured if b.order is not None and b.bbox]
    if len(structured) >= 2 and len(ordered) < 2:
        scores["structure"].add(2, None)
        issue("structure", "reading_order_unverified", "warning", None,
              [b.id for b in structured], ["fewer than two positioned ordered blocks"])
    ordered.sort(key=lambda b: b.order)
    for left, right in zip(ordered, ordered[1:]):
        if not left.bbox or not right.bbox:
            continue
        same_column = min(left.bbox.x1, right.bbox.x1) > max(left.bbox.x0, right.bbox.x0)
        if not same_column:
            scores["structure"].add(1, None)
            issue("structure", "reading_order_unverified", "warning", right.bbox,
                  [left.id, right.id], {"reason": "Multi-column order needs an independent layout model"})
            continue
        good = left.bbox.y0 <= right.bbox.y0 + 3
        scores["structure"].add(1, 1 if good else 0)
        if not good:
            issue("structure", "reading_order_conflict", "major", right.bbox,
                  [left.id, right.id], {"order": [left.order, right.order]})
    headings = [b for b in ordered if b.kind == "heading" and b.heading_level is not None]
    for left, right in zip(headings, headings[1:]):
        good = right.heading_level <= left.heading_level + 1
        scores["structure"].add(1, 1 if good else 0)
        if not good:
            issue("structure", "heading_level_jump", "major", right.bbox,
                  [left.id, right.id], {"levels": [left.heading_level, right.heading_level]})
    plumber = next((o for o in obs if o.method == "pdfplumber" and o.lines
                    and not o.shared_with_upstream), None)
    if plumber:
        for block in structured:
            if block.kind != "heading" or not block.bbox:
                continue
            nearby = [line for line in plumber.lines if block.bbox.contains_center(line.box)]
            body = [line.font_size for line in plumber.lines if line.font_size and
                    not block.bbox.contains_center(line.box)]
            if nearby and body:
                heading_size = max(line.font_size or 0 for line in nearby)
                typical = sorted(body)[len(body) // 2]
                scores["structure"].add(1, 1 if heading_size >= typical or any(l.bold for l in nearby) else 0.5)


def _table_aggregate(expected: str, block: Block, obs: list[Observation], scores: dict, issue) -> None:
    expected_tokens = tokens(expected)
    if not expected_tokens:
        return
    weight = max(4, min(50, len(expected_tokens) / 20))
    _, candidates, reasons = _comparison(expected, block.bbox, obs)
    if reasons:
        scores["tables"].add(weight, None)
        return
    expected_counts = Counter(expected_tokens)
    expected_critical = Counter(critical(expected_tokens))
    by_family: dict[str, dict] = {}
    for candidate in candidates:
        actual_tokens = tokens(candidate["text"])
        actual_counts = Counter(actual_tokens)
        common = sum((expected_counts & actual_counts).values())
        bag = 2 * common / max(1, len(expected_tokens) + len(actual_tokens))
        actual_critical = Counter(critical(actual_tokens))
        missing = list((expected_counts - actual_counts).elements())
        extra = list((actual_counts - expected_counts).elements())
        split_only = (len(missing) == 1 and len(extra) == 2 and
                      missing[0] in {"".join(extra), "".join(reversed(extra))})
        summary = {"method": candidate["method"], "family": candidate["family"],
                   "family_overlaps_upstream": candidate["family_overlaps_upstream"],
                   "bag_support": round(bag, 3),
                   "lexical_difference": bool(missing or extra) and not split_only,
                   "lexical_missing": missing[:12], "lexical_extra": extra[:12],
                   "critical_missing": list((expected_critical - actual_critical).elements())[:12],
                   "critical_extra": list((actual_critical - expected_critical).elements())[:12]}
        if summary["family"] not in by_family or bag > by_family[summary["family"]]["bag_support"]:
            by_family[summary["family"]] = summary
    evidence = list(by_family.values())
    best = max(evidence, key=lambda c: c["bag_support"])
    scores["tables"].add(weight, best["bag_support"])
    best_critical = bool(best["critical_missing"] or best["critical_extra"])
    other_match = any(not (c["critical_missing"] or c["critical_extra"]) and
                      c["bag_support"] >= 0.85 for c in evidence if c is not best)
    if best_critical and other_match:
        scores["tables"].add(2, None)
        issue("tables", "table_method_disagreement", "major", block.bbox, [block.id], evidence)
    elif best_critical:
        difference_count = len(best["critical_missing"]) + len(best["critical_extra"])
        scores["tables"].add(max(2, min(8, 2 * difference_count)), 0)
        issue("tables", "table_critical_token_difference", "critical", block.bbox, [block.id], evidence)
    elif best["bag_support"] < 0.85 or best["lexical_difference"]:
        issue("tables", "table_aggregate_text_difference", "major", block.bbox, [block.id], evidence)
    elif any(c["bag_support"] >= 0.85 and (c["critical_missing"] or c["critical_extra"])
             for c in evidence if c is not best):
        scores["tables"].add(2, None)
        issue("tables", "table_method_disagreement", "major", block.bbox, [block.id], evidence)


def _duplicate_table_content(page: Page, scores: dict, issue) -> None:
    compact = lambda value: re.sub(r"\W+", "", unicodedata.normalize("NFKC", value).casefold())
    for table in (b for b in page.blocks if b.kind == "table" and b.bbox):
        table_text = " ".join(c.text for c in table.cells) if table.cells else table.text
        normalized_table = compact(table_text)
        if not normalized_table:
            continue
        for block in page.blocks:
            if block.kind not in {"heading", "paragraph", "list_item", "footnote"} or not block.bbox:
                continue
            if not table.bbox.contains_center(block.bbox) or len(tokens(block.text)) < 4:
                continue
            if compact(block.text) in normalized_table:
                scores["accuracy"].add(min(20, len(tokens(block.text))), 0)
                issue("accuracy", "duplicate_table_content", "major", block.bbox,
                      [table.id, block.id], {"table_id": table.id, "text": block.text})


def _tables(page: Page, obs: list[Observation], scores: dict, issue) -> None:
    blocks = [b for b in page.blocks if b.kind == "table"]
    source = next((o for o in obs if o.status == "ok" and not o.shared_with_upstream), None)
    for block in blocks:
        table_index = next((i for i,b in enumerate(source.tables) if block.bbox and
                            block.bbox.overlap(b)/max(1,b.area()) > .4), None) if source else None
        cells = source.table_cells[table_index] if table_index is not None and table_index < len(source.table_cells) else []
        if not block.bbox:
            issue("tables", "table_position_missing", "warning", None, [block.id], {})
        aggregate = " ".join(c.text for c in block.cells) if block.cells else block.text
        _table_aggregate(aggregate, block, obs, scores, issue)
        if not block.cells:
            scores["tables"].add(5, None)
            issue("tables", "table_cells_not_available", "warning", block.bbox, [block.id], {})
        if not cells:
            scores["tables"].add(5, None)
            issue("tables", "table_structure_unverified", "warning", block.bbox, [block.id],
                  {"checks": ["row_column", "header_positions", "units", "merged_cells"], "reason": "No source cells recovered"})
        else:
            # Compare every method's source grid even when candidate cell boxes exist.
            observed = {(c.row,c.column): c for c in cells}
            candidate = {(c.row,c.column): c for c in block.cells}
            for key in sorted(set(observed) | set(candidate)):
                actual, expected = observed.get(key), candidate.get(key)
                if actual is None or expected is None:
                    scores["tables"].add(2, 0)
                    issue("tables", "table_cell_omission_or_addition", "major", (actual or expected).bbox or block.bbox,
                          [block.id] + ([expected.id] if expected else []),
                          {"row": key[0], "column": key[1], "source": actual.text if actual else None,
                           "candidate": expected.text if expected else None, "method": source.method})
                    continue
                spans_match = (actual.row_span,actual.column_span) == (expected.row_span,expected.column_span)
                text_match = tokens(actual.text) == tokens(expected.text)
                scores["tables"].add(max(1,len(tokens(actual.text))), 1 if text_match and spans_match else 0)
                if not spans_match:
                    issue("tables", "merged_cell_relationship_difference", "major", actual.bbox, [block.id,expected.id],
                          {"row": key[0], "column": key[1], "source_span": [actual.row_span,actual.column_span],
                           "candidate_span": [expected.row_span,expected.column_span], "method": source.method})
                if not text_match:
                    issue("tables", "table_row_alignment_disagreement", "major", actual.bbox, [block.id,expected.id],
                          {"row": key[0], "column": key[1], "source": actual.text, "candidate": expected.text,
                           "method": source.method, "family": source.family})
                if expected.bbox and expected.bbox.overlap(actual.bbox)/max(1,actual.bbox.area()) < .5:
                    issue("tables", "cell_row_column_conflict", "major", actual.bbox, [block.id,expected.id],
                          {"source_bbox": actual.bbox.as_list(), "candidate_bbox": expected.bbox.as_list()})
        occupied = set()
        for cell in block.cells:
            # Bounded spans prevent untrusted indices allocating a huge dense grid.
            if cell.row_span * cell.column_span > 10000:
                issue("tables", "cell_span_too_large", "major", cell.bbox, [block.id,cell.id], {}, "failed")
                continue
            locations = {(r,c) for r in range(cell.row,cell.row+cell.row_span)
                         for c in range(cell.column,cell.column+cell.column_span)}
            if locations & occupied:
                scores["tables"].add(1,0)
                issue("tables", "duplicate_cell_coordinate", "major", cell.bbox, [block.id,cell.id],
                      {"row": cell.row, "column": cell.column}, "failed")
            occupied.update(locations)
            if not cell.bbox:
                continue
            if not block.bbox or not block.bbox.contains_center(cell.bbox):
                issue("tables", "invalid_cell_geometry", "major", cell.bbox, [block.id,cell.id], {}, "failed")
            support, candidates, reasons = _comparison(cell.text, cell.bbox, obs)
            kind, _ = _difference(cell.text, candidates) if candidates else (None,False)
            if not cell.text.strip() and not candidates:
                continue
            if reasons:
                issue("tables", "cell_not_verifiable", "warning", cell.bbox, [block.id,cell.id], reasons)
            elif kind:
                issue("tables", "cell_content_difference", "critical" if kind.startswith("critical") else "major",
                      cell.bbox, [block.id,cell.id], candidates)
        for first,second in combinations([c for c in block.cells if c.bbox],2):
            left,right = sorted((first,second),key=lambda c:(c.row,c.column))
            if ((left.row == right.row and left.bbox.x0 > right.bbox.x0+2) or
                    (left.column == right.column and left.bbox.y0 > right.bbox.y0+2)):
                issue("tables", "cell_row_column_conflict", "major", right.bbox, [block.id,left.id,right.id], {}, "failed")
    if source:
        for table in source.tables:
            if not any(b.bbox and b.bbox.overlap(table)/max(1,table.area()) > .4 for b in blocks):
                scores["tables"].add(3,0)
                issue("tables", "possible_table_omission", "major", table, [], {"method": source.method})


def _fields(page: Page, obs: list[Observation], scores: dict, issue) -> None:
    fields = [b for b in page.blocks if b.kind == "field"]
    if not fields:
        scores["structure"].add(3,None)
        issue("structure", "certificate_fields_unstructured", "warning", None, [],
              {"reason": "Legacy text is checked; field-to-product associations require field blocks"})
        return
    source = _reference(obs)
    blocks = {b.id:b for b in page.blocks}
    # ponytail: explicit Product/Device/Model/Equipment labels, same-column layout;
    # other certificate layouts require a source field inventory or a layout model.
    entities = [l for l in source.lines if re.match(r"^(product|device|model|equipment)\b", l.text, re.I)] if source else []
    for field in fields:
        entity = blocks.get(field.entity_id)
        above = [l for l in entities if field.bbox and l.box.y1 <= field.bbox.y0+2 and
                 min(l.box.x1,field.bbox.x1) > max(l.box.x0,field.bbox.x0)]
        if not entity or not entity.bbox or not field.bbox or not above:
            scores["structure"].add(3,None)
            issue("structure", "field_association_unverified", "warning", field.bbox, [field.id],
                  {"entity_id": field.entity_id, "reason": "Missing or unsupported source product/field layout"})
            continue
        actual = max(above,key=lambda l:l.box.y1)
        good = tokens(entity.text) == tokens(actual.text) and entity.bbox.contains_center(actual.box)
        scores["structure"].add(3,1 if good else 0)
        if not good:
            issue("structure", "field_entity_association_difference", "major", field.bbox, [field.id,entity.id],
                  {"observed_entity": actual.text, "candidate_entity": entity.text, "source_bbox": actual.box.as_list()})


def _formula_figures(page: Page, obs: list[Observation], scores: dict, issue) -> None:
    plumber = next((o for o in obs if o.method == "pdfplumber" and o.status == "ok"
                    and not o.shared_with_upstream), None)
    blocks = [b for b in page.blocks if b.kind in {"equation", "figure"}]
    for block in blocks:
        if block.kind == "equation":
            support, candidates, _ = _comparison(block.text, block.bbox, obs) if block.text else (None, [], [])
            kind, _ = _difference(block.text, candidates) if candidates else (None, False)
            scores["formula_figures"].add(2, min(support, 0.5) if kind and kind.endswith("text_difference") else support)
            if kind:
                issue("formula_figures", "formula_text_difference", "major", block.bbox,
                      [block.id], candidates)
            scores["formula_figures"].add(2, None)  # symbolic/visual fidelity needs a specialist
            issue("formula_figures", "formula_semantics_unverified", "warning", block.bbox,
                  [block.id], ["no independent formula parser"])
        else:
            presence = None
            if plumber and block.bbox:
                presence = 1 if any(block.bbox.overlap(image) / max(1, image.area()) > 0.4
                                    for image in plumber.images) else None
            scores["formula_figures"].add(2, presence)
            scores["formula_figures"].add(2, None)  # chart meaning is not inferred from an image box
            if presence is None:
                issue("formula_figures", "figure_presence_unverified", "warning", block.bbox,
                      [block.id], ["image not independently located; vector graphics may exist"])
            else:
                issue("formula_figures", "figure_semantics_unverified", "warning", block.bbox,
                      [block.id], ["figure content not independently interpreted"])
    if plumber:
        for image in plumber.images:
            if not any(b.bbox and b.bbox.overlap(image) / max(1, image.area()) > 0.4 for b in blocks):
                scores["formula_figures"].add(2, 0)
                issue("formula_figures", "possible_figure_omission", "major", image, [],
                      {"method": "pdfplumber"})


def _repeated_marginals(observations: dict[int, list[Observation]],
                        sizes: list[tuple[float, float]]) -> set[str]:
    occurrences: dict[str, set[int]] = defaultdict(set)
    for index, obs in observations.items():
        reference = _reference(obs)
        if not reference:
            continue
        for line in reference.lines:
            if line.box.y1 < sizes[index][1] * 0.12 or line.box.y0 > sizes[index][1] * 0.88:
                key = " ".join(tokens(line.text))
                if key:
                    occurrences[key].add(index)
    return {text for text, pages in occurrences.items() if len(pages) >= 2}


def _page_label(text: str, index: int) -> str | None:
    value = text.strip()
    labeled = re.fullmatch(r"page\s+(\d{1,4})(?:\s*(?:of|/)\s*\d{1,4})?", value, re.I)
    if labeled:
        return labeled.group(1)
    return value if re.fullmatch(r"\d{1,4}", value) and value == str(index + 1) else None


def _cleanliness(page: Page, obs: list[Observation], size: tuple[float, float],
                 repeated: set[str], scores: dict, issue) -> None:
    separated = [b for b in page.blocks if b.kind in {"page_number", "header", "footer", "watermark", "sidebar"}]
    ref = _reference(obs)
    for block in page.blocks:
        if block.kind not in BODY_KINDS:
            continue
        body = " ".join(tokens(block.text))
        if not body:
            continue
        contaminated = False
        for meta in separated:
            value = " ".join(tokens(meta.text))
            if (value and value in body and meta.id != block.id
                    and (block.bbox is None or meta.bbox is None or block.bbox.overlap(meta.bbox))):
                contaminated = True
                issue("cleanliness", "metadata_in_body", "major", block.bbox,
                      [block.id, meta.id], {"metadata_type": meta.kind, "text": meta.text})
        if block.bbox and (block.bbox.y1 < size[1] * 0.15 or block.bbox.y0 > size[1] * 0.85):
            label = _page_label(block.text, page.page_index)
            if label:
                contaminated = True
                issue("cleanliness", "page_number_in_body", "major", block.bbox,
                      [block.id], {"observed_label": label})
        if (body in repeated and block.bbox
                and (block.bbox.y1 < size[1] * 0.12 or block.bbox.y0 > size[1] * 0.88)):
            contaminated = True
            issue("cleanliness", "repeated_margin_in_body", "major", block.bbox,
                  [block.id], {"text": block.text})
        scores["cleanliness"].add(1, 0 if contaminated else 1)
    if ref:
        for line in ref.lines:
            if line.box.y1 >= size[1] * 0.15 and line.box.y0 <= size[1] * 0.85:
                continue
            label = _page_label(line.text, page.page_index)
            if not label:
                continue
            if page.printed_page_label:
                declared = _page_label(page.printed_page_label, page.page_index) or page.printed_page_label.strip()
                scores["cleanliness"].add(1, 1 if declared == label else 0)
                if declared != label:
                    issue("cleanliness", "printed_page_label_mismatch", "major", line.box, [],
                          {"observed": label, "declared": page.printed_page_label})
            if not page.printed_page_label and not any(b.kind == "page_number" and
                                                    b.bbox and b.bbox.overlap(line.box)
                                                    for b in page.blocks):
                scores["cleanliness"].add(1, None)
                issue("cleanliness", "printed_page_number_not_separated", "warning", line.box,
                      [], {"observed_label": label})
