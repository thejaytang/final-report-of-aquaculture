# Development handoff snapshot

Implementation snapshot dated 2026-10-06, revision 2; English handoff prepared 2026-10-07, from the current module root. The program now lives directly at module root; v0.1 is archived separately and excluded.

Known issue: controlled experiment 18/20; both clean controls have a word-order false positive. After directory relocation, 74/74 engineering tests passed and the unchanged controlled experiment again returned 18/20. No validator algorithm or frozen input/expectation was changed. See PROJECT_STATE.md and tests/controlled-example-20261006/README.md. The tests folder contains materials, initial results, the relocation rerun and its logs.

Depth 5 has not executed a model. Docling, PP-StructureV3 and MinerU adapters are not implemented. Native Windows and real company Evidence acceptance remain unverified.

Recreate the local environment from pyproject.toml and uv.lock. The archive excludes environments, credentials, caches and the legacy v0.1 repository. This is a development snapshot for continuation and defect reproduction, not an accepted final product.

English documentation and experiment reports preserve all existing findings and failure states. Original PDFs, candidates and validator code are unchanged. Source-language parser tokens and Unicode test fixtures remain intact. Superseded Chinese visuals/source archives are excluded; the source project retains them.
