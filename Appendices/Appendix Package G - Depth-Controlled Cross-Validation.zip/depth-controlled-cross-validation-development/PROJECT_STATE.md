# Depth-Controlled Cross-Validation: current state

Implementation evidence as of 2026-10-06; English handoff prepared on 2026-10-07. The historical engineering suite passed 74/74. The latest controlled one-page experiment passed 18/20: one word-order false-positive defect affects the correct control in both PDF forms and remains unresolved. Real files for the four Evidence categories were unavailable; obtaining them or claiming business acceptance was outside that work's completion criteria. [Run guide](README.md) · [Design and official references](project-support/design/validation-design.md).

## 1. Implemented behavior

- Select methods by source type, content and actual layout. Distinguish text, scanned and mixed pages with small text layers. Route tables in regulations and manuals through structured checks from the first depth.
- Each method reads the original PDF and compares the same fixed candidate and scope. Retain readings and stable finding IDs; later agreement does not overwrite earlier differences. OCR configurations count as one method.
- Check table values, rows, columns, header text/positions, units and horizontal/vertical rectangular spans. Check certificate field/product associations and section parent relationships. Source inventories participate in detecting whole-section and whole-table omissions.
- Separately report failure, uninstalled/unimplemented methods, inapplicability, upstream overlap and incomplete evidence. Effective depth counts completed required checks. Missing pages fail directly without invented content-review methods.
- Updated CLI/Python interfaces, guides and state records use `validation-report/3` and `local-evidence/10`. Dependency declarations and the lockfile were unchanged.

## 2. Controlled error-detection experiment

An authored pump-check page was rendered as a text PDF and a 216 dpi image-only simulated scan. Nine separate mutations of the same JSON were tested. Inputs, expected findings and success criteria were frozen before running the existing validator. There were no simulated model outputs or validator changes.

Historical result: FAIL, 18/20 passed, 2 failed. All nine error types were detected in both forms. Both correct controls received an inspection-paragraph word-order false positive. Raw OCR order was correct; `_text_in_box()` grouped top coordinates in 5-point bands and moved `every` to the end of the line. The next step is to repair same-line order reconstruction and rerun the unchanged samples and success criteria. [Results and diagnosis](tests/controlled-example-20261006/results/initial-20261006/results.md) · [Machine-readable results](tests/controlled-example-20261006/results/initial-20261006/results.json).

## 3. Historical engineering regression

On 2026-10-06, PASS: 74/74, 0 failures, 0 skipped, 53.249 seconds. [Full log](project-support/validation/cross-validation-20261006/tests-final.log) · [Machine-readable record](project-support/validation/cross-validation-20261006/verification.json). Counts are unittest methods; subcases and repeated runs are not counted again.

Generated text/scanned PDFs cover the four Evidence types and regulations. The existing real 30-page regulatory fixture was also rerun. CLI reports for synthetic certificate/product misassociation and scanned-table span errors produced specific review findings. Nine PDF/candidate pairs and erroneous variants are retained in [examples](project-support/validation/cross-validation-20261006/examples).

[Raw wall-clock and CPU measurements](project-support/validation/cross-validation-20261006/cost-measurements.json) record three runs per method on the same scope and hardware. Default priority remains a configuration, not a measured business-cost ranking.

## 4. Capabilities and unexecuted work

- Executed methods: Poppler, pdfplumber and structured Tesseract. PDFium inspects and renders; it adds no depth. Current maxima are three methods for text bodies, two for text tables and one for scanned content; insufficient local evidence can reduce these counts.
- Docling, PP-StructureV3, MinerU Basic, Camelot and Table Transformer have no verified integration/inference here. Dependency detection is not an engine pass. Depth 5 remains an interface contract; no model selection, paid API call or upload occurred.
- Image grids support axis-aligned solid lines and rectangular spans. Borderless, dashed, rotated and complex multipage tables, semantic headers, multicolumn order and nonstandard certificate layouts may remain unverified. The two table workflows share some geometry code and are not fully independent models.
- Company input adaptation, real Evidence files, business accuracy and human-review savings remain unverified. Passing tests establish behavior only for the stated samples and conditions.

The original development task wrote only within this project. The Word report and parent content mirror changed externally during that run, as recorded in `verification.json`; that task neither wrote nor reverted them, modified the adjacent Workbench nor resumed HTML synchronization.

## 5. Relocation and English handoff

On 2026-10-06 the newer implementation became the sole current module entry. v0.1 moved to the author's project archive. Materials, predefined conditions and results are together in the [controlled experiment](tests/controlled-example-20261006/README.md). No validator algorithm changed during relocation.

The relocation regression passed 74/74 in 45.078 seconds. The controlled rerun remained FAIL, 18/20, with the same two failures. [Rerun record](tests/controlled-example-20261006/results/run-20261006T125704-991792Z/results.md). Initial results and diagnosis are retained.

The English handoff translates documentation and experiment labels/report text. Validator algorithms, frozen PDF/JSON inputs and historical method findings remain unchanged. Superseded source archives and Chinese visual variants are excluded from this handoff; they remain in the author's project. Language and package checks are separate from the unresolved controlled-experiment failures.

English-output reproduction on 2026-10-07 returned the same 18/20 outcome, with unchanged inputs and validator code. [Actual rerun](tests/controlled-example-20261006/results/run-20261007T070231-676733Z/results.md).
