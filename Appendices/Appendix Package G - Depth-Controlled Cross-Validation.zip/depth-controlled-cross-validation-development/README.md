# Depth-Controlled Cross-Validation

A local, read-only validator compares the same candidate JSON against the same original PDF, method by method. It retains each method's readings, differences and unverified areas. It checks full documents, sections or tables delivered by `full_page_extraction`; downstream target extraction is outside scope. Support scores are not probabilities of correctness.

[Current state](PROJECT_STATE.md) · [Design, official references and limitations](project-support/design/validation-design.md) · [Historical engineering checks](project-support/validation/cross-validation-20261006/verification.md) · [Controlled experiment: one page in two PDF forms](tests/controlled-example-20261006/README.md)

## 1. Environment and execution

Use Python 3.12 and this project's own `.venv`. Dependencies are declared in `pyproject.toml` and `uv.lock`. Poppler's `pdftotext` and Tesseract must also be installed. The recorded implementation work used the existing dependencies and did not install additional models.

From the extracted project root:

```bash
uv sync --locked --extra test
uv run --locked python -m pdf_validator \
  --pdf tests/fixtures/test.pdf \
  --json tests/fixtures/test-input-partial.json \
  --depth 1 --output project-support/validation/example.report.json
uv run --locked --extra test python -m unittest discover -s tests -v
```

The command writes JSON and a Markdown report with the same stem. Successfully generating a report returns exit code 0 even when its status is `failed` or `review_required`; invalid input returns 2. Integrations must inspect `document.status`. `--ocr-lang nor` requires the corresponding Tesseract language data.

The real regulatory fixture `tests/fixtures/test.pdf` has 30 pages. Its historical candidate covers only the first three, so the example reports 27 missing pages. This does not measure the current company parser. Real files for the four Evidence categories were unavailable during this work; generated text and simulated scanned PDFs were used to test program behavior. Obtaining those business files was outside the delivery criteria.

This project provides a Python interface and CLI, with no standalone UI. The recorded work did not change the adjacent Workbench, HTML presentation or Word report.

## 2. Inputs and validation scope

Input retains the `pages → blocks → cells` structure. `page_index` is zero-based. A `bbox` uses PDF points with its origin at the top left; printed page numbers are separate. Block IDs must be unique across the document. Coordinates, types, page order, duplicate IDs and any declared `source_sha256` are checked before processing.

```json
{
  "document_type": "legal",
  "parser_engines": ["upstream-parser"],
  "extraction_stage": "full_page_extraction",
  "pages": [{"page_index": 0, "blocks": [
    {"id": "p1", "type": "paragraph", "text": "Pressure must not exceed 10 bar.",
     "bbox": [50, 60, 450, 90], "order": 0}
  ]}]
}
```

| Type | Upstream workflow description | Default scope |
| --- | --- | --- |
| `legal` | Requirement regulations; text, scanned and mixed pages assessed separately | `full_document` |
| `product_certificate` | Evidence text certificates: PDF Inspector; scanned certificates: LLM image | `full_document` |
| `user_manual` | Evidence; LLM image section extraction | `sections` |
| `deployment_report` | Evidence; LLM image table extraction | `tables` |
| `facility_certificate` | Evidence; LLM image table extraction | `tables` |

`general` and `financial` remain accepted. `extraction_scope` can override the default. The upstream descriptions record business categories; they do not establish an implemented integration or identify the underlying engines.

### 2.1 Section and table inventories

Section or table extraction requires a complete `expected_regions` inventory independent of the candidate. List each page separately for sections spanning pages. Derive the inventory from the original or an independent human inventory. Generating it from candidate blocks would exclude wholly omitted sections or tables from the scope being checked.

```json
{
  "document_type": "user_manual",
  "expected_regions": [
    {"page_index": 0, "bbox": [50, 60, 550, 300]},
    {"page_index": 0, "bbox": [50, 320, 550, 700]}
  ],
  "pages": []
}
```

The optional independent `expected_tables` inventory also uses `page_index` and `bbox`. It can identify tables within full documents or sections, especially layouts the current source detector cannot identify. It must fall within any declared section scope.

Before selecting depth, the program establishes a fixed source-page and table-location inventory from the PDF. Content checks can proceed without an independent section inventory, but scope and complete effective depth remain unconfirmed. Without an independent table inventory, detected tables define only provisional coverage and the report cannot pass. Physical pages establish full-document scope; automatic table discovery does not prove that all borderless tables were found.

### 2.2 Cells and certificate fields

Cells support `row_span` and `column_span`, each a positive integer defaulting to 1. Row and column indices remain zero-based. Cell coordinates may be omitted: the validator still compares the source grid's rows, columns, header text and positions, values, units and spans. A whole-table string alone leaves structure unverified.

```json
{"id": "header", "row": 0, "column": 0, "column_span": 2, "text": "Pressure (bar)"}
```

Certificates support `field` blocks. `field_name`, `value` and `unit` are strings; `entity_id` points to a product or equipment heading block on the same page. The compared field text combines the name, value and unit.

```json
{"id": "pressure", "type": "field", "field_name": "Pressure", "value": "10",
 "unit": "bar", "entity_id": "pump-a", "bbox": [50, 110, 350, 140], "order": 1}
```

Product association currently checks the nearest preceding `Product`, `Device`, `Model` or `Equipment` source label in the same column. Other layouts produce `field_association_unverified`. Older paragraph-based certificate inputs can still have their text checked, but produce `certificate_fields_unstructured`; field association is not claimed as complete.

## 3. Methods, depth and actual completion

The program first selects applicable capabilities, then follows configured priority. These defaults are engineering choices, not measured business-document cost rankings.

| Route | Configured priority, up to four methods |
| --- | --- |
| Text body without tables | Poppler → pdfplumber → Tesseract → Docling |
| Text certificate fields | pdfplumber → Tesseract → Docling → PP-StructureV3 |
| Scanned body, scanned certificates, manual text sections | Tesseract → Docling → PP-StructureV3 → MinerU Basic |
| Text content with tables, including regulations and manuals | pdfplumber → structured Tesseract table workflow → Docling → PP-StructureV3 |
| Scanned content with tables | structured Tesseract table workflow → Docling → PP-StructureV3 → MinerU Basic |

The implemented and executed methods are Poppler, pdfplumber and the structured Tesseract workflow. PDFium provides source inspection and rendering; it does not count as another validation method. OCR cropping, resolution, segmentation and per-cell recognition all belong to the same Tesseract method.

The Tesseract table workflow extracts solid-line grids from the source image, reconstructs rows, columns, empty cells and rectangular merged cells, then recognizes cell text. It shares grid assembly with pdfplumber. Reports record `components`, so these paths must not be described as fully independent table models. Poppler and pdfplumber also share the PDF text layer.

Docling, PP-StructureV3 and MinerU Basic have no verified adapters and were not installed in the recorded environment. They are configured candidates reported as `unavailable`. Installing their packages alone would leave them `not_implemented`, rather than make them valid checks. The design document discusses Camelot and Table Transformer; neither was integrated.

Increasing depth retains every earlier method comparison. Known upstream engines are marked `excluded_upstream`. Inapplicable, unavailable, failed or evidence-empty methods do not count toward effective depth; later candidates are attempted. Current maxima are three methods for text bodies, two for text tables and one for scanned content. Individual pages may achieve less. Entirely missing pages receive deterministic missing-page findings; content methods are neither run nor counted for them.

Depth 5 is an interface boundary only: original PDF and candidate, fixed scope, upstream model ID, a different review model, maximum budget and appended differences. `depth_5.executed` remains `false`. No model was selected, no remote or paid API was called, and no files were uploaded.

To change configured priority, pass `--method-order order.json`, for example:

```json
{"text": ["pdfplumber", "poppler", "tesseract", "docling"]}
```

Routes are `text`, `fields`, `scan`, `tables_text` and `tables_scan`. Duplicate methods, obsolete OCR variant names and unknown methods are rejected. Configuration cannot make a plain-text reader perform table validation.

## 4. Reports and migration

Reports use `validation-report/3` with `local-evidence/10` rules. They retain `document`, `pages`, five-dimensional support scores, `findings` and `review_items`.

- `pages[].comparisons` retains independent readings, cells, scores and finding IDs for each method. Later agreement does not remove earlier differences. Cross-method corroboration adds a finding without rewriting earlier findings.
- `findings[].method` identifies the method. Finding IDs are content hashes, not `F00001` sequence numbers, so they can be compared across depths.
- `scope_sha256` identifies the fixed page, section or table scope. PDF and candidate files retain separate SHA-256 hashes.
- `effective_depth` counts methods completing all required checks over the fixed scope. Unverified field association, table structure, section order or scope prevents a method from counting as complete. `block_depths` separately describes localized content or structured-cell evidence; it does not confirm all semantics.
- `methods[].status` distinguishes `ok`, `empty`, `error`, `unavailable`, `not_applicable`, `excluded_upstream` and `not_implemented`. Dependency detection is not a successful engine run.
- `cost` records wall-clock time, CPU time, hardware/Python information and process peak memory. Memory is a process-lifetime high-water mark, not exclusive memory per method. API charges are 0; local monetary computing cost is unknown. `depth_5` is a structured object.

Scores may be `assessed`, `partial`, `unverified` or `not_applicable`; `calibrated_correctness` remains `null`. Greater depth can add useful findings or false positives; higher accuracy is not guaranteed. Missing pages retain unknown weight in other dimensions so a few extracted pages cannot mask whole-document omissions.

## 5. Validation boundaries

Tests use generated PDFs and scanned images, controlled errors and an existing real regulatory fixture. They test program behavior, not a company Evidence dataset or independently labelled accuracy. Business accuracy, missed-error rates, false-positive rates and review time for the four Evidence categories remain unmeasured.

Image-table support is limited to axis-aligned solid-line grids and rectangular merged cells, with lines of at least 12 points and at most 200 cells. Borderless, dashed, rotated and complex multipage tables need another structural parser or human review. Header text, positions and spans are checked at the first depth. Complex semantic header classification, figure/formula meaning and multicolumn reading order may remain unverified. Agreement scores or method counts do not replace these capabilities.

## 6. Package layout

The current implementation is at the extracted root: `pdf_validator/` contains the program, `tests/` the engineering tests and controlled experiment, and `project-support/` the design and retained verification evidence. Rebuild `.venv/` locally. The former v0.1 implementation and superseded source snapshots remain in the author's project archive and are excluded from this current English handoff.
