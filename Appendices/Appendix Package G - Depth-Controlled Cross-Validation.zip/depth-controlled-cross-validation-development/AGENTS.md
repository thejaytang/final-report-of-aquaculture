# Depth-Controlled Cross-Validation Agent instructions

This is an independent project and repository. Read [README.md](README.md), [PROJECT_STATE.md](PROJECT_STATE.md) and [design and interfaces](project-support/design/validation-design.md). The separate Workbench project is a possible reference only; its JSON, environment or internal confidence scores are not established contracts for this project.

## Always

- Treat original PDFs and upstream JSON as read-only evidence. Record input hashes, physical page order, tool versions and rule versions. Reports locate and assess issues.
- Distinguish tool agreement, validation support and correctness probabilities calibrated against human-labelled samples. Without calibration, correctness probability is unknown; an agreement percentage cannot substitute for it.
- Check both PDF-to-JSON omissions and JSON-to-PDF misrecognition, additions and field contamination. Keep physical page order separate from printed page numbers.
- Report five dimensions per page and document. Distinguish no applicable content from insufficient evidence; high scores elsewhere must not conceal critical errors.
- Locate human-review needs to specific regions and record unverified areas, evidence paths and method overlap.
- Fix source scope before comparing the same candidate through each method. Preserve raw readings and earlier differences instead of selecting only the closest match.
- Check table values, rows, columns, header text and positions, units and spans from the first depth. Tables within regulations and manuals also use structured routes. OCR configurations do not count as separate depths.
- Derive section/table inventories from source evidence or an independent inventory. Report uninstalled, unimplemented, inapplicable, failed and partially unverified methods honestly. Configured order is not a measured cost ranking.

## Ask first

Uploading PDF/JSON, calling remote or paid models, connecting company systems, modifying Workbench, committing or publishing requires authorization matching the action.

## Never

- Do not reintroduce public benchmark scoring into this scope or describe an OmniParse fused output as multiple independent votes.
- Do not write validation results back into upstream JSON, automatically repair originals or use unvalidated scores as proof of correctness.
